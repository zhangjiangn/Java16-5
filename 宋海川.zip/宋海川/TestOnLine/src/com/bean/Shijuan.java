package com.bean;

import java.util.HashSet;
import java.util.Set;


/**
 * Shijuan entity. @author MyEclipse Persistence Tools
 */

public class Shijuan  implements java.io.Serializable {


    // Fields    

     private Integer jid;
    
     private String sjlie;
     private String cid;
     private String kaisj;
     private String sjztai;
     private Integer kaossc;
     private String kmname;
     private String biaoti;
     private String jiedname;
     private String fanxname;
     private Integer zongfen;
     private Integer suantishu;	
     private Integer dantifen;
     private String jieshusj;
     private Set shitis = new HashSet(0);


    // Constructors

    /** default constructor */
    public Shijuan() {
    }

    
    /** full constructor */
    
   
    // Property accessors

    public Integer getJid() {
        return this.jid;
    }
    







	public Shijuan(Integer jid, String sjlie, String cid, String kaisj,
			String sjztai, Integer kaossc, String kmname, String biaoti,
			String jiedname, String fanxname, Integer zongfen,
			Integer suantishu, Integer dantifen, String jieshusj, Set shitis) {
		super();
		this.jid = jid;
		this.sjlie = sjlie;
		this.cid = cid;
		this.kaisj = kaisj;
		this.sjztai = sjztai;
		this.kaossc = kaossc;
		this.kmname = kmname;
		this.biaoti = biaoti;
		this.jiedname = jiedname;
		this.fanxname = fanxname;
		this.zongfen = zongfen;
		this.suantishu = suantishu;
		this.dantifen = dantifen;
		this.jieshusj = jieshusj;
		this.shitis = shitis;
	}


	public String getSjlie() {
		return sjlie;
	}


	public void setSjlie(String sjlie) {
		this.sjlie = sjlie;
	}


	public String getCid() {
		return cid;
	}


	public void setCid(String cid) {
		this.cid = cid;
	}


	public String getKaisj() {
		return kaisj;
	}


	public void setKaisj(String kaisj) {
		this.kaisj = kaisj;
	}


	public String getSjztai() {
		return sjztai;
	}


	public void setSjztai(String sjztai) {
		this.sjztai = sjztai;
	}


	public Integer getKaossc() {
		return kaossc;
	}


	public void setKaossc(Integer kaossc) {
		this.kaossc = kaossc;
	}


	public String getKmname() {
		return kmname;
	}


	public void setKmname(String kmname) {
		this.kmname = kmname;
	}


	public String getBiaoti() {
		return biaoti;
	}


	public void setBiaoti(String biaoti) {
		this.biaoti = biaoti;
	}


	public String getJiedname() {
		return jiedname;
	}


	public void setJiedname(String jiedname) {
		this.jiedname = jiedname;
	}


	public String getFanxname() {
		return fanxname;
	}


	public void setFanxname(String fanxname) {
		this.fanxname = fanxname;
	}


	public Integer getZongfen() {
		return zongfen;
	}


	public void setZongfen(Integer zongfen) {
		this.zongfen = zongfen;
	}


	public Integer getSuantishu() {
		return suantishu;
	}


	public void setSuantishu(Integer suantishu) {
		this.suantishu = suantishu;
	}


	public Integer getDantifen() {
		return dantifen;
	}


	public void setDantifen(Integer dantifen) {
		this.dantifen = dantifen;
	}


	public String getJieshusj() {
		return jieshusj;
	}


	public void setJieshusj(String jieshusj) {
		this.jieshusj = jieshusj;
	}


	public Set getShitis() {
		return shitis;
	}


	public void setShitis(Set shitis) {
		this.shitis = shitis;
	}


	public void setJid(Integer jid) {
		this.jid = jid;
	}


	

}