package com.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Clases entity. @author MyEclipse Persistence Tools
 */

public class Clases implements java.io.Serializable {

	// Fields

	private Integer cid;
	private Clases clases;
	private String className;
	private Integer sjid;
	private Set strutses = new HashSet(0);

	// Constructors

	/** default constructor */
	public Clases() {
	}

	/** minimal constructor */
	public Clases(Clases clases) {
		this.clases = clases;
	}

	/** full constructor */
	public Clases(Integer cid, Clases clases, String className, int sjid,
			Set strutses) {
		super();
		this.cid = cid;
		this.clases = clases;
		this.className = className;
		this.sjid = sjid;
		this.strutses = strutses;
	}
	// Property accessors

	public Integer getCid() {
		return this.cid;
	}

	

	public void setCid(Integer cid) {
		this.cid = cid;
	}

	public Clases getClases() {
		return this.clases;
	}

	public void setClases(Clases clases) {
		this.clases = clases;
	}

	public String getClassName() {
		return this.className;
	}

	public void setClassName(String className) {
		this.className = className;
	}


	public Set getStrutses() {
		return this.strutses;
	}

	public void setStrutses(Set strutses) {
		this.strutses = strutses;
	}

	public Integer getSjid() {
		return sjid;
	}

	public void setSjid(Integer sjid) {
		this.sjid = sjid;
	}

	

	

}