package com.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;

import com.bean.Emp;
import com.bean.Struts;
import com.dao.Logindao;

public class Logindaoimpl implements Logindao {

	public Struts Logins(String sname,String spwd) {
		// TODO Auto-generated method stub
		Struts struts=new Struts();
		try {
//				String hql="from Struts where szhanghao=:szhanghao and spwd=:spwd";
//				Query query=session.createQuery(hql);
//			query.setString("szhanghao", sname)
//					.setString("spwd", spwd);
//			struts=(Struts) query.list();
		Criteria criteria=session.createCriteria(Struts.class)
					.add(Restrictions.eq("szhanghao", sname))
					.add(Restrictions.eq("spwd", spwd));
		List<Struts> list=criteria.list();
		for (int i = 0; i <list.size(); i++) {
			struts=list.get(i);
		}
		} catch (Exception e) {
			// TODO: handle exception
			
		}
		return struts;
	}

	public Emp login(String sname,String spwd) {
		// TODO Auto-generated method stub
		Emp emp=new Emp();
		try {
//			String hql="from Emp where uyonghm=:uyonghm and upwd=:spwd";
//		Query query=session.createQuery(hql);
//		query.setString("uyonghm", sname)
//			  .setString("spwd", spwd);
//		emp=(Emp) query.list();
			Criteria criteria=session.createCriteria(Emp.class)
			.add(Restrictions.eq("uyonghm", sname))
			.add(Restrictions.eq("upwd", spwd));
			List<Emp> list=criteria.list();
			for (int i = 0; i <list.size(); i++) {
				emp=list.get(i);
			}		
		} catch (Exception e) {
			// TODO: handle exception
			emp=null;
			
		}
		return emp;
	}

}
