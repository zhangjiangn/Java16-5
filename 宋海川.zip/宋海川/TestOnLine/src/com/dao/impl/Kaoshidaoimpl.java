package com.dao.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tools.PageBean;

import com.bean.Clases;
import com.bean.Shijuan;
import com.bean.Shiti;
import com.bean.StrutsShiti;
import com.dao.HibernateSessionFactory;
import com.dao.Kaoshidao;
import com.util.PageBeans;

public class Kaoshidaoimpl implements Kaoshidao {




	public List<Shijuan> shijuan(int jid) {
		// TODO Auto-generated method stub
		Criteria criteria=session.createCriteria(Shijuan.class).add(Restrictions.eq("jid", jid));
		List<Shijuan> list=criteria.list();
		return list;
	}

	public Shijuan shijian(int jid) {
		// TODO Auto-generated method stub
		Shijuan shijuan=(Shijuan) session.get(Shijuan.class, jid);
		return shijuan;
	}

	public Shiti shiti(int p,int jid) {
			Shijuan shijuan=(Shijuan) session.get(Shijuan.class, jid);
			Set<Shiti> set=shijuan.getShitis();
			List<Shiti> list= new ArrayList<Shiti>(set);
		
			Shiti shiti=list.get(p);
		return shiti;
		
		
	
		
		
		
		
	}

	public int insertss(StrutsShiti strutsShiti) {
		// TODO Auto-generated method stub
		int s=0;
		try {
			
				session.beginTransaction();
				session.save(strutsShiti);
				session.flush();
				session.clear();
				session.beginTransaction().commit();
			
			
		} catch (Exception e) {
			// TODO: handle exception
			s=1;
		}
		return s;
	}

	public int updatess(int sid,int tid,int jid,String daan,String zqdaan,String dantifen) {
		// TODO Auto-generated method stub
		int s=0;
		try {
			 Criteria criteria=session.createCriteria(StrutsShiti.class).add(Restrictions.eq("sid",sid)).add(Restrictions.eq("tid",tid)).add(Restrictions.eq("jid",jid));
			 List<StrutsShiti> list=criteria.list();
			 for (StrutsShiti strutsShiti2 : list) {
				 strutsShiti2.setJid(jid);
				 strutsShiti2.setSid(sid);
				 strutsShiti2.setTid(tid);
				 strutsShiti2.setDaan(daan);
				strutsShiti2.setZqdaan(zqdaan);
				strutsShiti2.setDantifen(dantifen);
				 session.beginTransaction();
				session.update(strutsShiti2);
				session.beginTransaction().commit();
			 }	
		} catch (Exception e) {
			// TODO: handle exception
			s=1;
		}
		return s;
	}

	public List<StrutsShiti> panduan(int sid,int jid) {
		// TODO Auto-generated method stub
	 Criteria criteria=session.createCriteria(StrutsShiti.class).add(Restrictions.eq("sid",sid)).add(Restrictions.eq("jid",jid));
	 criteria.addOrder(Order.asc("tid"));
		List<StrutsShiti> list=criteria.list();
		return list;
	}

	public List<StrutsShiti> chankang(int sid) {
		// TODO Auto-generated method stub
		
		Criteria criteria=session.createCriteria(StrutsShiti.class).add(Restrictions.eq("sid",sid));
		List<StrutsShiti> list=criteria.list();
		return list;
	}

	public int update(int sid, String zqdaan) {
		// TODO Auto-generated method stub\
		int s=0;
		try {	
		Criteria criteria=session.createCriteria(StrutsShiti.class).add(Restrictions.eq("sid",sid));
		List<StrutsShiti> list=criteria.list();
		StrutsShiti strutsShiti=new StrutsShiti();
		for (StrutsShiti strutsShiti1 : list) {
			strutsShiti=(StrutsShiti) session.get(StrutsShiti.class,strutsShiti1.getTid());
			strutsShiti.setZqdaan(zqdaan);
			strutsShiti.setSid(sid);
			session.beginTransaction();
			session.update(strutsShiti);
			session.beginTransaction().commit();
		}
	
		} catch (Exception e) {
			// TODO: handle exception
			s=1;
		}
		return s;
		
	}


	
}
