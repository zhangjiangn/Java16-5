package com.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tools.PageBean;

import com.bean.Clases;
import com.bean.Fangxiang;
import com.bean.Jieduan;
import com.bean.Kemu;
import com.bean.Shijuan;
import com.bean.Shiti;
import com.dao.HibernateSessionFactory;
import com.dao.Shijuandao;

public class Shijuandaoimpl implements Shijuandao {

	public List<Fangxiang> fangxiangs() {
		// TODO Auto-generated method stub
		String hql="from Fangxiang";
		List<Fangxiang> list=session.createQuery(hql).list();
		
		return list;
	}

	public PageBean fenye(int p) {
		// TODO Auto-generated method stub
		PageBean pb=new PageBean();
		Criteria criteria=session.createCriteria(Shijuan.class);
		Projection projections=Projections.rowCount();
		criteria.setProjection(projections);
		int count=(Integer) criteria.uniqueResult();	
		pb.setPagesize(10);
		pb.setCount(count);
		pb.setP(p);		
		String hql="from Shijuan";
		Query query=session.createQuery(hql);
		int k=pb.getPagesize();
		query.setFirstResult((pb.getP()-1)*k)
				.setMaxResults(k);			
		List<Shijuan> list=query.list();
		pb.setData(list);
		return pb;
	}

	public int insert(Shijuan shijuan,int tid) {
		// TODO Auto-generated method stub
		int s=0;
	try {
		Shiti shiti=(Shiti) session.get(Shiti.class, tid);
		shiti.getShijuans().add(shijuan);
		shijuan.getShitis().add(shiti);
		session.beginTransaction();
		session.save(shijuan);
		session.beginTransaction().commit();
	} catch (Exception e) {
		// TODO: handle exception
		s=1;
	}	
		return s;
	}

	public List<Jieduan> jieduans() {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		String hql="from Jieduan";
		List<Jieduan> list=session.createQuery(hql).list();
		
		return list;
	}

	public List<Kemu> kemus() {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		String hql="from Kemu";
		List<Kemu> list=session.createQuery(hql).list();
		
		return list;
	}

	public Shijuan select(int jid) {
		// TODO Auto-generated method stub
		session.beginTransaction();
		session.get(Shijuan.class, jid);
		session.beginTransaction().commit();
		return null;
	}

	public List<Shijuan> shijuan(String kmname, String jiedname, String fanxname,
			String sjztai, String sjlie) {
		// TODO Auto-generated method stub

		Criteria criteria=session.createCriteria(Shijuan.class)
						.add(Restrictions.eq("kmname", kmname))
						.add(Restrictions.eq("jiedname", jiedname))
						.add(Restrictions.eq("fanxname", fanxname))
						.add(Restrictions.eq("sjztai", sjztai))
						.add(Restrictions.eq("sjlie", sjlie));
		 List<Shijuan> list=criteria.list();
		
		return list;
	}

	public List<Shiti> selectshiti(int kid) {
		// TODO Auto-generated method stub
		Criteria criteria=session.createCriteria(Shiti.class).add(Restrictions.eq("kid", kid));
		
		List<Shiti> list=criteria.list();
		
		return list;
	}

	public int selectke(String name) {
		// TODO Auto-generated method stub
		int s=0;
		Criteria criteria=session.createCriteria(Kemu.class).add(Restrictions.eq("kname", name));
		List<Kemu> list=criteria.list();
		for (Kemu kemu : list) {
			s=kemu.getKid();
		}
		return s;
	}

	public List<Shiti> danjiandan() {
		// TODO Auto-generated method stub
	
		Criteria criteria=session.createCriteria(Shiti.class)
								 .add(Restrictions.eq("tixiaolie", "��ѡ"))
								 .add(Restrictions.eq("nanyidu", "��"));
		List<Shiti> list=criteria.list();
		
		return list;
	}

	public List<Shiti> dankunnan() {
		// TODO Auto-generated method stub
		Criteria criteria=session.createCriteria(Shiti.class)
		 .add(Restrictions.eq("tixiaolie", "��ѡ"))
		 .add(Restrictions.eq("nanyidu", "����"));
List<Shiti> list=criteria.list();
		return list;
	}

	public List<Shiti> danyiban() {
		// TODO Auto-generated method stub
		Criteria criteria=session.createCriteria(Shiti.class)
		 .add(Restrictions.eq("tixiaolie", "��ѡ"))
		 .add(Restrictions.eq("nanyidu", "һ��"));
		List<Shiti> list=criteria.list();

		return list;
	}

	public List<Shiti> fujiandan() {
		// TODO Auto-generated method stub
		Criteria criteria=session.createCriteria(Shiti.class)
		 .add(Restrictions.eq("tixiaolie", "��ѡ"))
		 .add(Restrictions.eq("nanyidu", "��"));
		List<Shiti> list=criteria.list();
		return list;
	}

	public List<Shiti> fukunnan() {
		// TODO Auto-generated method stub��
		Criteria criteria=session.createCriteria(Shiti.class)
		 .add(Restrictions.eq("tixiaolie", "��ѡ"))
		 .add(Restrictions.eq("nanyidu", "����"));
List<Shiti> list=criteria.list();
		return list;
	}

	public List<Shiti> fuyiban() {
		// TODO Auto-generated method stub
		Criteria criteria=session.createCriteria(Shiti.class)
		 .add(Restrictions.eq("tixiaolie", "��ѡ"))
		 .add(Restrictions.eq("nanyidu", "һ��"));
List<Shiti> list=criteria.list();
		return list;
	}

	public List<Clases> banji() {
		// TODO Auto-generated method stub
		Criteria criteria=session.createCriteria(Clases.class);
		List<Clases> list=criteria.list();
		return list;
	}

	public int gai(int sjid, String sjlie,String ban) {
		// TODO Auto-generated method stub
		int s=0;
		try {
			Shijuan shijuan=(Shijuan) session.get(Shijuan.class, sjid);
			shijuan.setKaisj(sjlie);
			shijuan.setCid(ban);
			shijuan.setSjztai("������");
			session.beginTransaction();
			session.update(shijuan);
			session.beginTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			s=1;
		}
		return s;
	}

	public int xiu(String className, int sjid) {
		// TODO Auto-generated method stub
		int s=0;
		try {
			List<Clases> list=session.createCriteria(Clases.class).add(Restrictions.eq("className", className)).list();
			for (Clases clases : list) {
				clases.setSjid(sjid);
				session.beginTransaction();
				session.update(clases);
				session.beginTransaction().commit();
			}
		} catch (Exception e) {
			// TODO: handle exception
			s=1;
		}
		return s;
	}

	public Shijuan chakan(int jid) {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		Shijuan shijuan=(Shijuan) session.get(Shijuan.class, jid);
		return shijuan;
	}

	public String zhong(String cid) {
		String kao=null;
		List<Shijuan> list=session.createCriteria(Shijuan.class).add(Restrictions.eq("cid", cid)).list();
		for (Shijuan shijuan : list) {
			kao=shijuan.getSjztai();
		}
		
		return kao;
	}

	public int jieshu(int jid, String jieshusj) {
		// TODO Auto-generated method stub
		int s=0;
		try {
			Shijuan shijuan=(Shijuan) session.get(Shijuan.class,jid);
			shijuan.setSjztai("���Խ���");
			shijuan.setJieshusj(jieshusj);
			session.beginTransaction();
			session.update(shijuan);
			session.beginTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			s=1;
		}
		return s;
	}
	
}
