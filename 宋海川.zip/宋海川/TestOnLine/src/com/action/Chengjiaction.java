package com.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;
import org.jgroups.protocols.SHUFFLE;

import tools.PageBean;

import com.bean.Clases;
import com.bean.Fangxiang;
import com.bean.Jieduan;
import com.bean.Kemu;
import com.bean.Shijuan;
import com.bean.Shiti;
import com.bean.Struts;
import com.bean.StrutsShiti;
import com.biz.Chengjibiz;
import com.biz.impl.Chengjibizimpl;


public class Chengjiaction {
	private int jid;
	private int sid;
	private Chengjibiz biz=new Chengjibizimpl();
	private List<Kemu> list3;
	private List<Jieduan> list4;
	private List<Fangxiang> list ;
	private List<Struts> list2;
	private Shijuan shijuan;
	private PageBean pb;
	private List<Clases> list5;
	private List<StrutsShiti> lists;
	private Struts strutsl;
	private double count=0;
	private Shiti shiti;
	private String kemu;
	private String fang;
	private String classifyid;
	private String lie;
	private List<Shijuan> shijuans;
	private String names;
	private int clases;
	public String fenye(){
		HttpServletRequest request=ServletActionContext.getRequest();
		list=biz.fangxiangs();
		list4=biz.jieduans();
		list3=biz.kemus();
		Integer p=1;
		String ps=request.getParameter("sp");
		if(ps!=null){
			p=Integer.parseInt(ps.trim());
		};		
		pb=biz.fenye(p);
		return "ajxt";	

	}
	public String chengji() {
		int sid=biz.strut(jid);
		int id=biz.shiti(jid);
		list2=biz.struts(id);
		list5=biz.list();
		List<StrutsShiti> list=biz.strutsShitis(jid);
		
		double son=0;
		int s=0;
		for (StrutsShiti strutsShiti : list) {
			if (strutsShiti.getDaan().equals(strutsShiti.getZqdaan())) {
				s=s+1;			
			}

			son=Double.parseDouble(strutsShiti.getDantifen());
			
		}

		count=son*s;
		shijuan=biz.Shijuan(sid);
		return "chengji";
		
	}
	public String xiangqing(){
		shijuan=biz.shijuans(jid);
		lists=biz.strutsShitis(jid);
		strutsl=biz.stru(sid);
		double son=0;
		int s=0;
		for (StrutsShiti strutsShiti : lists) {
			if (strutsShiti.getDaan().equals(strutsShiti.getZqdaan())) {
				s=s+1;
			}
			shiti=biz.shi(strutsShiti.getTid());
		
			son=Double.parseDouble(strutsShiti.getDantifen());
		}
		count=son*s;
		return "xiangqing";
		
	}
	
	
	public String chaxun() {
		list=biz.fangxiangs();
		list4=biz.jieduans();
		list3=biz.kemus();
		shijuans=biz.shijuan(kemu, classifyid, fang, lie);
		return "chaxun";
	}
	public String chati(){
		shijuan=biz.shijuans(clases);
		int sid=biz.sid(names);
		lists=biz.strutsshitis(clases, sid);
		double son=0;
		int s=0;
		for (StrutsShiti strutsShiti : lists) {
			if (strutsShiti.getDaan().equals(strutsShiti.getZqdaan())) {
				s=s+1;
			}
			shiti=biz.shi(strutsShiti.getTid());
		
			son=Double.parseDouble(strutsShiti.getDantifen());
		}
		count=son*s;
		return "chati";
	}
	
	public int getJid() {
		return jid;
	}
	public void setJid(int jid) {
		this.jid = jid;
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public List<Kemu> getList3() {
		return list3;
	}
public void setList3(List<Kemu> list3) {
		this.list3 = list3;
	}
public List<Jieduan> getList4() {
		return list4;
	}

	public void setList4(List<Jieduan> list4) {
		this.list4 = list4;
	}
public List<Fangxiang> getList() {
		return list;
	}
	public void setList(List<Fangxiang> list) {
		this.list = list;
	}
	public PageBean getPb() {
		return pb;
	}
	public void setPb(PageBean pb) {
		this.pb = pb;
	}
	public List<Struts> getList2() {
		return list2;
	}
	public void setList2(List<Struts> list2) {
		this.list2 = list2;
	}
	public Shijuan getShijuan() {
		return shijuan;
	}
	public void setShijuan(Shijuan shijuan) {
		this.shijuan = shijuan;
	}
	public List<Clases> getList5() {
		return list5;
	}
	public void setList5(List<Clases> list5) {
		this.list5 = list5;
	}
	public double getCount() {
		return count;
	}
	public void setCount(double count) {
		this.count = count;
	}
	public List<StrutsShiti> getLists() {
		return lists;
	}
	public void setLists(List<StrutsShiti> lists) {
		this.lists = lists;
	}
	public Struts getStrutsl() {
		return strutsl;
	}
	public void setStrutsl(Struts strutsl) {
		this.strutsl = strutsl;
	}
	public Shiti getShiti() {
		return shiti;
	}
	public void setShiti(Shiti shiti) {
		this.shiti = shiti;
	}
	public String getKemu() {
		return kemu;
	}
	public void setKemu(String kemu) {
		this.kemu = kemu;
	}
	public String getFang() {
		return fang;
	}
	public void setFang(String fang) {
		this.fang = fang;
	}
	public String getClassifyid() {
		return classifyid;
	}
	public void setClassifyid(String classifyid) {
		this.classifyid = classifyid;
	}
	public String getLie() {
		return lie;
	}
	public void setLie(String lie) {
		this.lie = lie;
	}
	public List<Shijuan> getShijuans() {
		return shijuans;
	}
	public void setShijuans(List<Shijuan> shijuans) {
		this.shijuans = shijuans;
	}
	public String getNames() {
		return names;
	}
	public void setNames(String names) {
		this.names = names;
	}
	public int getClases() {
		return clases;
	}
	public void setClases(int clases) {
		this.clases = clases;
	}

	
	
}
