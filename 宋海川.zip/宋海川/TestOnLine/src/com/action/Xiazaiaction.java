package com.action;

import java.io.FileInputStream;
import java.io.InputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.net.aso.r;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;

public class Xiazaiaction extends ActionSupport{
	private InputStream dowFileName_is;
	private String dowfile_Name;
	public String execute()throws Exception{  
		
		System.out.println(dowfile_Name);
		String filepath=ServletActionContext.getServletContext().getRealPath("/")+"upload/"+dowfile_Name;
		dowFileName_is=new FileInputStream(filepath);
	        return SUCCESS;  
	    }  
	

	
	public String getDowfile_Name() {
		return dowfile_Name;
	}
	public void setDowfile_Name(String dowfileName) {
		dowfile_Name = dowfileName;
	}
	public InputStream getDowFileName_is() {
		return dowFileName_is;
	}
	public void setDowFileName_is(InputStream dowFileNameIs) {
		dowFileName_is = dowFileNameIs;
	}
}
