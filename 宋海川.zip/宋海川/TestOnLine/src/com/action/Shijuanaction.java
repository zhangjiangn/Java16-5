package com.action;

import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.servlet.http.HttpServletRequest;

import oracle.net.aso.r;

import org.apache.struts2.ServletActionContext;
import org.jgroups.protocols.SHUFFLE;

import tools.PageBean;
import tools.Suijishu;

import com.bean.Clases;
import com.bean.Fangxiang;
import com.bean.Jieduan;
import com.bean.Kemu;
import com.bean.Shijuan;
import com.bean.Shiti;
import com.biz.Shijuanbiz;
import com.biz.impl.Shijuanimpl;

public class Shijuanaction {
	private Shijuan shijuan;
	private List<Kemu> list3;
	private List<Jieduan> list4;
	private List<Fangxiang> list ;
	private List<Shijuan> list2;
	private List<Shiti> list5;
	private List<Clases> list6;
	private PageBean pb;
	public Shijuanbiz biz=new Shijuanimpl();
	public  Suijishu sui=new Suijishu();
	private int jid;
	private String jieshusj;
	public String fenye() {
		HttpServletRequest request=ServletActionContext.getRequest();
		list=biz.fangxiangs();
		list4=biz.jieduans();
		list3=biz.kemus();
		Integer p=1;
		String ps=request.getParameter("sp");
		if(ps!=null){
			p=Integer.parseInt(ps.trim());
		};		
		pb=biz.fenye(p);
		return "ajxt";	
	}
	public String select(){
		list=biz.fangxiangs();
		list4=biz.jieduans();
		list3=biz.kemus();
		HttpServletRequest request=ServletActionContext.getRequest();
		String kmname=request.getParameter("kmname");
		String jiedname=request.getParameter("jiedname");
		String fanxname=request.getParameter("fanxname");
		String sjztai=request.getParameter("sjztai");
		String sjlie=request.getParameter("sjlie");
		list2=biz.shijuan(kmname, jiedname, fanxname, sjztai, sjlie);
		return "select";	
	}
	public String zujuan(){
		list=biz.fangxiangs();
		list4=biz.jieduans();
		list3=biz.kemus();
		HttpServletRequest request=ServletActionContext.getRequest();
		String jiedname=request.getParameter("jiedname");
		String slo=request.getParameter("slo");
		String hkid=request.getParameter("kid");
		request.setAttribute("jiedname", jiedname);
		request.setAttribute("fxname", slo);
		request.setAttribute("name", hkid);
		int kid=biz.selectke(hkid);
		request.setAttribute("hkid", kid);

		list5=biz.selectshiti(kid);	
		return "zujuan";	
	}
	public String tianjia(){
		HttpServletRequest request=ServletActionContext.getRequest();
		String hkid=request.getParameter("kid");
		String jiedname=request.getParameter("jiedname");
		String slo=request.getParameter("slo");
	shijuan.setFanxname(slo);
		shijuan.setJiedname(jiedname);
		shijuan.setKmname(hkid);
	String[] tsid=request.getParameterValues("tid");
		int s=0;
		for (String string : tsid) {
			int tid=Integer.parseInt(string);
			s=biz.insert(shijuan, tid);
		}
		if (s==0) {
			return "tianjia";
		} else {
			return "shibai";
		}
		
	}
	public String danzhu(){
	
		list=biz.fangxiangs();
	
		return "okl";	
	}
	public String jieduan(){
		HttpServletRequest request=ServletActionContext.getRequest();
		list=biz.fangxiangs();
		list4=biz.jieduans();
		String slo=request.getParameter("slo");
		request.setAttribute("fxname", slo);

		return "sol";	
	}
	public String kemu(){
		HttpServletRequest request=ServletActionContext.getRequest();
		String jiedname=request.getParameter("jiedname");
		String slo=request.getParameter("slo");
		list=biz.fangxiangs();
		list4=biz.jieduans();
		list3=biz.kemus();
		request.setAttribute("jiedname", jiedname);
		request.setAttribute("fxname", slo);
		return "kemu";	
	}
	public String zhu(){
		
		list=biz.fangxiangs();
	
		return "zhu";	
	}
	public String jie(){
		HttpServletRequest request=ServletActionContext.getRequest();
		list=biz.fangxiangs();
		list4=biz.jieduans();
		String slo=request.getParameter("slo");
		request.setAttribute("fxname", slo);

		return "jie";	
	}
	public String ke(){
		HttpServletRequest request=ServletActionContext.getRequest();
		String jiedname=request.getParameter("jiedname");
		String slo=request.getParameter("slo");
		list=biz.fangxiangs();
		list4=biz.jieduans();
		list3=biz.kemus();
		request.setAttribute("jiedname", jiedname);
		request.setAttribute("fxname", slo);
		return "ke";	
	}
	public String add(){
		int so=0;
		HttpServletRequest request=ServletActionContext.getRequest();
		String fang=request.getParameter("slo");
		String jie=request.getParameter("jiedname");
		shijuan.setFanxname(fang);
		shijuan.setJiedname(jie);
		int jian=Integer.parseInt(request.getParameter("jian"));
		 Set<Integer> tid=sui.shuijishu(jian);
		 for (Integer integer : tid) {
			 Shiti list= biz.danjiandan().get(integer);		
			so=biz.insert(shijuan, list.getTid());
		 }
		int yi=Integer.parseInt(request.getParameter("yi"));
		 Set<Integer> tid1=sui.shuijishu(yi);
		 for (Integer integer : tid1) {
			 Shiti list= biz.danyiban().get(integer);		
			 so=biz.insert(shijuan, list.getTid());
		 }
		int kun=Integer.parseInt(request.getParameter("kun"));
		 Set<Integer> tid2=sui.shuijishu(kun);
		 for (Integer integer : tid2) {
			 Shiti list= biz.dankunnan().get(integer);		
			 so=biz.insert(shijuan, list.getTid());
		 }
		int ji=Integer.parseInt(request.getParameter("ji"));
		 Set<Integer> tid3=sui.shuijishu(ji);
		 for (Integer integer : tid3) {
			 Shiti list= biz.fujiandan().get(integer);		
			 so=biz.insert(shijuan, list.getTid());
		 }
		int dyi=Integer.parseInt(request.getParameter("dyi"));
		Set<Integer> tid4=sui.shuijishu(dyi);
		 for (Integer integer : tid4) {
			 Shiti list= biz.fuyiban().get(integer);		
			 so=biz.insert(shijuan, list.getTid());
		 }
		int ku=Integer.parseInt(request.getParameter("ku"));
		Set<Integer> tid5=sui.shuijishu(dyi);
		 for (Integer integer : tid5) {
			 Shiti list= biz.fukunnan().get(integer);		
			 so=biz.insert(shijuan, list.getTid());
		 }
		 if (so==0) {
			 return "add";
		} else {
			return "notadd";
		}	
	}

	public String kaoshi(){
		list6=biz.banji();
		HttpServletRequest request=ServletActionContext.getRequest();
		String jid=request.getParameter("jid");
		request.setAttribute("jid", jid);
		return "kaoshi";
	}
	public String kaishi(){
		int s=1;
		HttpServletRequest request=ServletActionContext.getRequest();
		String sn=request.getParameter("sn");
		String sc=request.getParameter("sc");
		int sjid=0;
		String[] cid=request.getParameterValues("cname");
		String ban=null;
		String kao=null;
		for (String string : cid) {
			if (string!="") {
				kao=biz.zhong(string);	
			} 			
		}
		
				if (kao != "������") {
				 sjid=Integer.parseInt(request.getParameter("jid"));
					s=biz.xiu(cid[0], sjid);
					s=biz.xiu(cid[1], sjid);
					s=biz.xiu(cid[2], sjid);
					s=biz.xiu(cid[3], sjid);
					String sjlei=sn+" "+sc;
					ban=cid[0]+cid[1]+cid[2]+cid[3];	
					s=biz.gai(sjid,sjlei,ban);
					return "kaizhong";
				}else if (kao=="������"){
				list6=biz.banji();
				String jid=request.getParameter("jid");
				request.setAttribute("jid", jid);
				request.setAttribute("kao", kao);
				
				}
				return "kaishizhong";
				
				
		
	}
	public String chakan(){
		HttpServletRequest request=ServletActionContext.getRequest();
		int sjid=Integer.parseInt(request.getParameter("jid"));
		shijuan=biz.chakan(sjid);
		return "chakan";
	}
	
	public String jieshu(){
		HttpServletRequest request=ServletActionContext.getRequest();
		int s=biz.jieshu(jid, jieshusj);
		list=biz.fangxiangs();
		list4=biz.jieduans();
		list3=biz.kemus();
		Integer p=1;
		String ps=request.getParameter("sp");
		if(ps!=null){
			p=Integer.parseInt(ps.trim());
		};		
		pb=biz.fenye(p);
		
			return "notjieshu";
	
		
		
		

	}
	
	
	
	
	
	
	
	
	public List<Shiti> getList5() {
		return list5;
	}
	public void setList5(List<Shiti> list5) {
		this.list5 = list5;
	}
	public List<Shijuan> getList2() {
		return list2;
	}
	public void setList2(List<Shijuan> list2) {
		this.list2 = list2;
	}
	public Shijuan getShijuan() {
		return shijuan;
	}
	public void setShijuan(Shijuan shijuan) {
		this.shijuan = shijuan;
	}
	
	public List<Kemu> getList3() {
		return list3;
	}
	public void setList3(List<Kemu> list3) {
		this.list3 = list3;
	}
	public List<Jieduan> getList4() {
		return list4;
	}
	public void setList4(List<Jieduan> list4) {
		this.list4 = list4;
	}
	public List<Fangxiang> getList() {
		return list;
	}
	public void setList(List<Fangxiang> list) {
		this.list = list;
	}
	public PageBean getPb() {
		return pb;
	}
	public void setPb(PageBean pb) {
		this.pb = pb;
	}
	public List<Clases> getList6() {
		return list6;
	}
	public void setList6(List<Clases> list6) {
		this.list6 = list6;
	}
	public Shijuanbiz getBiz() {
		return biz;
	}
	public void setBiz(Shijuanbiz biz) {
		this.biz = biz;
	}
	public int getJid() {
		return jid;
	}
	public void setJid(int jid) {
		this.jid = jid;
	}
	public String getJieshusj() {
		return jieshusj;
	}
	public void setJieshusj(String jieshusj) {
		this.jieshusj = jieshusj;
	}	
	
}
