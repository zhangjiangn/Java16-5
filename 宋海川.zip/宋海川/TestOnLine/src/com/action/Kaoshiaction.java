package com.action;

import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import tools.PageBean;

import com.bean.Clases;
import com.bean.Shijuan;
import com.bean.Shiti;
import com.bean.StrutsShiti;
import com.biz.Kaoshibiz;
import com.biz.impl.Kaoshibizimpl;

public class Kaoshiaction {
	private int sid;
	private List<Shijuan> list2;
	private Kaoshibiz biz=new Kaoshibizimpl();
	private List<Shiti> list3;
	private Shijuan shijuan;
	private PageBean pb=new PageBean();
	private Set<Shiti> set;
	private Shiti shiti;
	private int stid;
	private int sp;
	private int tid;
	private int jid;
	private StrutsShiti strutsshiti=new StrutsShiti();
	private String daan;
	private String[] da;
	private int ps;
	private String dantifen;
	private String zqdaan;
	private List<StrutsShiti> list;
	public Shiti getShiti() {
		return shiti;
	}
	public void setShiti(Shiti shiti) {
		this.shiti = shiti;
	}
	
	public String kaoshi(){
		System.out.println(jid);
		list2=biz.shijuan(jid);
	
		return "kaoshi";
	}
	public String kaishi(){
		shijuan=biz.shijian(jid);
		Set<Shiti> set=shijuan.getShitis();
		list=biz.panduan(stid,jid);
		if (list.isEmpty()) {
			strutsshiti.setJid(jid);
			for (Shiti shiti : set) {
				strutsshiti.setSid(stid);
				strutsshiti.setTid(shiti.getTid());
				strutsshiti.setZqdaan(shiti.getDaan());	
				biz.insertss(strutsshiti);	
			}
		
		}
		HttpServletRequest request=ServletActionContext.getRequest();
		Integer p=0;
		String ps=request.getParameter("sp");
		if(ps!=null){
			p=Integer.parseInt(ps.trim());
		};	
		list=biz.panduan(stid,jid);
		request.setAttribute("p", p);	
		shiti=biz.shiti(p, jid);
		return "kaishi";
		
	}
	public String xiaye() {
		HttpServletRequest request=ServletActionContext.getRequest();
		String dan="";
		if (daan!=null) {
			dan=daan;
			strutsshiti.setDaan(dan);
		} else if (da!=null) {
			for (String das : da) {
				dan+=das+"";

		}
			strutsshiti.setDaan(dan);	}
		int id=Integer.parseInt(request.getParameter("skjid"));
		strutsshiti.setJid(id);
		strutsshiti.setSid(sid);
		strutsshiti.setTid(tid);
		strutsshiti.setDantifen(dantifen);
		strutsshiti.setZqdaan(zqdaan);
		stid=strutsshiti.getSid();
		shijuan=biz.shijian(strutsshiti.getJid());	
		list=biz.panduan(sid,id);
		if (list.isEmpty()) {
			biz.insertss(strutsshiti);
		} else {
			if (dan!="") {
			int s=biz.updatess(sid, tid, id,dan, zqdaan, dantifen);
	
			}
		}
		Integer p=1;
		if(sp!=0){
			p=sp;
		};
			int s=0;
		try {
			shiti=biz.shiti(p, id);
			request.setAttribute("p", p);	
		} catch (Exception e) {
			// TODO: handle exception
			s=1;
		}
		if (s==0) {
			return "xiaye";
		} else {
			return "notxiaye";
		}
		
		
	}
	public String shangti() {
		HttpServletRequest request=ServletActionContext.getRequest();
		String dan=null;
		if (daan!=null) {
			dan=daan;
			strutsshiti.setDaan(dan);
		} else if (da!=null) {
			for (String das : da) {
				dan=das+",";
		strutsshiti.setDaan(dan);
		}
		}
		int id=Integer.parseInt(request.getParameter("skjid"));
		strutsshiti.setJid(id);
		strutsshiti.setSid(sid);
		strutsshiti.setTid(tid);
		strutsshiti.setDantifen(dantifen);
		strutsshiti.setZqdaan(zqdaan);
		stid=strutsshiti.getSid();
		shijuan=biz.shijian(strutsshiti.getJid());	
		list=biz.panduan(sid,id);
		
		if (list.isEmpty()) {
			biz.insertss(strutsshiti);
		} else {
			if (dan!=null) {
				int s=biz.updatess(sid, tid, id, dan, zqdaan, dantifen);
			}
		}
		System.out.println(sp);
		Integer p=0;
		if(sp!=0){
			p=(sp-1);
		};
		set=shijuan.getShitis();	
		shiti=biz.shiti(p, id);
			p=p-1;
		request.setAttribute("p", p);	
		return "shangti";
	}
	public String jiaojuan(){
		HttpServletRequest request=ServletActionContext.getRequest();
		String dan=" ";
		if (daan!=null) {
			dan=daan;
			strutsshiti.setDaan(dan);
		} else if (da!=null) {
			for (String das : da) {
				dan+=das+"";	
		}
			strutsshiti.setDaan(dan);}
		int id=Integer.parseInt(request.getParameter("skjid"));
		if (dan!=" ") {
			biz.updatess(sid, tid, id, dan, zqdaan, dantifen);	
		}
		list2=biz.shijuan(jid);
		return "jiaojuan";
	}
	
	
	
	
	public int getSp() {
		return sp;
	}
	public void setSp(int sp) {
		this.sp = sp;
	}
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public int getJid() {
		return jid;
	}
	public void setJid(int jid) {
		this.jid = jid;
	}
	public StrutsShiti getStrutsshiti() {
		return strutsshiti;
	}
	public void setStrutsshiti(StrutsShiti strutsshiti) {
		this.strutsshiti = strutsshiti;
	}
	public String getDaan() {
		return daan;
	}
	public void setDaan(String daan) {
		this.daan = daan;
	}
	public List<Shijuan> getList2() {
		return list2;
	}
	public void setList2(List<Shijuan> list2) {
		this.list2 = list2;
	}
	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public List<Shiti> getList3() {
		return list3;
	}
	public void setList3(List<Shiti> list3) {
		this.list3 = list3;
	}
	public Shijuan getShijuan() {
		return shijuan;
	}
	public void setShijuan(Shijuan shijuan) {
		this.shijuan = shijuan;
	}
	public PageBean getPb() {
		return pb;
	}
	public void setPb(PageBean pb) {
		this.pb = pb;
	}
	public Set<Shiti> getSet() {
		return set;
	}
	public void setSet(Set<Shiti> set) {
		this.set = set;
	}
	public int getStid() {
		return stid;
	}
	public void setStid(int stid) {
		this.stid = stid;
	}
	public int getPs() {
		return ps;
	}
	public void setPs(int ps) {
		this.ps = ps;
	}
	public String[] getDa() {
		return da;
	}
	public void setDa(String[] da) {
		this.da = da;
	}
	public String getDantifen() {
		return dantifen;
	}
	public void setDantifen(String dantifen) {
		this.dantifen = dantifen;
	}
	public String getZqdaan() {
		return zqdaan;
	}
	public void setZqdaan(String zqdaan) {
		this.zqdaan = zqdaan;
	}
	public List<StrutsShiti> getList() {
		return list;
	}
	public void setList(List<StrutsShiti> list) {
		this.list = list;
	}
	
}
