package com.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.bean.Emp;
import com.bean.Struts;
import com.biz.Loginbiz;
import com.biz.impl.Loginbizimpl;
import com.dao.Logindao;



public class Loginaction {
	public Loginbiz biz=new Loginbizimpl();
	private Struts struts=new Struts();
	private Emp emp=new Emp();
	public String login() {
		HttpServletRequest request=ServletActionContext.getRequest();
		String sname=request.getParameter("sname");
		String spwd=request.getParameter("spwd");
		int role=Integer.parseInt(request.getParameter("role"));
	
		HttpSession session=ServletActionContext.getRequest().getSession();
		switch (role) {
			case 1:{
				struts=biz.Logins(sname, spwd);
	
				break;
				}
			case 2:{
				
				emp=biz.login(sname, spwd);
			
				break;
				}
			case 3:{
				emp=biz.login(sname, spwd);
				break;		
				}
			}
		if (struts.getSname()==null&&emp.getUname()==null) {
			
		return "notlogin";
		} else {
			session.setAttribute("role", role);
			session.setAttribute("stu", struts);
			session.setAttribute("emp", emp);
		return "login";
		} 
	}
		public Loginbiz getBiz() {
			return biz;
		}
		public void setBiz(Loginbiz biz) {
			this.biz = biz;
		}
		public Struts getStruts() {
			return struts;
		}
		public void setStruts(Struts struts) {
			this.struts = struts;
		}
		public Emp getEmp() {
			return emp;
		}
		public void setEmp(Emp emp) {
			this.emp = emp;
		}
		
}
