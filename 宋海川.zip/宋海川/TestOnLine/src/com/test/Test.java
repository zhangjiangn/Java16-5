package com.test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tools.PageBean;

import com.bean.Shijuan;
import com.bean.Shiti;
import com.bean.StrutsShiti;
import com.biz.Chengjibiz;
import com.biz.Kaoshibiz;
import com.biz.impl.Chengjibizimpl;
import com.biz.impl.Kaoshibizimpl;
import com.dao.HibernateSessionFactory;
import com.util.PageBeans;




public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Session session=HibernateSessionFactory.getSession();
		Kaoshibiz biz=new Kaoshibizimpl();
		StrutsShiti strutsShiti=new StrutsShiti();
	
		Shijuan shijuan=biz.shijian(2);
		Set<Shiti> set=shijuan.getShitis();
		strutsShiti.setSid(1);
		for (Shiti shiti : set) {
			strutsShiti.setTid(shiti.getTid());
			strutsShiti.setZqdaan(shiti.getDaan());
			
			session.beginTransaction();
			session.save(strutsShiti);
			session.flush();
			session.clear();

			session.beginTransaction().commit();
		}
		
	}
}
	

