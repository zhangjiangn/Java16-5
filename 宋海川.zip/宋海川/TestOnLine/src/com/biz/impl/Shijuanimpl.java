package com.biz.impl;

import java.util.List;

import tools.PageBean;

import com.bean.Clases;
import com.bean.Fangxiang;
import com.bean.Jieduan;
import com.bean.Kemu;
import com.bean.Shijuan;
import com.bean.Shiti;
import com.biz.Shijuanbiz;
import com.dao.Shijuandao;
import com.dao.impl.Shijuandaoimpl;

public class Shijuanimpl implements Shijuanbiz {
	public Shijuandao dao=new Shijuandaoimpl();
	public List<Fangxiang> fangxiangs() {
		// TODO Auto-generated method stub
		return dao.fangxiangs();
	}

	public PageBean fenye(int p) {
		// TODO Auto-generated method stub
		return dao.fenye(p);
	}

	public int insert(Shijuan shijuan ,int tid) {
		// TODO Auto-generated method stub
		return dao.insert(shijuan, tid);
	}

	public List<Jieduan> jieduans() {
		// TODO Auto-generated method stub
		return dao.jieduans();
	}

	public List<Kemu> kemus() {
		// TODO Auto-generated method stub
		return dao.kemus();
	}

	public Shijuan select(int jid) {
		// TODO Auto-generated method stub
		return dao.select(jid);
	}

	public List<Shijuan> shijuan(String kmname, String jiedname, String fanxname,
			String sjztai, String sjlie) {
		// TODO Auto-generated method stub
		return dao.shijuan(kmname, jiedname, fanxname, sjztai,sjlie);
	}

	public List<Shiti> selectshiti(int kid) {
		// TODO Auto-generated method stub
		return dao.selectshiti(kid);
	}

	public int selectke(String name) {
		// TODO Auto-generated method stub
		return dao.selectke(name);
	}

	public List<Shiti> danjiandan() {
		// TODO Auto-generated method stub
		return dao.danjiandan();
	}

	public List<Shiti> dankunnan() {
		// TODO Auto-generated method stub
		return dao.dankunnan();
	}

	public List<Shiti> danyiban() {
		// TODO Auto-generated method stub
		return dao.danyiban();
	}

	public List<Shiti> fujiandan() {
		// TODO Auto-generated method stub
		return dao.fujiandan();
	}

	public List<Shiti> fukunnan() {
		// TODO Auto-generated method stub
		return dao.fukunnan();
	}

	public List<Shiti> fuyiban() {
		// TODO Auto-generated method stub
		return dao.fuyiban();
	}

	public List<Clases> banji() {
		// TODO Auto-generated method stub
		return dao.banji();
	}

	

	public int xiu(String className, int sjid) {
		// TODO Auto-generated method stub
		return dao.xiu(className, sjid);
	}

	public int gai(int sjid, String sjlie,String ban) {
		// TODO Auto-generated method stub
		return dao.gai(sjid, sjlie,ban);
	}

	public Shijuan chakan(int jid) {
		// TODO Auto-generated method stub
		return dao.chakan(jid);
	}

	public String zhong(String cid) {
		// TODO Auto-generated method stub
		return dao.zhong(cid);
	}

	public int jieshu(int jid, String jieshusj) {
		// TODO Auto-generated method stub
		return dao.jieshu(jid, jieshusj);
	}

}
