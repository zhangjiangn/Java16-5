package com.biz.impl;

import java.util.List;

import com.bean.Emp;
import com.bean.Struts;
import com.biz.Loginbiz;
import com.dao.Logindao;
import com.dao.impl.Logindaoimpl;

public class Loginbizimpl implements Loginbiz {
	
	public Logindao dao=new Logindaoimpl();
	public Struts Logins(String sname, String spwd) {
		// TODO Auto-generated method stub
		return dao.Logins(sname, spwd);
	}

	public Emp login(String sname, String spwd) {
		// TODO Auto-generated method stub
		return dao.login(sname, spwd);
	}

}
