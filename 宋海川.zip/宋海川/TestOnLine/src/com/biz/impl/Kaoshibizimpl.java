package com.biz.impl;

import java.util.List;

import tools.PageBean;

import com.bean.Clases;
import com.bean.Shijuan;
import com.bean.Shiti;
import com.bean.StrutsShiti;
import com.biz.Kaoshibiz;
import com.dao.Kaoshidao;
import com.dao.impl.Kaoshidaoimpl;
import com.util.PageBeans;

public class Kaoshibizimpl implements Kaoshibiz{
	public Kaoshidao dao=new Kaoshidaoimpl();
	
	public List<Shijuan> shijuan(int jid) {
		// TODO Auto-generated method stub
		return dao.shijuan(jid);
	}

	public Shijuan shijian(int jid) {
		// TODO Auto-generated method stub
		return dao.shijian(jid);
	}

	public Shiti shiti(int p, int jid) {
		// TODO Auto-generated method stub
		return dao.shiti(p, jid);
	}

	public int insertss(StrutsShiti strutsShiti) {
		// TODO Auto-generated method stub
		return dao.insertss(strutsShiti);
	}

	public List<StrutsShiti> panduan(int sid,int jid) {
		// TODO Auto-generated method stub
		return dao.panduan(sid,jid);
	}

	public int updatess(int sid,int tid,int jid,String daan,String zqdaan,String dantifen){
		// TODO Auto-generated method stub
		return dao.updatess(sid, tid, jid, daan, zqdaan, dantifen);
	}

	public List<StrutsShiti> chankang(int sid) {
		// TODO Auto-generated method stub
		return dao.chankang(sid);
	}

	public int update(int sid, String zqdaan) {
		// TODO Auto-generated method stub
		return dao.update(sid, zqdaan);
	}


}
