package com.biz;

import java.util.List;

import com.bean.Emp;
import com.bean.Struts;


public interface Loginbiz {
	public Emp login(String sname,String spwd); 
	public Struts Logins(String sname,String spwd);
	
}
