package com.biz;

import java.util.List;

import tools.PageBean;

import com.bean.Clases;
import com.bean.Fangxiang;
import com.bean.Jieduan;
import com.bean.Kemu;
import com.bean.Shijuan;
import com.bean.Shiti;

public interface Shijuanbiz {
	public List<Shijuan> shijuan(String kmname,String jiedname,String fanxname,String sjztai,String sjlie);
	public List<Kemu> kemus();
	public List<Jieduan> jieduans();
	public List<Fangxiang> fangxiangs();
	public PageBean fenye(int p);
	public int insert(Shijuan shijuan,int tid);
	public Shijuan select(int jid);
	public List<Shiti> selectshiti(int kid);
	public int selectke(String name);
	public List<Shiti> danjiandan();
	public List<Shiti> danyiban();
	public List<Shiti> dankunnan();
	public List<Shiti> fujiandan();
	public List<Shiti> fuyiban();
	public List<Shiti> fukunnan();
	public List<Clases> banji();
	public int xiu(String className,int sjid);
	public int gai(int sjid,String sjlie,String ban);
	public Shijuan chakan(int jid);
	public String zhong(String cid);
	public int jieshu(int jid,String jieshusj);
}
