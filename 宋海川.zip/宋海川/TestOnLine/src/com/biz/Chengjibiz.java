package com.biz;

import java.util.List;

import tools.PageBean;

import com.bean.Clases;
import com.bean.Fangxiang;
import com.bean.Jieduan;
import com.bean.Kemu;
import com.bean.Shijuan;
import com.bean.Shiti;
import com.bean.Struts;
import com.bean.StrutsShiti;

public interface Chengjibiz {
	public List<Kemu> kemus();
	public List<Jieduan> jieduans();
	public List<Fangxiang> fangxiangs();
	public PageBean fenye(int p);
	public int strut(int tid);
	public int shiti(int tid);
	public List<Struts> struts(int sid);
	public Shijuan Shijuan(int jid);
	public List<Clases> list();
	public List<StrutsShiti> strutsShitis(int jid);
	public Shijuan shijuans(int jid);
	public Struts stru(int sid);
	public Shiti shi(int sid);
	public List<Shijuan> shijuan(String kmname, String jiedname, String fanxname,
			 String sjlie);
	public int sid(String sname);
	public List<StrutsShiti> strutsshitis(int jid,int sid);
	
}
