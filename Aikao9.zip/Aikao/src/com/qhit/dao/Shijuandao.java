package com.qhit.dao;

import java.util.List;

import org.hibernate.Session;

import com.qhit.bean.Fangxiang;
import com.qhit.bean.Jieduan;
import com.qhit.bean.Kemu;
import com.qhit.bean.Shijuan;
import com.qhit.bean.Shiti;

public interface Shijuandao {
	public  Session session=HibernateSessionFactory.getSession();
	 public  List<Fangxiang> selectfx();
	    public List<Jieduan> selectjd();
	    public List<Kemu> selectkm();
	    public List<Shijuan> selectsj();
	    public  List<Kemu> selectdankm(int fx,int jd);
}
