package com.qhit.dao;

import java.util.List;

import org.hibernate.Session;

import com.qhit.bean.Fangxiang;
import com.qhit.bean.Jieduan;
import com.qhit.bean.Kemu;
import com.qhit.bean.Shiti;
import com.qhit.util.PageBean;

public interface TiKudao {
	public Session session=HibernateSessionFactory.getSession();
	  public  List<Fangxiang> selectfx();
	    public List<Jieduan> selectjd();
	    public List<Kemu> selectkm();
	    public List<Kemu> flselect(int fid,int jid);
	    public PageBean selectst(int kmid,int p); 
	    public int updatest(Shiti shiti);
	    public int insertst(Shiti shiti);
	    public int count(int kmid);
	    public int selectkm(String kmname);
	    public Kemu selectmu(int kmid);
	    public Shiti selectdan(int stid);
}
