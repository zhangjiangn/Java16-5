package com.qhit.dao;

import org.hibernate.Session;

import com.qhit.bean.Student;
import com.qhit.bean.Users;

public interface Logindao {
	public Session session=HibernateSessionFactory.getSession();
    public Users loginuser(String name,String pwd);
    public Student loginstu(String name,String pwd);
}
