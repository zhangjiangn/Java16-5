package com.qhit.dao.impl;

import java.util.List;

import org.hibernate.Query;

import com.qhit.bean.Fangxiang;
import com.qhit.bean.Jieduan;
import com.qhit.bean.Kemu;
import com.qhit.bean.Shijuan;
import com.qhit.bean.Shiti;
import com.qhit.dao.Shijuandao;

public class ShijuandaoImpl implements Shijuandao {

	public List<Fangxiang> selectfx() {
		Query query=session.createQuery("select f from Fangxiang f");
		         List<Fangxiang> list=query.list();
		return list;
	}


	public List<Jieduan> selectjd() {
		String hql="from Jieduan";
		       List<Jieduan> list= session.createQuery(hql).list();
		return list;
	}


	@Override
	public List<Kemu> selectkm() {
		String hql="from Kemu";
	       List<Kemu> list= session.createQuery(hql).list();
			return list;
	}


	@Override
	public List<Shijuan> selectsj() {
		String hql="from Shijuan";
	       List<Shijuan> list= session.createQuery(hql).list();
			return list;
	}


	@Override
	public List<Kemu> selectdankm(int fx, int jd) {
		String hql="select * from Kemu k where k.fxid=? and k.jdid=?";
		
	       List<Kemu> list= session.createQuery(hql).list();
			return list;
	}


}
