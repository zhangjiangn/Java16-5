package com.qhit.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.qhit.bean.Fangxiang;
import com.qhit.bean.Jieduan;
import com.qhit.bean.Kemu;
import com.qhit.bean.Shiti;
import com.qhit.dao.TiKudao;
import com.qhit.util.PageBean;

public class TiKudaoImpl implements TiKudao{

	
	public List<Fangxiang> selectfx() {
		Query query=session.createQuery("select f from Fangxiang f");
		         List<Fangxiang> list=query.list();
		return list;
	}


	public List<Jieduan> selectjd() {
		String hql="from Jieduan";
		       List<Jieduan> list= session.createQuery(hql).list();
		return list;
	}


	@Override
	public List<Kemu> selectkm() {
		String hql="from Kemu";
	       List<Kemu> list= session.createQuery(hql).list();
			return list;
	}


	@Override
	public List<Kemu> flselect(int fid,int jid) {
		String hql="select k from Kemu k where k.fangxiang.fxid=:fid and k.jieduan.jdid=:jid";
		Query query=session.createQuery(hql);
		query.setInteger("fid",fid);
		query.setInteger("jid", jid);
		return  query.list();
	}


	@Override
	public int insertst(Shiti shiti) {
		int i=0;
		try {
			session.beginTransaction();
			session.save(shiti);
			session.beginTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			i=1;
		}
		return i;
	}
	public PageBean selectst(int kmid, int p) {
		PageBean pb=new PageBean();
		 Query query=session.createQuery("from Shiti s where s.kemu.kmid=?");
		 query.setInteger(0, kmid);
		int count= query.list().size();
		  pb.setCount(count);
		     pb.setPagesize(5);
		     pb.setP(p);
		     int s=pb.getPagesize();
		     query.setFirstResult((pb.getP()-1)*s)
				.setMaxResults(s);
		     List<Shiti> list=query.list();
		pb.setData(list);
		return pb;
	}


	@Override
	public int updatest(Shiti shiti) {
		int i=0;
		try {
			session.beginTransaction();
			session.update(shiti);
			session.beginTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			i=1;
		}
		return i;
	}


	@Override
	public int count(int kmid) {
		String hql="select  count(s)  from Shiti s where s.kemu.kmid=?";
		Query query=session.createQuery(hql);
		query.setInteger(0,kmid);
		return Integer.parseInt(query.list().get(0).toString());
	}

	@Override
	public int selectkm(String kmname) {
		int i=0;
		Criteria criteria=session.createCriteria(Kemu.class).add(Restrictions.eq("kmname", kmname));
		List<Kemu> list=criteria.list();
		for (Kemu kemu : list) {
			i=kemu.getKmid();
		}
		return i;
	}


	@Override
	public Kemu selectmu(int kmid) {
		// TODO Auto-generated method stub
		Kemu kemu=(Kemu) session.get(Kemu.class, kmid);
		return kemu;
	}
	@Override
	public Shiti selectdan(int stid) {
		Shiti shiti=(Shiti) session.get(Shiti.class, stid);
		return shiti;
	}

}
