package com.qhit.dao.impl;

import org.hibernate.Query;

import com.qhit.bean.Student;
import com.qhit.bean.Users;
import com.qhit.dao.Logindao;

public class Logindaoimpl implements Logindao{
 
	public Student loginstu(String name, String pwd) {
	  Query query=session.createQuery("select s from Student s where s.sname=:name and s.spwd=:pwd");
	  query.setString("name", name);
	  query.setString("pwd",pwd);
	  return (Student) query.uniqueResult();
	}

	public Users loginuser(String name, String pwd) {
		  Query query=session.createQuery("select u from Users u where u.uname=:name and u.upwd=:pwd");
		  query.setString("name", name);
		  query.setString("pwd",pwd);
		  return (Users) query.uniqueResult();
	}
      
}
