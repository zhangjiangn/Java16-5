package com.qhit.biz;
import com.qhit.bean.Student;
import com.qhit.bean.Users;

public interface Loginbiz {
      public Users loginuser(String name,String pwd);
      public Student loginstu(String name,String pwd);
}
