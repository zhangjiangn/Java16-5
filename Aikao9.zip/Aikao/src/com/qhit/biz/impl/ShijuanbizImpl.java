package com.qhit.biz.impl;

import java.util.List;

import com.qhit.bean.Fangxiang;
import com.qhit.bean.Jieduan;
import com.qhit.bean.Kemu;
import com.qhit.bean.Shijuan;
import com.qhit.bean.Shiti;
import com.qhit.biz.Shijuanbiz;
import com.qhit.dao.Shijuandao;
import com.qhit.dao.impl.ShijuandaoImpl;

public class ShijuanbizImpl implements Shijuanbiz{
          Shijuandao      sjdao=new    ShijuandaoImpl();          
	@Override
	public List<Fangxiang> selectfx() {
		// TODO Auto-generated method stub
		return sjdao.selectfx();
	}

	@Override
	public List<Jieduan> selectjd() {
		// TODO Auto-generated method stub
		return sjdao.selectjd();
	}

	@Override
	public List<Kemu> selectkm() {
		// TODO Auto-generated method stub
		return sjdao.selectkm();
	}

	@Override
	public List<Shijuan> selectsj() {
		// TODO Auto-generated method stub
		return sjdao.selectsj();
	}

	@Override
	public List<Kemu> selectdankm(int fx, int jd) {
		// TODO Auto-generated method stub
		return null;
	}


}
