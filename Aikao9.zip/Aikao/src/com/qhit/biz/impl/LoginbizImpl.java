package com.qhit.biz.impl;

import com.qhit.bean.Student;
import com.qhit.bean.Users;
import com.qhit.biz.Loginbiz;
import com.qhit.dao.Logindao;
import com.qhit.dao.impl.Logindaoimpl;

public class LoginbizImpl implements Loginbiz {
	Logindao dao=new Logindaoimpl();
	public Users loginuser(String name, String pwd) {
		// TODO Auto-generated method stub
		return dao.loginuser(name, pwd);
	}
	public Student loginstu(String name, String pwd) {
		// TODO Auto-generated method stub
		return dao.loginstu(name, pwd) ;
	}

}
