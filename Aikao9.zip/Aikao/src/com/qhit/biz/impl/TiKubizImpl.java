package com.qhit.biz.impl;

import java.util.List;

import com.qhit.bean.Fangxiang;
import com.qhit.bean.Jieduan;
import com.qhit.bean.Kemu;
import com.qhit.bean.Shiti;
import com.qhit.biz.TiKubiz;
import com.qhit.dao.TiKudao;
import com.qhit.dao.impl.TiKudaoImpl;
import com.qhit.util.PageBean;

public class TiKubizImpl implements TiKubiz {
    public TiKudao tkdao=new TiKudaoImpl();
	
	public List<Fangxiang> selectfx() {
		// TODO Auto-generated method stub
		return tkdao.selectfx();
	}

	@Override
	public List<Jieduan> selectjd() {
		// TODO Auto-generated method stub
		return tkdao.selectjd();
	}

	@Override
	public List<Kemu> selectkm() {
		// TODO Auto-generated method stub
		return tkdao.selectkm();
	}
	@Override
	public List<Kemu> flselect(int fid, int jid) {
		// TODO Auto-generated method stub
		return tkdao.flselect(fid, jid);
	}
	public int insertst() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public PageBean selectst(int kmid, int p) {
		// TODO Auto-generated method stub
		return tkdao.selectst(kmid, p);
	}
	public int count(int kmid) {
		// TODO Auto-generated method stub
		return tkdao.count(kmid);
	}

	@Override
	public int insertst(Shiti shiti) {
		// TODO Auto-generated method stub
		return tkdao.insertst(shiti);
	}

	@Override
	public int updatest(Shiti shiti) {
		// TODO Auto-generated method stub
		return tkdao.updatest(shiti);
	}

	@Override
	public int deletest(int stid) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int selectkm(String kmname) {
		// TODO Auto-generated method stub
		return tkdao.selectkm(kmname);
	}

	@Override
	public Kemu selectmu(int kmid) {
		// TODO Auto-generated method stub
		return tkdao.selectmu(kmid);
	}

	@Override
	public Shiti selectdan(int stid) {
		// TODO Auto-generated method stub
		return tkdao.selectdan(stid);
	}

}
