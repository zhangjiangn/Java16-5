package com.qhit.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Kemu entity. @author MyEclipse Persistence Tools
 */

public class Kemu implements java.io.Serializable {

	// Fields

	private Integer kmid;
	private Fangxiang fangxiang;
	private Jieduan jieduan;
	private String kmname;
	private Set shijuans = new HashSet(0);
	private Set shitis = new HashSet(0);

	// Constructors

	/** default constructor */
	public Kemu() {
	}

	/** minimal constructor */
	public Kemu(Integer kmid, Fangxiang fangxiang, Jieduan jieduan,
			String kmname) {
		this.kmid = kmid;
		this.fangxiang = fangxiang;
		this.jieduan = jieduan;
		this.kmname = kmname;
	}

	/** full constructor */
	public Kemu(Integer kmid, Fangxiang fangxiang, Jieduan jieduan,
			String kmname, Set shijuans, Set shitis) {
		this.kmid = kmid;
		this.fangxiang = fangxiang;
		this.jieduan = jieduan;
		this.kmname = kmname;
		this.shijuans = shijuans;
		this.shitis = shitis;
	}

	// Property accessors

	public Integer getKmid() {
		return this.kmid;
	}

	public void setKmid(Integer kmid) {
		this.kmid = kmid;
	}

	public Fangxiang getFangxiang() {
		return this.fangxiang;
	}

	public void setFangxiang(Fangxiang fangxiang) {
		this.fangxiang = fangxiang;
	}

	public Jieduan getJieduan() {
		return this.jieduan;
	}

	public void setJieduan(Jieduan jieduan) {
		this.jieduan = jieduan;
	}

	public String getKmname() {
		return this.kmname;
	}

	public void setKmname(String kmname) {
		this.kmname = kmname;
	}

	public Set getShijuans() {
		return this.shijuans;
	}

	public void setShijuans(Set shijuans) {
		this.shijuans = shijuans;
	}

	public Set getShitis() {
		return this.shitis;
	}

	public void setShitis(Set shitis) {
		this.shitis = shitis;
	}

}