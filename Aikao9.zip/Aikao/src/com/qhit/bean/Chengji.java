package com.qhit.bean;

/**
 * Chengji entity. @author MyEclipse Persistence Tools
 */

public class Chengji implements java.io.Serializable {

	// Fields

	private Integer cjid;
	private Student student;
	private Shijuan shijuan;
	private String kstime;
	private String jstime;

	// Constructors

	/** default constructor */
	public Chengji() {
	}

	/** minimal constructor */
	public Chengji(Integer cjid, Student student, Shijuan shijuan) {
		this.cjid = cjid;
		this.student = student;
		this.shijuan = shijuan;
	}

	/** full constructor */
	public Chengji(Integer cjid, Student student, Shijuan shijuan,
			String kstime, String jstime) {
		this.cjid = cjid;
		this.student = student;
		this.shijuan = shijuan;
		this.kstime = kstime;
		this.jstime = jstime;
	}

	// Property accessors

	public Integer getCjid() {
		return this.cjid;
	}

	public void setCjid(Integer cjid) {
		this.cjid = cjid;
	}

	public Student getStudent() {
		return this.student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Shijuan getShijuan() {
		return this.shijuan;
	}

	public void setShijuan(Shijuan shijuan) {
		this.shijuan = shijuan;
	}

	public String getKstime() {
		return this.kstime;
	}

	public void setKstime(String kstime) {
		this.kstime = kstime;
	}

	public String getJstime() {
		return this.jstime;
	}

	public void setJstime(String jstime) {
		this.jstime = jstime;
	}

}