package com.qhit.bean;

/**
 * XueshengShiti entity. @author MyEclipse Persistence Tools
 */

public class XueshengShiti implements java.io.Serializable {

	// Fields

	private Integer stuid;
	private Shijuan shijuan;
	private Shiti shiti;
	private Integer sjid;
	private Integer stid;
	private String xsdaan;

	// Constructors

	/** default constructor */
	public XueshengShiti() {
	}

	/** minimal constructor */
	public XueshengShiti(Integer stuid, Shijuan shijuan, Shiti shiti,
			Integer sjid, Integer stid) {
		this.stuid = stuid;
		this.shijuan = shijuan;
		this.shiti = shiti;
		this.sjid = sjid;
		this.stid = stid;
	}

	/** full constructor */
	public XueshengShiti(Integer stuid, Shijuan shijuan, Shiti shiti,
			Integer sjid, Integer stid, String xsdaan) {
		this.stuid = stuid;
		this.shijuan = shijuan;
		this.shiti = shiti;
		this.sjid = sjid;
		this.stid = stid;
		this.xsdaan = xsdaan;
	}

	// Property accessors

	public Integer getStuid() {
		return this.stuid;
	}

	public void setStuid(Integer stuid) {
		this.stuid = stuid;
	}

	public Shijuan getShijuan() {
		return this.shijuan;
	}

	public void setShijuan(Shijuan shijuan) {
		this.shijuan = shijuan;
	}

	public Shiti getShiti() {
		return this.shiti;
	}

	public void setShiti(Shiti shiti) {
		this.shiti = shiti;
	}

	public Integer getSjid() {
		return this.sjid;
	}

	public void setSjid(Integer sjid) {
		this.sjid = sjid;
	}

	public Integer getStid() {
		return this.stid;
	}

	public void setStid(Integer stid) {
		this.stid = stid;
	}

	public String getXsdaan() {
		return this.xsdaan;
	}

	public void setXsdaan(String xsdaan) {
		this.xsdaan = xsdaan;
	}

}