package com.qhit.bean;

/**
 * ShijuanShiti entity. @author MyEclipse Persistence Tools
 */

public class ShijuanShiti implements java.io.Serializable {

	// Fields

	private Integer ssid;
	private Shijuan shijuan;
	private Shiti shiti;

	// Constructors

	/** default constructor */
	public ShijuanShiti() {
	}

	/** full constructor */
	public ShijuanShiti(Integer ssid, Shijuan shijuan, Shiti shiti) {
		this.ssid = ssid;
		this.shijuan = shijuan;
		this.shiti = shiti;
	}

	// Property accessors

	public Integer getSsid() {
		return this.ssid;
	}

	public void setSsid(Integer ssid) {
		this.ssid = ssid;
	}

	public Shijuan getShijuan() {
		return this.shijuan;
	}

	public void setShijuan(Shijuan shijuan) {
		this.shijuan = shijuan;
	}

	public Shiti getShiti() {
		return this.shiti;
	}

	public void setShiti(Shiti shiti) {
		this.shiti = shiti;
	}

}