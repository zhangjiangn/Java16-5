package com.qhit.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Jieduan entity. @author MyEclipse Persistence Tools
 */

public class Jieduan implements java.io.Serializable {

	// Fields

	private Integer jdid;
	private String jdname;
	private Set kemus = new HashSet(0);

	// Constructors

	/** default constructor */
	public Jieduan() {
	}

	/** minimal constructor */
	public Jieduan(Integer jdid, String jdname) {
		this.jdid = jdid;
		this.jdname = jdname;
	}

	/** full constructor */
	public Jieduan(Integer jdid, String jdname, Set kemus) {
		this.jdid = jdid;
		this.jdname = jdname;
		this.kemus = kemus;
	}

	// Property accessors

	public Integer getJdid() {
		return this.jdid;
	}

	public void setJdid(Integer jdid) {
		this.jdid = jdid;
	}

	public String getJdname() {
		return this.jdname;
	}

	public void setJdname(String jdname) {
		this.jdname = jdname;
	}

	public Set getKemus() {
		return this.kemus;
	}

	public void setKemus(Set kemus) {
		this.kemus = kemus;
	}

}