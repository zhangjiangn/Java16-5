package com.qhit.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Classes entity. @author MyEclipse Persistence Tools
 */

public class Classes implements java.io.Serializable {

	// Fields

	private Integer classid;
	private Fangxiang fangxiang;
	private String claxuhao;
	private String claname;
	private String tname;
	private String jname;
	private String kaidata;
	private String zt;
	private Set shijuans = new HashSet(0);
	private Set students = new HashSet(0);

	// Constructors

	/** default constructor */
	public Classes() {
	}

	/** minimal constructor */
	public Classes(Integer classid, Fangxiang fangxiang, String claxuhao,
			String claname, String kaidata, String zt) {
		this.classid = classid;
		this.fangxiang = fangxiang;
		this.claxuhao = claxuhao;
		this.claname = claname;
		this.kaidata = kaidata;
		this.zt = zt;
	}

	/** full constructor */
	public Classes(Integer classid, Fangxiang fangxiang, String claxuhao,
			String claname, String tname, String jname, String kaidata,
			String zt, Set shijuans, Set students) {
		this.classid = classid;
		this.fangxiang = fangxiang;
		this.claxuhao = claxuhao;
		this.claname = claname;
		this.tname = tname;
		this.jname = jname;
		this.kaidata = kaidata;
		this.zt = zt;
		this.shijuans = shijuans;
		this.students = students;
	}

	// Property accessors

	public Integer getClassid() {
		return this.classid;
	}

	public void setClassid(Integer classid) {
		this.classid = classid;
	}

	public Fangxiang getFangxiang() {
		return this.fangxiang;
	}

	public void setFangxiang(Fangxiang fangxiang) {
		this.fangxiang = fangxiang;
	}

	public String getClaxuhao() {
		return this.claxuhao;
	}

	public void setClaxuhao(String claxuhao) {
		this.claxuhao = claxuhao;
	}

	public String getClaname() {
		return this.claname;
	}

	public void setClaname(String claname) {
		this.claname = claname;
	}

	public String getTname() {
		return this.tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

	public String getJname() {
		return this.jname;
	}

	public void setJname(String jname) {
		this.jname = jname;
	}

	public String getKaidata() {
		return this.kaidata;
	}

	public void setKaidata(String kaidata) {
		this.kaidata = kaidata;
	}

	public String getZt() {
		return this.zt;
	}

	public void setZt(String zt) {
		this.zt = zt;
	}

	public Set getShijuans() {
		return this.shijuans;
	}

	public void setShijuans(Set shijuans) {
		this.shijuans = shijuans;
	}

	public Set getStudents() {
		return this.students;
	}

	public void setStudents(Set students) {
		this.students = students;
	}

}