package com.qhit.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Shijuan entity. @author MyEclipse Persistence Tools
 */

public class Shijuan implements java.io.Serializable {

	// Fields

	private Integer sjid;
	private Kemu kemu;
	private Classes classes;
	private String sjlx;
	private String biaoti;
	private String kstime;
	private String zt;
	private Set shijuanShitis = new HashSet(0);
	private Set xueshengShitis = new HashSet(0);
	private Set chengjis = new HashSet(0);

	// Constructors

	/** default constructor */
	public Shijuan() {
	}

	/** minimal constructor */
	public Shijuan(Integer sjid, Classes classes, String zt) {
		this.sjid = sjid;
		this.classes = classes;
		this.zt = zt;
	}

	/** full constructor */
	public Shijuan(Integer sjid, Kemu kemu, Classes classes, String sjlx,
			String biaoti, String kstime, String zt, Set shijuanShitis,
			Set xueshengShitis, Set chengjis) {
		this.sjid = sjid;
		this.kemu = kemu;
		this.classes = classes;
		this.sjlx = sjlx;
		this.biaoti = biaoti;
		this.kstime = kstime;
		this.zt = zt;
		this.shijuanShitis = shijuanShitis;
		this.xueshengShitis = xueshengShitis;
		this.chengjis = chengjis;
	}

	// Property accessors

	public Integer getSjid() {
		return this.sjid;
	}

	public void setSjid(Integer sjid) {
		this.sjid = sjid;
	}

	public Kemu getKemu() {
		return this.kemu;
	}

	public void setKemu(Kemu kemu) {
		this.kemu = kemu;
	}

	public Classes getClasses() {
		return this.classes;
	}

	public void setClasses(Classes classes) {
		this.classes = classes;
	}

	public String getSjlx() {
		return this.sjlx;
	}

	public void setSjlx(String sjlx) {
		this.sjlx = sjlx;
	}

	public String getBiaoti() {
		return this.biaoti;
	}

	public void setBiaoti(String biaoti) {
		this.biaoti = biaoti;
	}

	public String getKstime() {
		return this.kstime;
	}

	public void setKstime(String kstime) {
		this.kstime = kstime;
	}

	public String getZt() {
		return this.zt;
	}

	public void setZt(String zt) {
		this.zt = zt;
	}

	public Set getShijuanShitis() {
		return this.shijuanShitis;
	}

	public void setShijuanShitis(Set shijuanShitis) {
		this.shijuanShitis = shijuanShitis;
	}

	public Set getXueshengShitis() {
		return this.xueshengShitis;
	}

	public void setXueshengShitis(Set xueshengShitis) {
		this.xueshengShitis = xueshengShitis;
	}

	public Set getChengjis() {
		return this.chengjis;
	}

	public void setChengjis(Set chengjis) {
		this.chengjis = chengjis;
	}

}