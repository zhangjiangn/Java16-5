package com.qhit.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Student entity. @author MyEclipse Persistence Tools
 */

public class Student implements java.io.Serializable {

	// Fields

	private Integer stuid;
	private Classes classes;
	private String stuno;
	private String name;
	private String sex;
	private String tel;
	private String sname;
	private String spwd;
	private String role;
	private Set chengjis = new HashSet(0);

	// Constructors

	/** default constructor */
	public Student() {
	}

	/** minimal constructor */
	public Student(Integer stuid, Classes classes, String stuno, String name,
			String sex, String tel, String sname, String spwd, String role) {
		this.stuid = stuid;
		this.classes = classes;
		this.stuno = stuno;
		this.name = name;
		this.sex = sex;
		this.tel = tel;
		this.sname = sname;
		this.spwd = spwd;
		this.role = role;
	}

	/** full constructor */
	public Student(Integer stuid, Classes classes, String stuno, String name,
			String sex, String tel, String sname, String spwd, String role,
			Set chengjis) {
		this.stuid = stuid;
		this.classes = classes;
		this.stuno = stuno;
		this.name = name;
		this.sex = sex;
		this.tel = tel;
		this.sname = sname;
		this.spwd = spwd;
		this.role = role;
		this.chengjis = chengjis;
	}

	// Property accessors

	public Integer getStuid() {
		return this.stuid;
	}

	public void setStuid(Integer stuid) {
		this.stuid = stuid;
	}

	public Classes getClasses() {
		return this.classes;
	}

	public void setClasses(Classes classes) {
		this.classes = classes;
	}

	public String getStuno() {
		return this.stuno;
	}

	public void setStuno(String stuno) {
		this.stuno = stuno;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSex() {
		return this.sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getTel() {
		return this.tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getSname() {
		return this.sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getSpwd() {
		return this.spwd;
	}

	public void setSpwd(String spwd) {
		this.spwd = spwd;
	}

	public String getRole() {
		return this.role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Set getChengjis() {
		return this.chengjis;
	}

	public void setChengjis(Set chengjis) {
		this.chengjis = chengjis;
	}

}