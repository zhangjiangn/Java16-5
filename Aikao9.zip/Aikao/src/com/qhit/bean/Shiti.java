package com.qhit.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Shiti entity. @author MyEclipse Persistence Tools
 */

public class Shiti implements java.io.Serializable {

	// Fields

	private Integer stid;
	private Kemu kemu;
	private String tmlx;
	private String tmxlx;
	private String ksbt;
	private String xxa;
	private String xxb;
	private String xxc;
	private String xxd;
	private String daan;
	private String nandu;
	private String dyzj;
	private Set xueshengShitis = new HashSet(0);
	private Set shijuanShitis = new HashSet(0);

	// Constructors

	/** default constructor */
	public Shiti() {
	}

	/** minimal constructor */
	public Shiti(Integer stid, Kemu kemu, String tmlx, String tmxlx) {
		this.stid = stid;
		this.kemu = kemu;
		this.tmlx = tmlx;
		this.tmxlx = tmxlx;
	}

	/** full constructor */
	public Shiti(Integer stid, Kemu kemu, String tmlx, String tmxlx,
			String ksbt, String xxa, String xxb, String xxc, String xxd,
			String daan, String nandu, String dyzj, Set xueshengShitis,
			Set shijuanShitis) {
		this.stid = stid;
		this.kemu = kemu;
		this.tmlx = tmlx;
		this.tmxlx = tmxlx;
		this.ksbt = ksbt;
		this.xxa = xxa;
		this.xxb = xxb;
		this.xxc = xxc;
		this.xxd = xxd;
		this.daan = daan;
		this.nandu = nandu;
		this.dyzj = dyzj;
		this.xueshengShitis = xueshengShitis;
		this.shijuanShitis = shijuanShitis;
	}

	// Property accessors

	public Integer getStid() {
		return this.stid;
	}

	public void setStid(Integer stid) {
		this.stid = stid;
	}

	public Kemu getKemu() {
		return this.kemu;
	}

	public void setKemu(Kemu kemu) {
		this.kemu = kemu;
	}

	public String getTmlx() {
		return this.tmlx;
	}

	public void setTmlx(String tmlx) {
		this.tmlx = tmlx;
	}

	public String getTmxlx() {
		return this.tmxlx;
	}

	public void setTmxlx(String tmxlx) {
		this.tmxlx = tmxlx;
	}

	public String getKsbt() {
		return this.ksbt;
	}

	public void setKsbt(String ksbt) {
		this.ksbt = ksbt;
	}

	public String getXxa() {
		return this.xxa;
	}

	public void setXxa(String xxa) {
		this.xxa = xxa;
	}

	public String getXxb() {
		return this.xxb;
	}

	public void setXxb(String xxb) {
		this.xxb = xxb;
	}

	public String getXxc() {
		return this.xxc;
	}

	public void setXxc(String xxc) {
		this.xxc = xxc;
	}

	public String getXxd() {
		return this.xxd;
	}

	public void setXxd(String xxd) {
		this.xxd = xxd;
	}

	public String getDaan() {
		return this.daan;
	}

	public void setDaan(String daan) {
		this.daan = daan;
	}

	public String getNandu() {
		return this.nandu;
	}

	public void setNandu(String nandu) {
		this.nandu = nandu;
	}

	public String getDyzj() {
		return this.dyzj;
	}

	public void setDyzj(String dyzj) {
		this.dyzj = dyzj;
	}

	public Set getXueshengShitis() {
		return this.xueshengShitis;
	}

	public void setXueshengShitis(Set xueshengShitis) {
		this.xueshengShitis = xueshengShitis;
	}

	public Set getShijuanShitis() {
		return this.shijuanShitis;
	}

	public void setShijuanShitis(Set shijuanShitis) {
		this.shijuanShitis = shijuanShitis;
	}

}