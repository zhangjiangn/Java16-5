package com.qhit.action;
import org.apache.struts2.ServletActionContext;
import com.qhit.bean.Student;
import com.qhit.bean.Users;
import com.qhit.biz.Loginbiz;
import com.qhit.biz.impl.LoginbizImpl;
public class LoginAction {
	private String name;
	private String pwd;
	private int role;
	private Student stu;
	private Users user;
	private Loginbiz loginbiz = new LoginbizImpl();
	public String login() {
		if (role == 1) {
			stu = loginbiz.loginstu(name, pwd);
			if (stu != null) {
				ServletActionContext.getRequest().getSession().setAttribute("stu", stu);
				return "index";
			} else {
				return "login";
			}
		} if(role==2){
			user = loginbiz.loginuser(name, pwd);
			if (user != null && user.getRole().equals("��ʦ")) {
				ServletActionContext.getRequest().getSession().setAttribute("user", user);
				return "index";
			} else {
				return "login";
			}
		}if(role==3){
			user = loginbiz.loginuser(name, pwd);
			if (user != null && user.getRole().equals("����Ա")) {
				ServletActionContext.getRequest().getSession().setAttribute("user", user);
				return "index";
			} else {
				return "login";
			}
		}else {
			
			return "login";
		}

	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public int getRole() {
		return role;
	}
	public void setRole(int role) {
		this.role = role;
	}
	public Student getStu() {
		return stu;
	}
	public void setStu(Student stu) {
		this.stu = stu;
	}
	public Users getUser() {
		return user;
	}
	public void setUser(Users user) {
		this.user = user;
	}
	public Loginbiz getLoginbiz() {
		return loginbiz;
	}
	public void setLoginbiz(Loginbiz loginbiz) {
		this.loginbiz = loginbiz;
	}

	
}
