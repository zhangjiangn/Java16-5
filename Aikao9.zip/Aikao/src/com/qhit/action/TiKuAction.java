package com.qhit.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.qhit.bean.Fangxiang;
import com.qhit.bean.Jieduan;
import com.qhit.bean.Kemu;
import com.qhit.bean.Shiti;
import com.qhit.biz.TiKubiz;
import com.qhit.biz.impl.TiKubizImpl;
import com.qhit.util.PageBean;

public class TiKuAction {
	private List<Fangxiang> list;
	private List<Jieduan> list1;
	private List<Kemu> list2;
	private int fid;
	private int jid;
	private PageBean pb;
	private Kemu kemu;
	private Shiti shiti;
	private Shiti newshiti;
	private int kmid;
	private int stid;
	private int count;
	private int p;
	private Map<Integer, Integer> stcount=new HashMap<Integer, Integer>();
	private TiKubiz tikubiz=new TiKubizImpl();   
public String  fxkm(){
	  list=tikubiz.selectfx();
	  list1=tikubiz.selectjd();
	  list2=tikubiz.flselect(fid, jid);
	  for (Kemu  list: list2) {
		     kmid=list.getKmid();
	}
	    count=tikubiz.count(kmid);
	    stcount.put(kmid, count);
	   	return "tiku";
	   	
	}
 public String fenye(){
		pb=tikubiz.selectst(kmid, p);
	return "flchakanst";
	}
 public String insertst(){
		HttpServletRequest request=ServletActionContext.getRequest();
		String kmname=request.getParameter("kmname");
		int kmid=tikubiz.selectkm(kmname);
		newshiti.getKemu().setKmid(kmid);
		int i=tikubiz.insertst(newshiti);
		if (i!=0) {
			return "insertst";
		} else {
			return "insertsb";
		}
	 
 }
 public String updatest(){
		kemu=tikubiz.selectmu(kmid);
		shiti=tikubiz.selectdan(stid);
		return "updatest";	
 }
 public String savest(){
	 HttpServletRequest request=ServletActionContext.getRequest();
		String kmname=request.getParameter("kmname");
		int kmid=tikubiz.selectkm(kmname);
		newshiti.getKemu().setKmid(kmid);
		int i=tikubiz.updatest(newshiti);
		if (i!=0) {
			return "updatest";
		} else {
			return "updatesb";
		}
 }
public TiKubiz getTikubiz() {
		return tikubiz;
	}
	public void setTikubiz(TiKubiz tikubiz) {
		this.tikubiz = tikubiz;
	}
	public List<Fangxiang> getList() {
		return list;
	}


	public void setList(List<Fangxiang> list) {
		this.list = list;
	}


	public List<Jieduan> getList1() {
		return list1;
	}


	public void setList1(List<Jieduan> list1) {
		this.list1 = list1;
	}
	public List<Kemu> getList2() {
		return list2;
	}


	public void setList2(List<Kemu> list2) {
		this.list2 = list2;
	}

	public int getFid() {
		return fid;
	}
	public void setFid(int fid) {
		this.fid = fid;
	}
	public int getJid() {
		return jid;
	}
	public void setJid(int jid) {
		this.jid = jid;
	}
	public PageBean getPb() {
		return pb;
	}
	public void setPb(PageBean pb) {
		this.pb = pb;
	}
	public Kemu getKemu() {
		return kemu;
	}
	public void setKemu(Kemu kemu) {
		this.kemu = kemu;
	}
	public Shiti getShiti() {
		return shiti;
	}
	public void setShiti(Shiti shiti) {
		this.shiti = shiti;
	}
	public Shiti getNewshiti() {
		return newshiti;
	}
	public void setNewshiti(Shiti newshiti) {
		this.newshiti = newshiti;
	}
	public Map<Integer, Integer> getStcount() {
		return stcount;
	}
	public void setStcount(Map<Integer, Integer> stcount) {
		this.stcount = stcount;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getKmid() {
		return kmid;
	}
	public void setKmid(int kmid) {
		this.kmid = kmid;
	}
	public int getStid() {
		return stid;
	}
	public void setStid(int stid) {
		this.stid = stid;
	}
	public int getP() {
		return p;
	}
	public void setP(int p) {
		this.p = p;
	}
}
