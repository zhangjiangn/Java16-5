package com.qhit.action;

import java.util.List;

import com.qhit.bean.Fangxiang;
import com.qhit.bean.Jieduan;
import com.qhit.bean.Kemu;
import com.qhit.bean.Shijuan;
import com.qhit.bean.Shiti;
import com.qhit.biz.Shijuanbiz;
import com.qhit.biz.impl.ShijuanbizImpl;
public class ShijuanAction {
	     private List<Fangxiang> fangxiang;
	     private List<Jieduan> jieduan;
	     private List<Kemu> allkemu;
	     private List<Kemu> dankemu;
	     private List<Shijuan> shijuan;
		private int fx;
	     private int jd;
	     private int km;
	     
		private Shijuanbiz shijuanbiz=new ShijuanbizImpl();
  public String fjklz(){
	  fangxiang=shijuanbiz.selectfx();
	  jieduan=shijuanbiz.selectjd();
	  allkemu=shijuanbiz.selectkm();
	  shijuan=shijuanbiz.selectsj();
	return "shijuan";}
  public String flcksj(){
	  
	 return "shijuan"; 
  }
  
  
  
  public List<Fangxiang> getFangxiang() {
		return fangxiang;
	}
	public void setFangxiang(List<Fangxiang> fangxiang) {
		this.fangxiang = fangxiang;
	}
	public List<Jieduan> getJieduan() {
		return jieduan;
	}
	public void setJieduan(List<Jieduan> jieduan) {
		this.jieduan = jieduan;
	}
    public List<Kemu> getAllkemu() {
		return allkemu;
	}
	public void setAllkemu(List<Kemu> allkemu) {
		this.allkemu = allkemu;
	}
	public List<Kemu> getDankemu() {
		return dankemu;
	}
	public void setDankemu(List<Kemu> dankemu) {
		this.dankemu = dankemu;
	}
	public List<Shijuan> getShijuan() {
		return shijuan;
	}
	public void setShijuan(List<Shijuan> shijuan) {
		this.shijuan = shijuan;
	}
	public int getFx() {
		return fx;
	}
	public void setFx(int fx) {
		this.fx = fx;
	}
	public int getJd() {
		return jd;
	}
	public void setJd(int jd) {
		this.jd = jd;
	}
	public int getKm() {
		return km;
	}
	public void setKm(int km) {
		this.km = km;
	}
	public Shijuanbiz getShijuanbiz() {
		return shijuanbiz;
	}
	public void setShijuanbiz(Shijuanbiz shijuanbiz) {
		this.shijuanbiz = shijuanbiz;
	}
}
