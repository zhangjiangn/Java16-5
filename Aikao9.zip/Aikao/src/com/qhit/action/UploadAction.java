package com.qhit.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.qhit.biz.TiKubiz;
import com.qhit.biz.impl.TiKubizImpl;
import com.opensymphony.xwork2.ActionSupport;

import com.qhit.util.PageBean;


public class UploadAction{
	private String name;
	private File filename;
	private String filenameFileName;
	private String filenameContentType;
	private PageBean pb;
	private int kmid;
	private TiKubiz tikubiz=new TiKubizImpl();
	public String upload() {
		try {
			InputStream is=new FileInputStream(filename);
			String filepath=ServletActionContext.getServletContext().getRealPath("/")+"upload/"+filenameFileName;
			OutputStream os=new FileOutputStream(filepath);
			byte[] by=new byte[8096];
			int len=0;
			while ((len=is.read(by))!=-1) {
				os.write(by, 0, len);
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		HttpServletRequest request=ServletActionContext.getRequest();
		kmid=Integer.parseInt(request.getParameter("kmid").trim());
		pb=tikubiz.selectst(kmid, 1);
		request.setAttribute("filenameFileName", filenameFileName);
		request.setAttribute("kmid", kmid);
		return "upload";
	}



	
	
	
	
	
	
	public int getKmid() {
		return kmid;
	}
	public void setKmid(int kmid) {
		this.kmid = kmid;
	}
	public PageBean getPb() {
		return pb;
	}
	public void setPb(PageBean pb) {
		this.pb = pb;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public File getFilename() {
		return filename;
	}
	public void setFilename(File filename) {
		this.filename = filename;
	}
	public String getFilenameFileName() {
		return filenameFileName;
	}
	public void setFilenameFileName(String filenameFileName) {
		this.filenameFileName = filenameFileName;
	}
	public String getFilenameContentType() {
		return filenameContentType;
	}
	public void setFilenameContentType(String filenameContentType) {
		this.filenameContentType = filenameContentType;
	}

}
