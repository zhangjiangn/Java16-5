package com.qhit.action;

import java.io.FileInputStream;
import java.io.InputStream;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;

public class DownloadAction extends ActionSupport{
	private InputStream dowFileName_is;
	
	public InputStream getInputStream()throws Exception{
		HttpServletRequest request=ServletActionContext.getRequest();
		String dowfilename=request.getParameter("dowfilename");
	
		dowfilename=new String(dowfilename.getBytes("UTF-8"), "UTF-8");
		System.out.println(dowfilename);
		String filepath=ServletActionContext.getServletContext().getRealPath("/")+"upload/"+dowfilename;
		dowFileName_is=new FileInputStream(filepath);
		System.out.println(dowFileName_is);
		
		return dowFileName_is;
	}
	   public String execute()throws Exception{  
		
	        return SUCCESS;  
	    }  
	

	
	public InputStream getDowFileName_is() {
		return dowFileName_is;
	}
	public void setDowFileName_is(InputStream dowFileNameIs) {
		dowFileName_is = dowFileNameIs;
	}
}
