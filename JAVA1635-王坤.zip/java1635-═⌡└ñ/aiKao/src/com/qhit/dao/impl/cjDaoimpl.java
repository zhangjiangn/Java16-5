package com.qhit.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import com.qhit.bean.Chengji;
import com.qhit.bean.Fangxiang;
import com.qhit.bean.Shiti;
import com.qhit.dao.HibernateSessionFactory;
import com.qhit.dao.cjDao;

public class cjDaoimpl implements cjDao {
static Session session=HibernateSessionFactory.getSession();
	public List<Chengji> find() {
		String hql="from Chengji";
		Query query=session.createQuery(hql);
	   	List<Chengji> list= query.list();
		return list;
	}
	public List<Chengji> selfind(Chengji cj) {
		String hql="select cj from Chengji cj join cj.stu s join cj.shijuan sj join sj.banji bj where 1=1 ";
		if(cj.getStu().getStuname()!=null&&!cj.getStu().getStuname().equals(""))hql+=" and s.stuname='"+cj.getStu().getStuname()+"'" ;
		if(cj.getShijuan().getBanji().getBjname()!=null&&!cj.getShijuan().getBanji().getBjname().equals(""))hql+="and bj.bjname='"+cj.getShijuan().getBanji().getBjname()+"'";
		Query query=session.createQuery(hql);
	   	List<Chengji> list= query.list();
		return list;
	}
	public List<Shiti> selshiti(Shiti st) {
		String hql="select st from Shiti st where stid="+st.getStid();
		Query query=session.createQuery(hql);
	   	List<Shiti> list= query.list();
		return list;
	} 
}
