package com.qhit.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.struts2.ServletActionContext;

import com.qhit.bean.Fangxiang;
import com.qhit.bean.Jieduan;
import com.qhit.bean.Kemu;
import com.qhit.bean.Shiti;
import com.qhit.biz.loginBiz;
import com.qhit.biz.shitiBiz;
import com.qhit.biz.impl.loginBizimpl;
import com.qhit.biz.impl.shitiBizimpl;
import com.qhit.util.PageBean;

public class shitiAction {
	private Fangxiang fangxiang;
	private Shiti shiti;
	
	
	
	private int esubid;
	private PageBean pbEQ;
	private int p;
	
	
	private Jieduan jieduan;
	private Kemu kemu;
	private ArrayList<Kemu> kmlist=new ArrayList<Kemu>();
	private loginBiz biz=new loginBizimpl();
	
	
	private shitiBiz shi=new shitiBizimpl();
	
	
	private String dirOpValue;
	private String staOpVlaue;
	
	
	 
	    //ע�⣬file������ָǰ��jsp�ϴ��������ļ������������ļ��ϴ������������ʱ�ļ���������ļ�
	    private File file;
	    //�ύ������file������
	    private String fileFileName;
	    //�ύ������file��MIME����
		
	    private String fileContentType;
		
	    //�������ļ�������
	    private String filename;
	    //��ȡ�������ļ���������
	    private InputStream downFile_is;
	
	private List<Shiti> list=new ArrayList<Shiti>();
	public String fangxiangorjieduan(){
		int did = Integer.parseInt(dirOpValue);
		int jdid = Integer.parseInt(dirOpValue);
		ArrayList<Fangxiang> lists=biz.lists(did);
		ArrayList<Jieduan> list=biz.list(jdid);
		//ArrayList<Shiti> list2=biz.find();
		ServletActionContext.getRequest().getSession().setAttribute("lists", lists);	
		ServletActionContext.getRequest().getSession().setAttribute("list", list);
		//ServletActionContext.getRequest().getSession().setAttribute("list2", list2);
		return "show";
	}
	public String fileDown(){
		
		String filePath= ServletActionContext.getServletContext().getRealPath("/")+"upload/";
		try {
		FileUtils.copyFile(file, new File(filePath, fileFileName));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "info";
	}
	
public String addHTml(){
	return "add";
}
	public String shitishow(){
		list=shi.listshow();
		//ServletActionContext.getRequest().getSession().setAttribute("lists", list);
		return "shiti2";
	}
	public String add(){
		int i=shi.addshiti(shiti);
		if (i==0) {
			return shitishow();
		}else {
			return "add";
		}		
	}
	public String shitilistshow(){
		list=shi.shitishow(shiti.getStid());
		return "shitiupdate";
	}
	public String update(){
		int i=shi.UPDATEshiti(shiti);
		return shitishow();
	}

	public String EQInfo(){
//		System.out.println(esubid);
		//test
		int up=1;
		if(p!=0)up=p;
		pbEQ = shi.getExamQuestionPageBean(up);
//		EQList = (ArrayList<ExamQuestion>) pbEQ.getData();
		//testOver
//		EQList = eqb.getExamQuestionByEsubid(esubid);
//		kmlist = shi.getSubjectById(esubid);
//		if (pbEQ!=null) {
//			ServletActionContext.getRequest().getSession().setAttribute("EQlist", EQList);
			return "shiti";
//		}else{
//			return "erro";
//		}

	}









	public InputStream getDownFile_is() {
		return downFile_is;
	}
	public void setDownFile_is(InputStream downFileIs) {
		downFile_is = downFileIs;
	}
	public File getFile() {
		return file;
	}
	public void setFile(File file) {
		this.file = file;
	}
	public String getFileFileName() {
		return fileFileName;
	}
	public void setFileFileName(String fileFileName) {
		this.fileFileName = fileFileName;
	}
	public String getFileContentType() {
		return fileContentType;
	}
	public void setFileContentType(String fileContentType) {
		this.fileContentType = fileContentType;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public InputStream getPhotoIn() {
		return downFile_is;
	}
	public void setPhotoIn(InputStream photoIn) {
		this.downFile_is = photoIn;
	}
public ArrayList<Kemu> getKmlist() {
		return kmlist;
	}

	public void setKmlist(ArrayList<Kemu> kmlist) {
		this.kmlist = kmlist;
	}

public shitiBiz getShi() {
		return shi;
	}

	public void setShi(shitiBiz shi) {
		this.shi = shi;
	}

public List<Shiti> getList() {
		return list;
	}

	public void setList(List<Shiti> list) {
		this.list = list;
	}

public loginBiz getBiz() {
		return biz;
	}
	public void setBiz(loginBiz biz) {
		this.biz = biz;
	}
	public String getDirOpValue() {
		return dirOpValue;
	}
	public void setDirOpValue(String dirOpValue) {
		this.dirOpValue = dirOpValue;
	}
	public String getStaOpVlaue() {
		return staOpVlaue;
	}
	public void setStaOpVlaue(String staOpVlaue) {
		this.staOpVlaue = staOpVlaue;
	}

public Fangxiang getFangxiang() {
	return fangxiang;
}

public void setFangxiang(Fangxiang fangxiang) {
	this.fangxiang = fangxiang;
}

public Shiti getShiti() {
	return shiti;
}

public void setShiti(Shiti shiti) {
	this.shiti = shiti;
}

public Jieduan getJieduan() {
	return jieduan;
}

public void setJieduan(Jieduan jieduan) {
	this.jieduan = jieduan;
}

public Kemu getKemu() {
	return kemu;
}

public void setKemu(Kemu kemu) {
	this.kemu = kemu;
}

public int getEsubid() {
	return esubid;
}

public void setEsubid(int esubid) {
	this.esubid = esubid;
}

public PageBean getPbEQ() {
	return pbEQ;
}

public void setPbEQ(PageBean pbEQ) {
	this.pbEQ = pbEQ;
}

public int getP() {
	return p;
}

public void setP(int p) {
	this.p = p;
}


}
