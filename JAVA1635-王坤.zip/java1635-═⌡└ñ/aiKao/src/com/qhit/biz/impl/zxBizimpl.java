package com.qhit.biz.impl;

import java.util.List;

import com.qhit.bean.Shijuan;
import com.qhit.bean.Shiti;
import com.qhit.bean.StuShiti;
import com.qhit.biz.zxBiz;
import com.qhit.dao.zxDao;
import com.qhit.dao.impl.zxDaoimpl;
import com.qhit.util.PageBean;

public class zxBizimpl implements zxBiz {
private zxDao dao=new zxDaoimpl();
	public List<Shijuan> list() {
		
		return dao.list();
	}
	public zxDao getDao() {
		return dao;
	}
	public void setDao(zxDao dao) {
		this.dao = dao;
	}
	public PageBean find(int p) {
		// TODO Auto-generated method stub
		return dao.find(p);
	}
	public List<Shijuan> stlist(int stid) {
		// TODO Auto-generated method stub
		return dao.stlist(stid);
	}
	public int anwer(String anwer,int sjid) {
		// TODO Auto-generated method stub
		return dao.anwer(anwer,sjid);
	}
	public int addsss(String daan) {
		// TODO Auto-generated method stub
		return dao.addsss(daan);
	}

}
