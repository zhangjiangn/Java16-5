package com.qhit.biz;

import java.util.List;

import com.qhit.bean.Chengji;
import com.qhit.bean.Shiti;

public interface cjBiz {
public List<Chengji> find();
public List<Chengji> selfind(Chengji cj);
public List<Shiti> selshiti(Shiti st);
}
