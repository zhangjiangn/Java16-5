package com.qhit.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Jieduan entity. @author MyEclipse Persistence Tools
 */

public class Jieduan implements java.io.Serializable {

	// Fields

	private Integer jdid;
	private String bjname;
	private Set kemus = new HashSet(0);

	// Constructors

	/** default constructor */
	public Jieduan() {
	}

	/** minimal constructor */
	public Jieduan(Integer jdid) {
		this.jdid = jdid;
	}

	/** full constructor */
	public Jieduan(Integer jdid, String bjname, Set kemus) {
		this.jdid = jdid;
		this.bjname = bjname;
		this.kemus = kemus;
	}

	// Property accessors

	public Integer getJdid() {
		return this.jdid;
	}

	public void setJdid(Integer jdid) {
		this.jdid = jdid;
	}

	public String getBjname() {
		return this.bjname;
	}

	public void setBjname(String bjname) {
		this.bjname = bjname;
	}

	public Set getKemus() {
		return this.kemus;
	}

	public void setKemus(Set kemus) {
		this.kemus = kemus;
	}

}