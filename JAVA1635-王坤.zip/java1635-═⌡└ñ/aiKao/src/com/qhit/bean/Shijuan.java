package com.qhit.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Shijuan entity. @author MyEclipse Persistence Tools
 */

public class Shijuan implements java.io.Serializable {

	// Fields

	private Integer sjid;
	private Banji banji;
	private String sjType;
	private String sjkm;
	private String sjbt;
	private String kaoshiTime;
	private String sjzt;
	private Set stuShitis = new HashSet(0);
	private Set chengjis = new HashSet(0);
	private Set shijuanShitis = new HashSet(0);

	// Constructors

	/** default constructor */
	public Shijuan() {
	}

	/** minimal constructor */
	public Shijuan(Integer sjid) {
		this.sjid = sjid;
	}

	/** full constructor */
	public Shijuan(Integer sjid, Banji banji, String sjType, String sjkm,
			String sjbt, String kaoshiTime, String sjzt, Set stuShitis,
			Set chengjis, Set shijuanShitis) {
		this.sjid = sjid;
		this.banji = banji;
		this.sjType = sjType;
		this.sjkm = sjkm;
		this.sjbt = sjbt;
		this.kaoshiTime = kaoshiTime;
		this.sjzt = sjzt;
		this.stuShitis = stuShitis;
		this.chengjis = chengjis;
		this.shijuanShitis = shijuanShitis;
	}

	// Property accessors

	public Integer getSjid() {
		return this.sjid;
	}

	public void setSjid(Integer sjid) {
		this.sjid = sjid;
	}

	public Banji getBanji() {
		return this.banji;
	}

	public void setBanji(Banji banji) {
		this.banji = banji;
	}

	public String getSjType() {
		return this.sjType;
	}

	public void setSjType(String sjType) {
		this.sjType = sjType;
	}

	public String getSjkm() {
		return this.sjkm;
	}

	public void setSjkm(String sjkm) {
		this.sjkm = sjkm;
	}

	public String getSjbt() {
		return this.sjbt;
	}

	public void setSjbt(String sjbt) {
		this.sjbt = sjbt;
	}

	public String getKaoshiTime() {
		return this.kaoshiTime;
	}

	public void setKaoshiTime(String kaoshiTime) {
		this.kaoshiTime = kaoshiTime;
	}

	public String getSjzt() {
		return this.sjzt;
	}

	public void setSjzt(String sjzt) {
		this.sjzt = sjzt;
	}

	public Set getStuShitis() {
		return this.stuShitis;
	}

	public void setStuShitis(Set stuShitis) {
		this.stuShitis = stuShitis;
	}

	public Set getChengjis() {
		return this.chengjis;
	}

	public void setChengjis(Set chengjis) {
		this.chengjis = chengjis;
	}

	public Set getShijuanShitis() {
		return this.shijuanShitis;
	}

	public void setShijuanShitis(Set shijuanShitis) {
		this.shijuanShitis = shijuanShitis;
	}

}