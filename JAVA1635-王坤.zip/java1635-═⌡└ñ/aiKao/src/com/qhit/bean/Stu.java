package com.qhit.bean;

/**
 * Stu entity. @author MyEclipse Persistence Tools
 */

public class Stu implements java.io.Serializable {

	// Fields

	private Integer stuid;
	private Banji banji;
	private String stunumber;
	private String stugrade;
	private String stuname;
	private String stupwd;
	private String stusex;
	private String stustel;

	// Constructors

	/** default constructor */
	public Stu() {
	}

	/** minimal constructor */
	public Stu(Integer stuid) {
		this.stuid = stuid;
	}

	/** full constructor */
	public Stu(Integer stuid, Banji banji, String stunumber, String stugrade,
			String stuname, String stupwd, String stusex, String stustel) {
		this.stuid = stuid;
		this.banji = banji;
		this.stunumber = stunumber;
		this.stugrade = stugrade;
		this.stuname = stuname;
		this.stupwd = stupwd;
		this.stusex = stusex;
		this.stustel = stustel;
	}

	// Property accessors

	public Integer getStuid() {
		return this.stuid;
	}

	public void setStuid(Integer stuid) {
		this.stuid = stuid;
	}

	public Banji getBanji() {
		return this.banji;
	}

	public void setBanji(Banji banji) {
		this.banji = banji;
	}

	public String getStunumber() {
		return this.stunumber;
	}

	public void setStunumber(String stunumber) {
		this.stunumber = stunumber;
	}

	public String getStugrade() {
		return this.stugrade;
	}

	public void setStugrade(String stugrade) {
		this.stugrade = stugrade;
	}

	public String getStuname() {
		return this.stuname;
	}

	public void setStuname(String stuname) {
		this.stuname = stuname;
	}

	public String getStupwd() {
		return this.stupwd;
	}

	public void setStupwd(String stupwd) {
		this.stupwd = stupwd;
	}

	public String getStusex() {
		return this.stusex;
	}

	public void setStusex(String stusex) {
		this.stusex = stusex;
	}

	public String getStustel() {
		return this.stustel;
	}

	public void setStustel(String stustel) {
		this.stustel = stustel;
	}

}