package com.qhit.bean;

/**
 * StuShiti entity. @author MyEclipse Persistence Tools
 */

public class StuShiti implements java.io.Serializable {

	// Fields

	private Integer sstuid;
	private Stu stu;
	private Shijuan shijuan;
	private Shiti shiti;
	private String stuanewr;

	// Constructors

	/** default constructor */
	public StuShiti() {
	}

	/** minimal constructor */
	public StuShiti(Integer sstuid) {
		this.sstuid = sstuid;
	}

	/** full constructor */
	public StuShiti(Integer sstuid, Stu stu, Shijuan shijuan, Shiti shiti,
			String stuanewr) {
		this.sstuid = sstuid;
		this.stu = stu;
		this.shijuan = shijuan;
		this.shiti = shiti;
		this.stuanewr = stuanewr;
	}

	// Property accessors

	public Integer getSstuid() {
		return this.sstuid;
	}

	public void setSstuid(Integer sstuid) {
		this.sstuid = sstuid;
	}

	public Stu getStu() {
		return this.stu;
	}

	public void setStu(Stu stu) {
		this.stu = stu;
	}

	public Shijuan getShijuan() {
		return this.shijuan;
	}

	public void setShijuan(Shijuan shijuan) {
		this.shijuan = shijuan;
	}

	public Shiti getShiti() {
		return this.shiti;
	}

	public void setShiti(Shiti shiti) {
		this.shiti = shiti;
	}

	public String getStuanewr() {
		return this.stuanewr;
	}

	public void setStuanewr(String stuanewr) {
		this.stuanewr = stuanewr;
	}

}