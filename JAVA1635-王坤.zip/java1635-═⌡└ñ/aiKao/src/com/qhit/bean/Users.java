package com.qhit.bean;

/**
 * Users entity. @author MyEclipse Persistence Tools
 */

public class Users implements java.io.Serializable {

	// Fields

	private Integer uid;
	private String accnumber;
	private String uname;
	private String upwd;
	private String sex;
	private String brith;
	private String education;
	private String tel;
	private String uroles;
	private String orther;

	// Constructors

	/** default constructor */
	public Users() {
	}

	/** minimal constructor */
	public Users(Integer uid) {
		this.uid = uid;
	}

	/** full constructor */
	public Users(Integer uid, String accnumber, String uname, String upwd,
			String sex, String brith, String education, String tel,
			String uroles, String orther) {
		this.uid = uid;
		this.accnumber = accnumber;
		this.uname = uname;
		this.upwd = upwd;
		this.sex = sex;
		this.brith = brith;
		this.education = education;
		this.tel = tel;
		this.uroles = uroles;
		this.orther = orther;
	}

	// Property accessors

	public Integer getUid() {
		return this.uid;
	}

	public void setUid(Integer uid) {
		this.uid = uid;
	}

	public String getAccnumber() {
		return this.accnumber;
	}

	public void setAccnumber(String accnumber) {
		this.accnumber = accnumber;
	}

	public String getUname() {
		return this.uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getUpwd() {
		return this.upwd;
	}

	public void setUpwd(String upwd) {
		this.upwd = upwd;
	}

	public String getSex() {
		return this.sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getBrith() {
		return this.brith;
	}

	public void setBrith(String brith) {
		this.brith = brith;
	}

	public String getEducation() {
		return this.education;
	}

	public void setEducation(String education) {
		this.education = education;
	}

	public String getTel() {
		return this.tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getUroles() {
		return this.uroles;
	}

	public void setUroles(String uroles) {
		this.uroles = uroles;
	}

	public String getOrther() {
		return this.orther;
	}

	public void setOrther(String orther) {
		this.orther = orther;
	}

}