package com.qhit.dao;

import org.hibernate.Session;

import com.qhit.bean.Direction;
import com.qhit.bean.Stage;
import com.qhit.bean.Student;
import com.qhit.bean.Subject;
import com.qhit.bean.Users;

public interface LoginDao {
	public Session session = HibernateSessionFactory.getSession();
	public Student getUsersByStu(String name,String pwd);
	public Users getUsersByUsers(String name,String pwd);
	
}
