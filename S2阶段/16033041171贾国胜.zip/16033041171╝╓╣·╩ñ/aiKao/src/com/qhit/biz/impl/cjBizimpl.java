package com.qhit.biz.impl;

import java.util.List;

import com.qhit.bean.Chengji;
import com.qhit.bean.Shiti;
import com.qhit.biz.cjBiz;
import com.qhit.dao.cjDao;
import com.qhit.dao.impl.cjDaoimpl;

public class cjBizimpl implements cjBiz {
private cjDao dao=new cjDaoimpl();
	public List<Chengji> find() {
		// TODO Auto-generated method stub
		return dao.find();
	}
	public cjDao getDao() {
		return dao;
	}
	public void setDao(cjDao dao) {
		this.dao = dao;
	}
	public List<Chengji> selfind(Chengji cj) {
		// TODO Auto-generated method stub
		return dao.selfind(cj);
	}
	public List<Shiti> selshiti(Shiti st) {
		// TODO Auto-generated method stub
		return dao.selshiti(st);
	}
}
