package com.qhit.biz.impl;

import java.util.ArrayList;
import java.util.List;

import com.qhit.bean.Fangxiang;
import com.qhit.bean.Jieduan;
import com.qhit.bean.Shiti;
import com.qhit.bean.Stu;
import com.qhit.bean.Users;
import com.qhit.biz.loginBiz;
import com.qhit.dao.loginDao;
import com.qhit.dao.impl.loginDaoimpl;

public class loginBizimpl implements loginBiz {
private loginDao dao=new loginDaoimpl();
public loginDao getDao() {
	return dao;
}

public void setDao(loginDao dao) {
	this.dao = dao;
}
	public Stu stulogin(String name, String pwd) {
		// TODO Auto-generated method stub
		return dao.stulogin(name, pwd);
	}

	public Users userslogin(String name, String pwd) {
		// TODO Auto-generated method stub
		return dao.userslogin(name, pwd);
	}

	
	
/////����SCME��SCCE���ͽ׶Σ�G1��G2��G3��
	public ArrayList<Jieduan> list(int id) {
		// TODO Auto-generated method stub
		return dao.list(id);
	}

	public ArrayList<Fangxiang> lists(int id) {
		// TODO Auto-generated method stub
		return dao.lists(id);
	}
	//��ѯ���������
	public ArrayList<Shiti> find() {
		// TODO Auto-generated method stub
		return dao.find();
	}


}
