package com.qhit.action;

import java.util.ArrayList;
import java.util.List;

import org.apache.struts2.ServletActionContext;

import com.qhit.bean.Stu;
import com.qhit.bean.Users;
import com.qhit.biz.loginBiz;
import com.qhit.biz.impl.loginBizimpl;

public class loginAction {
private String name;
private String pwd;
private int role;
private loginBiz biz=new loginBizimpl();
private List<Stu> list;

public String login(){
	if (role==1) {
		Stu stu=biz.stulogin(name, pwd);
		if (stu!=null) {
			ServletActionContext.getRequest().getSession().setAttribute("role", 1);
			ServletActionContext.getRequest().getSession().setAttribute("student", stu);
			return "index";
		}else{
			return "login";
		}
	}else {
		Users users=biz.userslogin(name, pwd);
		if (users!=null) {
			ServletActionContext.getRequest().getSession().setAttribute("role", 2);
			ServletActionContext.getRequest().getSession().setAttribute("users", users);
			return "index";
		}else{
			return "login";
		}
	}
}


public loginBiz getBiz() {
	return biz;
}


public void setBiz(loginBiz biz) {
	this.biz = biz;
}


public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getPwd() {
	return pwd;
}
public void setPwd(String pwd) {
	this.pwd = pwd;
}
public int getRole() {
	return role;
}
public void setRole(int role) {
	this.role = role;
}


public List<Stu> getList() {
	return list;
}


public void setList(List<Stu> list) {
	this.list = list;
}





}
