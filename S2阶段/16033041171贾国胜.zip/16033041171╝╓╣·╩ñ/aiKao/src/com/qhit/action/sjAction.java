package com.qhit.action;

import java.util.List;

import com.qhit.bean.Fangxiang;
import com.qhit.bean.Jieduan;
import com.qhit.bean.Kemu;
import com.qhit.bean.Shijuan;
import com.qhit.bean.Shiti;
import com.qhit.biz.shijuanBiz;
import com.qhit.biz.shitiBiz;
import com.qhit.biz.impl.shijuanBizimpl;
import com.qhit.biz.impl.shitiBizimpl;
import com.qhit.util.PageBean;

public class sjAction {
	private shijuanBiz biz=new shijuanBizimpl();
	private shitiBiz biz2=new shitiBizimpl();
	
	private Shijuan sj;
	private Shiti st;
	private Kemu km;
	private List<Fangxiang> sjFx;//����
	private List<Jieduan> sjjd;//�׶�
	private List<Kemu> sjkm;//�Ծ���Ŀ
	private List<Shijuan> sjzt;//�Ծ�״̬
	private List<Shijuan> find;//��������
	private List<Shiti> stlist;
	//////////////////��ҳ����
	private PageBean pbEQ;
	private int p;
	
	public String addHTml(){
		sjFx=biz.sjFx();
		sjkm=biz.sjkm();
		sjjd=biz.sjjd();
		return "selzj";
	}
	public String xialaortableshow(){
		int up=1;
		if(p!=0)up=p;
		pbEQ=biz.find(up);
		sjFx=biz.sjFx();
		sjkm=biz.sjkm();
		sjjd=biz.sjjd();
		return "sjshow";
	}
	
	public String xialaortableshow0(){
		int up=1;
		if(p!=0)up=p;
		pbEQ=biz.find(up);
		sjFx=biz.sjFx();
		sjkm=biz.sjkm();
		sjjd=biz.sjjd();
		return "sjshow2";
	}
	
	
	public String xzHTml(){
		sjFx=biz.sjFx();
		sjkm=biz.sjkm();
		sjjd=biz.sjjd();
		stlist=biz.show();
		return "xuantijsp";
	}
	public String updateZT(){
		biz.updateZT(sj.getSjid());
		return xialaortableshow0();
	}
	public String stop(){
		biz.stop(sj.getSjid());
		return xialaortableshow0();
	}
	
	
	
	
	
	
	
	public List<Shiti> getStlist() {
		return stlist;
	}
	public void setStlist(List<Shiti> stlist) {
		this.stlist = stlist;
	}
	public PageBean getPbEQ() {
		return pbEQ;
	}
	public void setPbEQ(PageBean pbEQ) {
		this.pbEQ = pbEQ;
	}
	public int getP() {
		return p;
	}
	public void setP(int p) {
		this.p = p;
	}
	public shijuanBiz getBiz() {
		return biz;
	}
	public void setBiz(shijuanBiz biz) {
		this.biz = biz;
	}
	public List<Fangxiang> getSjFx() {
		return sjFx;
	}
	public void setSjFx(List<Fangxiang> sjFx) {
		this.sjFx = sjFx;
	}
	public List<Jieduan> getSjjd() {
		return sjjd;
	}
	public void setSjjd(List<Jieduan> sjjd) {
		this.sjjd = sjjd;
	}
	public List<Kemu> getSjkm() {
		return sjkm;
	}
	public void setSjkm(List<Kemu> sjkm) {
		this.sjkm = sjkm;
	}
	public List<Shijuan> getSjzt() {
		return sjzt;
	}
	public void setSjzt(List<Shijuan> sjzt) {
		this.sjzt = sjzt;
	}
	public List<Shijuan> getFind() {
		return find;
	}
	public void setFind(List<Shijuan> find) {
		this.find = find;
	}
	public shitiBiz getBiz2() {
		return biz2;
	}
	public void setBiz2(shitiBiz biz2) {
		this.biz2 = biz2;
	}
	public Shijuan getSj() {
		return sj;
	}
	public void setSj(Shijuan sj) {
		this.sj = sj;
	}
	public Shiti getSt() {
		return st;
	}
	public void setSt(Shiti st) {
		this.st = st;
	}
	public Kemu getKm() {
		return km;
	}
	public void setKm(Kemu km) {
		this.km = km;
	}
	
	
	
	
	
	
	
	
}
