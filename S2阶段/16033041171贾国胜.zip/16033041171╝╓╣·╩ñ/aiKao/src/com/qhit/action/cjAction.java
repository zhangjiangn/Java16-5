package com.qhit.action;

import java.util.List;

import com.qhit.bean.Chengji;
import com.qhit.bean.Shiti;
import com.qhit.biz.cjBiz;
import com.qhit.biz.impl.cjBizimpl;

public class cjAction {
private cjBiz biz=new cjBizimpl();

private List<Chengji> list;
private List<Shiti> stlist;

private Chengji chengji;
private Shiti shiti;



public String find(){
	list=biz.find();
	return "chengji";
}
public String selectCj(){
	list=biz.selfind(chengji);
	return "chengji1";
}
public String show(){
	list=biz.find();
	stlist=biz.selshiti(shiti);
	return "show";
}

public Chengji getChengji() {
	return chengji;
}
public void setChengji(Chengji chengji) {
	this.chengji = chengji;
}
public cjBiz getBiz() {
	return biz;
}
public void setBiz(cjBiz biz) {
	this.biz = biz;
}
public List<Chengji> getList() {
	return list;
}
public void setList(List<Chengji> list) {
	this.list = list;
}
public Shiti getShiti() {
	return shiti;
}
public void setShiti(Shiti shiti) {
	this.shiti = shiti;
}
public List<Shiti> getStlist() {
	return stlist;
}
public void setStlist(List<Shiti> stlist) {
	this.stlist = stlist;
}

}
