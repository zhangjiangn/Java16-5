package com.qhit.bean;

/**
 * Chengji entity. @author MyEclipse Persistence Tools
 */

public class Chengji implements java.io.Serializable {

	// Fields

	private Integer cjid;
	private Stu stu;
	private Shijuan shijuan;
	private String begintime;
	private String overtime;
	private Integer chengji;

	// Constructors

	/** default constructor */
	public Chengji() {
	}

	/** minimal constructor */
	public Chengji(Integer cjid) {
		this.cjid = cjid;
	}

	/** full constructor */
	public Chengji(Integer cjid, Stu stu, Shijuan shijuan, String begintime,
			String overtime, Integer chengji) {
		this.cjid = cjid;
		this.stu = stu;
		this.shijuan = shijuan;
		this.begintime = begintime;
		this.overtime = overtime;
		this.chengji = chengji;
	}

	// Property accessors

	public Integer getCjid() {
		return this.cjid;
	}

	public void setCjid(Integer cjid) {
		this.cjid = cjid;
	}

	public Stu getStu() {
		return this.stu;
	}

	public void setStu(Stu stu) {
		this.stu = stu;
	}

	public Shijuan getShijuan() {
		return this.shijuan;
	}

	public void setShijuan(Shijuan shijuan) {
		this.shijuan = shijuan;
	}

	public String getBegintime() {
		return this.begintime;
	}

	public void setBegintime(String begintime) {
		this.begintime = begintime;
	}

	public String getOvertime() {
		return this.overtime;
	}

	public void setOvertime(String overtime) {
		this.overtime = overtime;
	}

	public Integer getChengji() {
		return this.chengji;
	}

	public void setChengji(Integer chengji) {
		this.chengji = chengji;
	}

}