package com.qhit.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Banji entity. @author MyEclipse Persistence Tools
 */

public class Banji implements java.io.Serializable {

	// Fields

	private Integer bjid;
	private String bjname;
	private Set stus = new HashSet(0);

	// Constructors

	/** default constructor */
	public Banji() {
	}

	/** minimal constructor */
	public Banji(Integer bjid) {
		this.bjid = bjid;
	}

	/** full constructor */
	public Banji(Integer bjid, String bjname, Set stus) {
		this.bjid = bjid;
		this.bjname = bjname;
		this.stus = stus;
	}

	// Property accessors

	public Integer getBjid() {
		return this.bjid;
	}

	public void setBjid(Integer bjid) {
		this.bjid = bjid;
	}

	public String getBjname() {
		return this.bjname;
	}

	public void setBjname(String bjname) {
		this.bjname = bjname;
	}

	public Set getStus() {
		return this.stus;
	}

	public void setStus(Set stus) {
		this.stus = stus;
	}

}