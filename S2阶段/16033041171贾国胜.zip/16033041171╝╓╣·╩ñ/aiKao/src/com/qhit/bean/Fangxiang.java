package com.qhit.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Fangxiang entity. @author MyEclipse Persistence Tools
 */

public class Fangxiang implements java.io.Serializable {

	// Fields

	private Integer fxid;
	private String fxname;
	private Set kemus = new HashSet(0);

	// Constructors

	/** default constructor */
	public Fangxiang() {
	}

	/** minimal constructor */
	public Fangxiang(Integer fxid) {
		this.fxid = fxid;
	}

	/** full constructor */
	public Fangxiang(Integer fxid, String fxname, Set kemus) {
		this.fxid = fxid;
		this.fxname = fxname;
		this.kemus = kemus;
	}

	// Property accessors

	public Integer getFxid() {
		return this.fxid;
	}

	public void setFxid(Integer fxid) {
		this.fxid = fxid;
	}

	public String getFxname() {
		return this.fxname;
	}

	public void setFxname(String fxname) {
		this.fxname = fxname;
	}

	public Set getKemus() {
		return this.kemus;
	}

	public void setKemus(Set kemus) {
		this.kemus = kemus;
	}

}