package com.qhit.bean;

/**
 * Shiti entity. @author MyEclipse Persistence Tools
 */

public class Shiti implements java.io.Serializable {

	// Fields

	private Integer stid;
	private Kemu kemu;
	private String stbigType;
	private String tmtype;
	private String tmNr;
	private String xuanxiangA;
	private String xuanxiangB;
	private String xuanxiangC;
	private String xuanxiangD;
	private String zhangjie;
	private Integer meitiFs;
	private String daan;
	private String nandu;
	private int counts;
	// Constructors

	/** default constructor */
	
	public Shiti() {
	}

	public int getCount() {
		return counts;
	}

	public void setCount(int count) {
		this.counts = count;
	}

	/** minimal constructor */
	public Shiti(Integer stid) {
		this.stid = stid;
	}

	/** full constructor */
	public Shiti(Integer stid, Kemu kemu, String stbigType, String tmtype,
			String tmNr, String xuanxiangA, String xuanxiangB,
			String xuanxiangC, String xuanxiangD, String zhangjie,
			Integer meitiFs, String daan, String nandu) {
		this.stid = stid;
		this.kemu = kemu;
		this.stbigType = stbigType;
		this.tmtype = tmtype;
		this.tmNr = tmNr;
		this.xuanxiangA = xuanxiangA;
		this.xuanxiangB = xuanxiangB;
		this.xuanxiangC = xuanxiangC;
		this.xuanxiangD = xuanxiangD;
		this.zhangjie = zhangjie;
		this.meitiFs = meitiFs;
		this.daan = daan;
		this.nandu = nandu;
	}

	// Property accessors

	public Integer getStid() {
		return this.stid;
	}

	public void setStid(Integer stid) {
		this.stid = stid;
	}

	public Kemu getKemu() {
		return this.kemu;
	}

	public void setKemu(Kemu kemu) {
		this.kemu = kemu;
	}

	public String getStbigType() {
		return this.stbigType;
	}

	public void setStbigType(String stbigType) {
		this.stbigType = stbigType;
	}

	public String getTmtype() {
		return this.tmtype;
	}

	public void setTmtype(String tmtype) {
		this.tmtype = tmtype;
	}

	public String getTmNr() {
		return this.tmNr;
	}

	public void setTmNr(String tmNr) {
		this.tmNr = tmNr;
	}

	public String getXuanxiangA() {
		return this.xuanxiangA;
	}

	public void setXuanxiangA(String xuanxiangA) {
		this.xuanxiangA = xuanxiangA;
	}

	public String getXuanxiangB() {
		return this.xuanxiangB;
	}

	public void setXuanxiangB(String xuanxiangB) {
		this.xuanxiangB = xuanxiangB;
	}

	public String getXuanxiangC() {
		return this.xuanxiangC;
	}

	public void setXuanxiangC(String xuanxiangC) {
		this.xuanxiangC = xuanxiangC;
	}

	public String getXuanxiangD() {
		return this.xuanxiangD;
	}

	public void setXuanxiangD(String xuanxiangD) {
		this.xuanxiangD = xuanxiangD;
	}

	public String getZhangjie() {
		return this.zhangjie;
	}

	public void setZhangjie(String zhangjie) {
		this.zhangjie = zhangjie;
	}

	public Integer getMeitiFs() {
		return this.meitiFs;
	}

	public void setMeitiFs(Integer meitiFs) {
		this.meitiFs = meitiFs;
	}

	public String getDaan() {
		return this.daan;
	}

	public void setDaan(String daan) {
		this.daan = daan;
	}

	public String getNandu() {
		return this.nandu;
	}

	public void setNandu(String nandu) {
		this.nandu = nandu;
	}

}