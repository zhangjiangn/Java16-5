package com.qhit.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.qhit.bean.Kemu;
import com.qhit.bean.Shiti;

import com.qhit.dao.HibernateSessionFactory;
import com.qhit.dao.shitiDao;
import com.qhit.util.PageBean;

public class shitiDaoimpl implements shitiDao {

	public List<Shiti> listshow() {
		Session session=HibernateSessionFactory.getSession();
		String hql="from Shiti s";
		Query query=session.createQuery(hql);
		List<Shiti> list=query.list();
		return list;
	}
	public int addshiti(Shiti shiti){
		int i=0;
		try {
			Session session=HibernateSessionFactory.getSession();
			session.beginTransaction();
			session.save(shiti);
			session.beginTransaction().commit();
		} catch (Exception e) {
			i=1;
		}		
		return i;
	}
	public int UPDATEshiti(Shiti shiti){
		int i=0;
		try {
			Session session=HibernateSessionFactory.getSession();
			session.beginTransaction();
			session.update(shiti);
			session.beginTransaction().commit();
		} catch (Exception e) {
			i=1;
		}		
		return i;
	}
	public PageBean getExamQuestionPageBean(int p) {
		PageBean pb = new PageBean();
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		try {
			String hql = "from Shiti ";
			Query query = session.createQuery(hql).setCacheable(true);
		
			int count=query.list().size();
			
			pb.setPagesize(3);
			pb.setCount(count);
			pb.setP(p);
			
			query.setFirstResult((p-1)*3);
			query.setMaxResults(pb.getPagesize());
			List<Shiti> eqList = query.list();
			pb.setData(eqList);
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
		}
//		
//	public PageBean find(int p) {
//		PageBean pb = new PageBean();
//		Session session=HibernateSessionFactory.getSession();
//		String hql = "select count(ss) cnt from Shiti ss";// ��ѯ��¼������
////		try {
//			Statement st = con.createStatement();
//			ResultSet rs1 = st.executeQuery(sql);
//			rs1.next();
//			pb.setPagesize(2);// ����ÿҳ��ʾ4����¼�����ȵ���
//			pb.setCount(rs1.getInt("cnt"));// ��ε���
//			pb.setP(p);// �����ã�����������һ��ע�����˳��
//			rs1.close();
//			sql = "select top " + pb.getPagesize() + " * ";
//			sql += "from users ";
//			sql += "where uid not in";
//			sql += "(select top " + (pb.getP() - 1) * pb.getPagesize()
//					+ " uid from users)";
//			ResultSet rs2 = st.executeQuery(sql);
//			while (rs2.next()) {
//				Users u = new Users();
//				u.setUid(rs2.getInt("uid"));
//				u.setUname(rs2.getString("uname"));
//				u.setUpwd(rs2.getString("upwd"));
//				u.setSex(rs2.getString("sex"));
//				u.setBirth(rs2.getString("birth"));
//				u.setAihao(rs2.getString("aihao"));
//				pb.addData(u);
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		} finally {
//			ConFactory.close(con);
//		}
		return pb;

	}
	public List<Shiti> shitishow(int id) {
		Session session=HibernateSessionFactory.getSession();
		String hql="from Shiti s where stid ="+id;
		Query query=session.createQuery(hql);	
		List<Shiti> list=query.list();
		return list;
	}
	public PageBean find(int p) {
		// TODO Auto-generated method stub
		return null;
	}
	public ArrayList<Kemu> getSubjectById(int subid) {
		Session session=HibernateSessionFactory.getSession();
		ArrayList<Kemu> list = new ArrayList<Kemu>();
		String hql = "from Kemu where kmid=:subid";
		Query query = session.createQuery(hql);
		query.setInteger("subid", subid);
		list = (ArrayList<Kemu>) query.list();
		return list;
	}

}
