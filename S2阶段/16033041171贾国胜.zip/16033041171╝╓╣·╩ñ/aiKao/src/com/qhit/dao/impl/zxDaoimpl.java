package com.qhit.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.qhit.bean.Shijuan;
import com.qhit.bean.Shiti;
import com.qhit.bean.Stu;
import com.qhit.bean.StuShiti;
import com.qhit.dao.HibernateSessionFactory;
import com.qhit.dao.zxDao;
import com.qhit.util.PageBean;

public class zxDaoimpl implements zxDao {
	static Session session=HibernateSessionFactory.getSession();
	public List<Shijuan> list() {
	   	String hql01="select s from Shijuan s join s.banji b";
	   	Query query=session.createQuery(hql01);	
			List<Shijuan> list=query.list();
		return list;
	}
	public PageBean find(int p) {
		PageBean pb = new PageBean();
		Transaction transaction = session.beginTransaction();
		String hql3="from Shiti ";
		Query query = session.createQuery(hql3).setCacheable(true);
   		
   		
   		int count=query.list().size();
		pb.setPagesize(1);
		pb.setCount(count);
		pb.setP(p);
		query.setFirstResult((p-1)*1);
		query.setMaxResults(pb.getPagesize());
		List<Shiti> sj = query.list();
		pb.setData(sj);
		transaction.commit();
		return pb;
	}
	public List<Shijuan> stlist(int stid) {
		String hql="from Shijuan where sjid="+stid;
   		Query query=session.createQuery(hql);
   		List<Shijuan> sj= query.list();
		return sj;
		
	}
	public int anwer(String anwer,int sjid) {
		int i=0;
		String hql="select s from Shiti s where daan="+anwer+" and stid="+sjid;
		Query query=session.createQuery(hql);
		List<Shiti> list=query.list();
		for (Shiti shiti : list) {
			i=1;
		}
		return i;
	}
	public int addsss(String daan) {
		int i=0;
		Shijuan ss0=(Shijuan)session.get(Shijuan.class, 1);
		Stu stu=(Stu)session.get(Stu.class, 1);
		Shiti shiti=(Shiti)session.get(Shiti.class, 1);
		StuShiti ss001=new StuShiti();
		ss001.setShijuan(ss0);
		ss001.setShiti(shiti);
		ss001.setStu(stu);
		ss001.setStuanewr(daan);
		try {
			session.beginTransaction();
			session.save(ss001);
			session.beginTransaction().commit();
		} catch (Exception e) {
			i=1;
		}
		
		return i;
	}

}
