package com.qhit.dao;

import java.util.List;

import com.qhit.bean.Chengji;
import com.qhit.bean.Shiti;

public interface cjDao {
	public List<Chengji> find();
	public List<Chengji> selfind(Chengji cj);
	public List<Shiti> selshiti(Shiti st);
}
