package com.qhit.util;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.JspFactory;
import javax.servlet.jsp.PageContext;

import com.jspsmart.upload.File;
import com.jspsmart.upload.Files;
import com.jspsmart.upload.SmartUpload;
import com.jspsmart.upload.SmartUploadException;

public class UpDown extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		SmartUpload su=new SmartUpload();
		PageContext pageContext=JspFactory.getDefaultFactory().getPageContext(this,request, response, null, true, 10000, true);
		su.initialize(pageContext);
		String filename=request.getParameter("fname");
		try {
			su.setContentDisposition(null);
			su.downloadFile("/upload/"+filename);
		} catch (SmartUploadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		SmartUpload su=new SmartUpload();
		PageContext pageContext=JspFactory.getDefaultFactory().getPageContext(this,request, response, null, true, 10000, true);
		su.initialize(pageContext);
		try {
			su.setAllowedFilesList("jsp,jpg,png");
			su.setDeniedFilesList("exe");
			su.setMaxFileSize(1204*1024);
			su.upload();
			System.out.println(su.getRequest().getParameter("username"));
			Files fs=su.getFiles();
			File f=fs.getFile(0);
			f.saveAs("/upload/"+f.getFileName());
			response.sendRedirect("info.jsp");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
