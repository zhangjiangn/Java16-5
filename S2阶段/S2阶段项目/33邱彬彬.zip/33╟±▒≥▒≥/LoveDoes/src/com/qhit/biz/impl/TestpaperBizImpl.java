package com.qhit.biz.impl;

import java.util.ArrayList;

import com.qhit.bean.Classes;
import com.qhit.bean.PageBean;
import com.qhit.bean.Subjects;
import com.qhit.bean.Testpapers;
import com.qhit.bean.Testquestions;
import com.qhit.biz.TestpaperBiz;
import com.qhit.dao.TestpaperDao;
import com.qhit.dao.impl.TestpaperDaoImpl;


public class TestpaperBizImpl implements TestpaperBiz {
	
	private TestpaperDao dao=new TestpaperDaoImpl();

	@Override
	public ArrayList<Subjects> selectSubjects() {
		return dao.selectSubjects();
	}

	@Override
	public PageBean selectTestpapers(int p,int subid,String state) {
		// TODO Auto-generated method stub
		return dao.selectTestpapers(p,subid, state);
	}

	@Override
	public PageBean selectTestpapers(int p,int subid) {
		// TODO Auto-generated method stub
		return dao.selectTestpapers(p,subid);
	}

	@Override
	public ArrayList<Classes> selectClasses() {
		// TODO Auto-generated method stub
		return dao.selectClasses();
	}

	@Override
	public ArrayList<Testpapers> updatestate(int tpid,String state) {
		// TODO Auto-generated method stub
		return dao.updatestate(tpid, state);
	}

	@Override
	public ArrayList<Testpapers> deletetestpaper(int tpid) {
		// TODO Auto-generated method stub
		return dao.deletetestpaper(tpid);
	}

	@Override
	public ArrayList<Testquestions> looktestpaper(int tpid) {
		// TODO Auto-generated method stub
		return dao.looktestpaper(tpid);
	}

	@Override
	public Testpapers createtestpaper(Testpapers ts,int subid) {
		// TODO Auto-generated method stub
		return dao.createtestpaper(ts, subid);
	}

	@Override
	public int associated(int tpid, String tqid) {
		// TODO Auto-generated method stub
		return dao.associated(tpid, tqid);
	}

	@Override
	public ArrayList<Testpapers> begintest(int tpid, String state, String clas) {
		// TODO Auto-generated method stub
		return dao.begintest(tpid, state, clas);
	}

	@Override
	public int random(int tp, int abc, String danxuan, String jiandan) {
		// TODO Auto-generated method stub
		return dao.random(tp, abc, danxuan, jiandan);
	}

	


}
