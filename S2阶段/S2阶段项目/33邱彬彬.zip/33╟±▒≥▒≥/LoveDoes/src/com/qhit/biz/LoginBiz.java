package com.qhit.biz;

import org.hibernate.Session;

import com.qhit.bean.Students;
import com.qhit.bean.Users;
import com.qhit.dao.HibernateSessionFactory;

public interface LoginBiz {
	
	public Session session=HibernateSessionFactory.getSession();
	public Students loginStudent(String name,String pwd);
	public Users loginUsers(String name,String pwd);

}
