package com.qhit.action;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.io.File;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.qhit.bean.Directions;
import com.qhit.bean.PageBean;
import com.qhit.bean.Stages;
import com.qhit.bean.Subjects;
import com.qhit.bean.Testquestions;
import com.qhit.biz.HoutaiBiz;
import com.qhit.biz.impl.HoutaiBizImpl;
//
public class HoutaiAction {
	//����Ա��¼-������
	
	private HoutaiBiz houtaiBiz=new HoutaiBizImpl();
	private ArrayList<Directions> dirList ;
	private ArrayList<Stages> staList ;
	private ArrayList<Subjects> subjects;//��Ŀ��
	private ArrayList<Stages> stages;//�׶α�
	private ArrayList<Subjects> subList = new ArrayList<Subjects>();
	private String dirOpValue;
	private String staOpVlaue;
	private ArrayList<Testquestions> testquestionsList;
	private Testquestions testquestions;
	private int subid;
	private int subname;
	
	//��ҳ
	private int p;
	private PageBean pb;
	
	//����
	private String name;
	private File uploadfile;
	private String uploadfileFileName;
	private String uploadfileContentType;
	
	private String downfile_name;
	private InputStream downfile_is;

	
	
	
	public int getP() {
		return p;
	}
	public void setP(int p) {
		this.p = p;
	}
	public int getSubname() {
		return subname;
	}
	public void setSubname(int subname) {
		this.subname = subname;
	}
	private int tqid;
	
	

	
	public int getTqid() {
		return tqid;
	}
	public void setTqid(int tqid) {
		this.tqid = tqid;
	}
	//��ѯ.���
	public String question(){
		dirList=houtaiBiz.selectDirections();
		staList=houtaiBiz.selectStages();
		subjects = houtaiBiz.getSubjectByDidAndStaid(1, 1);
		stages = houtaiBiz.getStageById(1);
		for (Subjects sub : subjects) {
			int esubid= sub.getSubid();
			int Num = houtaiBiz.getCountBySubid(esubid);
			sub.setCount(Num);
			subList.add(sub);
		}
		ServletActionContext.getRequest().getSession().setAttribute("subList", subList);
		 return "questionadmin";
	}
	//�¼�
	public String dirChange(){
		int did = Integer.parseInt(dirOpValue);
		int staid = Integer.parseInt(staOpVlaue);
		System.out.println(did);
		System.out.println(staid);
		dirList = houtaiBiz.getDirList(did);
		staList = houtaiBiz.getStageList(staid);
		subjects = houtaiBiz.getSubjectByDidAndStaid(did, staid);
		stages = houtaiBiz.getStageById(staid);
		for (Subjects sub : subjects) {
			int esubid= sub.getSubid();
			int Num = houtaiBiz.getCountBySubid(esubid);
			sub.setCount(Num);
			subList.add(sub);
		}
		ServletActionContext.getRequest().getSession().setAttribute("subList", subList);
		return "questionadmin";
	}
	
	public String staChange(){
		int did = Integer.parseInt(dirOpValue);
		int staid = Integer.parseInt(staOpVlaue);
		dirList = houtaiBiz.getDirList(did);
		staList = houtaiBiz.getStageList(staid);
		subjects = houtaiBiz.getSubjectByDidAndStaid(did, staid);
		stages = houtaiBiz.getStageById(staid);
		for (Subjects sub : subjects) {
			int esubid= sub.getSubid();
			int Num = houtaiBiz.getCountBySubid(esubid);
			sub.setCount(Num);
			subList.add(sub);
		}
		ServletActionContext.getRequest().getSession().setAttribute("subList", subList);
		return "questionadmin";
	}
	
	//�����б�
	public String questionlist(){
		System.out.println(subid);
		subjects=houtaiBiz.selectsubjects(subid);
		testquestionsList = houtaiBiz.selectquestion(subid);
		if (pb!=null) {
			
			return "questionlist";
		}else{
			return "questionadmin";
		}
	}
	
	
	//��������
	public String addquestion(){
		int i=houtaiBiz.addquestion(testquestions, subid);
		if(i==1){
		return  "addsuccess";
		}
		return "addfailure";
		
	}
	
	//�༭������ʾ
	public String updatequestion(){
		System.out.println("tqid="+tqid);
		testquestionsList=houtaiBiz.selectquestionone(tqid);
		
		return "updatequestion";
	}
	//����༭
	public String updatequestion2(){
		System.out.println("tqid="+tqid);
		int i=houtaiBiz.updatequestion(testquestions, tqid);
		if(i==1){
			ServletActionContext.getRequest().getSession().setAttribute("prompt", "�ɹ�");
			return  "updateprompt";
			}
			ServletActionContext.getRequest().getSession().setAttribute("prompt", "ʧ��");
			return "updateprompt";
	}
	
	
	
	//�����ҳ
	public String paging(){
		if(p==0){
			p=1;
		}
		subjects=houtaiBiz.selectsubjects(subid);
		pb=houtaiBiz.question(p, subid);
		return "questionlist";
		
	}
	
	public PageBean getPb() {
		return pb;
	}
	public void setPb(PageBean pb) {
		this.pb = pb;
	}
	//����
	public String download(){
		
		try {
			String destfile=ServletActionContext.getServletContext().getRealPath("/")+"upload/"+downfile_name;
			downfile_is=new FileInputStream(destfile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return "down";
		
	}
	
	//�ϴ�
	public String upload(){
		try {
			InputStream is=new FileInputStream(uploadfile);
			String Filepath=ServletActionContext.getServletContext().getRealPath("/")+"upload/"+uploadfileFileName;;
			OutputStream os= new FileOutputStream(Filepath);
			byte[]buffer=new byte[8096];
			int len=0;
			while ((len=is.read(buffer))!=-1) {
				os.write(buffer, 0, len);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "uploadprompt";
	}
	
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public File getUploadfile() {
		return uploadfile;
	}
	public void setUploadfile(File uploadfile) {
		this.uploadfile = uploadfile;
	}
	public String getUploadfileFileName() {
		return uploadfileFileName;
	}
	public void setUploadfileFileName(String uploadfileFileName) {
		this.uploadfileFileName = uploadfileFileName;
	}
	public String getUploadfileContentType() {
		return uploadfileContentType;
	}
	public void setUploadfileContentType(String uploadfileContentType) {
		this.uploadfileContentType = uploadfileContentType;
	}
	public String getDownfile_name() {
		return downfile_name;
	}
	public void setDownfile_name(String downfileName) {
		downfile_name = downfileName;
	}
	public InputStream getDownfile_is() {
		return downfile_is;
	}
	public void setDownfile_is(InputStream downfileIs) {
		downfile_is = downfileIs;
	}
	
	public HoutaiBiz getHoutaiBiz() {
		return houtaiBiz;
	}
	public void setHoutaiBiz(HoutaiBiz houtaiBiz) {
		this.houtaiBiz = houtaiBiz;
	}
	public ArrayList<Directions> getDirList() {
		return dirList;
	}
	public void setDirList(ArrayList<Directions> dirList) {
		this.dirList = dirList;
	}
	public ArrayList<Stages> getStaList() {
		return staList;
	}
	public void setStaList(ArrayList<Stages> staList) {
		this.staList = staList;
	}
	public ArrayList<Subjects> getSubjects() {
		return subjects;
	}
	public void setSubjects(ArrayList<Subjects> subjects) {
		this.subjects = subjects;
	}
	public ArrayList<Stages> getStages() {
		return stages;
	}
	public void setStages(ArrayList<Stages> stages) {
		this.stages = stages;
	}
	public ArrayList<Subjects> getSubList() {
		return subList;
	}
	public void setSubList(ArrayList<Subjects> subList) {
		this.subList = subList;
	}
	public String getDirOpValue() {
		return dirOpValue;
	}
	public void setDirOpValue(String dirOpValue) {
		this.dirOpValue = dirOpValue;
	}
	public String getStaOpVlaue() {
		return staOpVlaue;
	}
	public void setStaOpVlaue(String staOpVlaue) {
		this.staOpVlaue = staOpVlaue;
	}
	public ArrayList<Testquestions> getTestquestionsList() {
		return testquestionsList;
	}
	public void setTestquestionsList(ArrayList<Testquestions> testquestionsList) {
		this.testquestionsList = testquestionsList;
	}
	public Testquestions getTestquestions() {
		return testquestions;
	}
	public void setTestquestions(Testquestions testquestions) {
		this.testquestions = testquestions;
	}
	public int getSubid() {
		return subid;
	}
	public void setSubid(int subid) {
		this.subid = subid;
	}
	
	





}
