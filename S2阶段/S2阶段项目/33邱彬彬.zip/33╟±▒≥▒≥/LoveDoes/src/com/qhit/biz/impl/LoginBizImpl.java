package com.qhit.biz.impl;


import java.util.ArrayList;

import org.hibernate.Session;

import com.qhit.bean.Students;
import com.qhit.bean.Users;
import com.qhit.biz.LoginBiz;
import com.qhit.dao.LoginDao;
import com.qhit.dao.impl.LoginDaoImpl;








public class LoginBizImpl implements LoginBiz {

	private LoginDao dao=new LoginDaoImpl();

	@Override
	public Students loginStudent(String name, String pwd) {
		// TODO Auto-generated method stub
		return dao.loginStudent(name, pwd);
	}

	@Override
	public Users loginUsers(String name, String pwd) {
		// TODO Auto-generated method stub
		return dao.loginUsers(name, pwd);
	}

	

	

	

	
	
	
}
