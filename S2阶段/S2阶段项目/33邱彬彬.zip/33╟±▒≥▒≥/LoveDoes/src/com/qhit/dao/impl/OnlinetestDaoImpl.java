package com.qhit.dao.impl;

import java.util.ArrayList;

import org.hibernate.Query;

import com.qhit.bean.Classes;
import com.qhit.bean.Grades;
import com.qhit.bean.Students;
import com.qhit.bean.StudentsTq;
import com.qhit.bean.Subjects;
import com.qhit.bean.Testpapers;
import com.qhit.bean.TpTq;
import com.qhit.dao.OnlinetestDao;

public class OnlinetestDaoImpl implements OnlinetestDao {

	@Override
	public ArrayList<Classes> selectClasses(String name, String pwd) {
		ArrayList<Classes> classes = new ArrayList<Classes>();
		String sql = "select cname from classes where cid=(select cid from students where sname='"+name+"' and spwd='"+pwd+"')";
		Query query = session.createSQLQuery(sql);
		return (ArrayList<Classes>) query.list();
	}

	

	@Override
	public ArrayList<Classes> selectClassesid(String name, String pwd) {
		ArrayList<Classes> classes = new ArrayList<Classes>();
		String sql = "select cid from classes where cid=(select cid from students where sname='"+name+"' and spwd='"+pwd+"')";
		Query query = session.createSQLQuery(sql);
		
		return (ArrayList<Classes>) query.list();
	}
	
	@Override
	public ArrayList<Testpapers> selectTestpapers(String cid, String state) {
		int ccid=Integer.parseInt(cid);
		String hql = " from Testpapers where cid=:ccid and state=:state";
		Query query = session.createQuery(hql);
		query.setString("ccid", cid);
		query.setString("state", state);
		
		return (ArrayList<Testpapers>) query.list();
	}



	@Override
	public Testpapers selectTestpapers(int tpid) {
		Testpapers testpapers=new Testpapers();
		String hql = " from Testpapers where tpid=:tpid";
		Query query = session.createQuery(hql);
		query.setInteger("tpid", tpid);
		testpapers=(Testpapers) query.uniqueResult();
		return testpapers;
	}



	@Override
	public ArrayList<TpTq> selectTpTq(int tpid) {
		String hql = " from TpTq where tpid=:tpid";
		Query query = session.createQuery(hql);
		query.setInteger("tpid", tpid);
		return (ArrayList<TpTq>) query.list();
	}


//��TpTq���������ssid
	@Override
	public int selectTpTqid(int tpid, int tqid) {
		String sql = "select ssid from tp_tq t where tpid=:tpid and tqid=:tqid";
		Query query = session.createSQLQuery(sql);
		query.setInteger("tpid", tpid);
		query.setInteger("tqid", tqid);
		Object o = query.uniqueResult();
		String a=o.toString();
		int ssid=Integer.parseInt(a);
		return ssid;
	}


//���Ӵ�
	@Override
	public int addStudentsTq(int sid, int ssid, String sanswer) {
		StudentsTq st=new StudentsTq();
		Students stu=(Students) session.get(Students.class, sid);
		TpTq pq=(TpTq) session.get(TpTq.class, ssid);
		st.setStudents(stu);
		st.setTpTq(pq);
		st.setSanswer(sanswer);
		session.beginTransaction();
		session.save(st);
		session.beginTransaction().commit();
		return 0;
	}



	@Override
	public int selectStudentsid(String name, String pwd) {
		String sql = "select sid from students where sname=:name and spwd=:pwd";
		Query query = session.createSQLQuery(sql);
		query.setString("name", name);
		query.setString("pwd", pwd);
		Object o = query.uniqueResult();
		String a=o.toString();
		int sid=Integer.parseInt(a);
		return sid;
	}



	@Override
	public ArrayList<TpTq> selectTpTqid(int tpid) {
		String sql = "select ssid from tp_tq t where tpid=:tpid";
		Query query = session.createSQLQuery(sql);
		query.setInteger("tpid", tpid);
		return (ArrayList<TpTq>) query.list();
	}



	@Override
	public String selectStudenrsTqsanwer(int sid, int ssid) {
		String sql = "select sanswer from students_tq where sid=:sid and ssid=:ssid";
		Query query = session.createSQLQuery(sql);
		query.setInteger("sid", sid);
		query.setInteger("ssid", ssid);
		Object o = query.uniqueResult();
		String sanwer=o.toString();
		return sanwer;
	}



	@Override
	public int selectStudentsTqsssid(int sid, int ssid) {
		String sql = "select sssid from students_tq where sid=:sid and ssid=:ssid";
		Query query = session.createSQLQuery(sql);
		query.setInteger("sid", sid);
		query.setInteger("ssid", ssid);
		Object o = query.uniqueResult();
		String id=o.toString();
		int ssid1=Integer.parseInt(id);
		return ssid1;
	}



	//�޸Ĵ�
	@Override
	public int updatesanswer(int sssid, String sanswer) {
		StudentsTq s=(StudentsTq) session.get(StudentsTq.class, sssid);
		s.setSanswer(sanswer);
		session.beginTransaction();
		session.save(s);
		session.beginTransaction().commit();
		return 0;
	}



	//��ѯ�Ƿ�������
	@Override
	public ArrayList<StudentsTq> selectsssidyesno(int sid, int ssid) {
		
			String sql = "select sssid from students_tq where sid=:sid and ssid=:ssid";
			Query query = session.createSQLQuery(sql);
			query.setInteger("sid", sid);
			query.setInteger("ssid", ssid);
		return (ArrayList<StudentsTq>) query.list();
	}



	//���ӿ������Ե÷���Ϣ
	@Override
	public int addGrades(int sid, int tpid, String starttime, String endtime,String grade) {
		try {
			Grades gr=new Grades();
			Students s=(Students) session.get(Students.class, sid);
			gr.setStudents(s);
			gr.setTpid(tpid);
			gr.setStarttime(starttime);
			gr.setEndtime(endtime);
			gr.setGrade(grade);
			session.beginTransaction();
			session.save(gr);
			session.beginTransaction().commit();
		} catch (Exception e) {
			session.beginTransaction().rollback();
		}
		return 0;
	}



	
	
	

}
