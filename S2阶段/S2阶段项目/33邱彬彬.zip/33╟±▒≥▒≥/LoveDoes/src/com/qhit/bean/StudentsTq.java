package com.qhit.bean;

/**
 * StudentsTq entity. @author MyEclipse Persistence Tools
 */

public class StudentsTq implements java.io.Serializable {

	// Fields

	private Integer sssid;
	private Students students;
	private TpTq tpTq;
	private String sanswer;

	// Constructors

	/** default constructor */
	public StudentsTq() {
	}

	/** minimal constructor */
	public StudentsTq(Integer sssid, Students students, TpTq tpTq) {
		this.sssid = sssid;
		this.students = students;
		this.tpTq = tpTq;
	}

	/** full constructor */
	public StudentsTq(Integer sssid, Students students, TpTq tpTq,
			String sanswer) {
		this.sssid = sssid;
		this.students = students;
		this.tpTq = tpTq;
		this.sanswer = sanswer;
	}

	// Property accessors

	public Integer getSssid() {
		return this.sssid;
	}

	public void setSssid(Integer sssid) {
		this.sssid = sssid;
	}

	public Students getStudents() {
		return this.students;
	}

	public void setStudents(Students students) {
		this.students = students;
	}

	public TpTq getTpTq() {
		return this.tpTq;
	}

	public void setTpTq(TpTq tpTq) {
		this.tpTq = tpTq;
	}

	public String getSanswer() {
		return this.sanswer;
	}

	public void setSanswer(String sanswer) {
		this.sanswer = sanswer;
	}

}