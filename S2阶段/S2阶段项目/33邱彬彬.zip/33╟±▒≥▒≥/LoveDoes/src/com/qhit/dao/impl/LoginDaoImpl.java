package com.qhit.dao.impl;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.qhit.bean.Students;
import com.qhit.bean.Users;
import com.qhit.dao.HibernateSessionFactory;
import com.qhit.dao.LoginDao;


public class LoginDaoImpl implements LoginDao {
	public Session getsSession() {
		return HibernateSessionFactory.getSession();
	}
	public Transaction transaction() {
		return getsSession().beginTransaction();
	}

	@Override
	public Students loginStudent(String sname, String spwd) {
		
		
		String hql="select s from Students s where s.sname=? and s.spwd=?";
		Query query=getsSession().createQuery(hql);
		query.setString(0, sname);
		query.setString(1, spwd);
		
		return (Students)query.uniqueResult();
	}
		

	@Override
	public Users loginUsers(String uname, String upwd) {
		
		String hql="select u from Users u where u.uname=? and u.upwd=?";
		Query query=getsSession().createQuery(hql);
		query.setString(0, uname);
		query.setString(1, upwd);
		return (Users) query.uniqueResult();
	}

}
