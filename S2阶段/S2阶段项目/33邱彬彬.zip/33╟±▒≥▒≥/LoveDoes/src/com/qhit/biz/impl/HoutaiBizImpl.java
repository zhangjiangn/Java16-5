package com.qhit.biz.impl;


import java.util.ArrayList;

import org.hibernate.Session;


import com.qhit.bean.Directions;
import com.qhit.bean.PageBean;
import com.qhit.bean.Stages;
import com.qhit.bean.Subjects;
import com.qhit.bean.Directions;
import com.qhit.bean.Testquestions;
import com.qhit.biz.HoutaiBiz;
import com.qhit.bean.Stages;
import com.qhit.dao.HoutaiDao;
import com.qhit.dao.impl.HoutaiDaoImpl;






public class HoutaiBizImpl implements HoutaiBiz {

	private HoutaiDao dao=new HoutaiDaoImpl();
		
	
	@Override
	public ArrayList<Directions> selectDirections() {
		// TODO Auto-generated method stub
		return dao.selectDirections();
	}


	@Override
	public ArrayList<Stages> selectStages() {
		// TODO Auto-generated method stub
		return dao.selectStages();
	}


	@Override
	public int getCountBySubid(int subid) {
		// TODO Auto-generated method stub
		return dao.getCountBySubid(subid);
	}


	@Override
	public ArrayList<Stages> getStageById(int stid) {
		// TODO Auto-generated method stub
		return dao.getStageById(stid);
	}


	@Override
	public ArrayList<Subjects> getSubjectByDidAndStaid(int did, int stid) {
		// TODO Auto-generated method stub
		return dao.getSubjectByDidAndStaid(did, stid);
	}


	@Override
	public ArrayList<Directions> getDirList(int order) {
		// TODO Auto-generated method stub
		return dao.getDirList(order);
	}


	@Override
	public ArrayList<Stages> getStageList(int order) {
		// TODO Auto-generated method stub
		return dao.getStageList(order);
	}


	@Override
	public ArrayList<Testquestions> selectquestion(int subid) {
		// TODO Auto-generated method stub
		return dao.selectquestion(subid);
	}


	@Override
	public ArrayList<Subjects> selectsubjects(int subid) {
		// TODO Auto-generated method stub
		return dao.selectsubjects(subid);
	}


	@Override
	public int addquestion(Testquestions t, int subid) {
		// TODO Auto-generated method stub
		return dao.addquestion(t, subid);
	}


	@Override
	public int updatequestion(Testquestions ut,int tqid) {
		// TODO Auto-generated method stub
		return dao.updatequestion(ut,tqid);
	}


	@Override
	public ArrayList<Testquestions> selectquestionone(int tqid) {
		// TODO Auto-generated method stub
		return dao.selectquestionone(tqid);
	}


	@Override
	public PageBean question(int p, int subid) {
		// TODO Auto-generated method stub
		return dao.question(p, subid);
	}


	@Override
	public ArrayList<Directions> getDirectionById(int did) {
		// TODO Auto-generated method stub
		return dao.getDirectionById(did);
	}





	
	
	

	}


