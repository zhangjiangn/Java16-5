package com.qhit.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.qhit.bean.Directions;
import com.qhit.bean.PageBean;
import com.qhit.bean.Stages;
import com.qhit.bean.Subjects;
import com.qhit.bean.Testquestions;
import com.qhit.dao.HibernateSessionFactory;
import com.qhit.dao.HoutaiDao;


public class HoutaiDaoImpl implements HoutaiDao {
	
	
	//�鷽��
	@Override
	public ArrayList<Directions> selectDirections() {
		Query query=session.createQuery("from Directions");
		
		return (ArrayList<Directions>) query.list();
	}

	//��׶�
	@Override
	public ArrayList<Stages> selectStages() {
		Query query=session.createQuery("from Stages");
		return (ArrayList<Stages>) query.list();
	}

	//��������
	@Override
	public int getCountBySubid(int subid) {
		int count = 0;
		String sql = "select count(*) from testquestions where subid=:subid group by subid";
		SQLQuery sqlquery = session.createSQLQuery(sql);
		sqlquery.setInteger("subid", subid);
		Object o = sqlquery.uniqueResult();
		if (o==null) {
			count = 0;
		}else{
			count = Integer.parseInt(o.toString());
		}
		return count;
	}

	@Override
	public ArrayList<Stages> getStageById(int stid) {
		ArrayList<Stages> stages = new ArrayList<Stages>();
		String hql = "from Stages where stid=:stid";
		Query query = session.createQuery(hql);
		query.setInteger("stid", stid);
		stages = (ArrayList<Stages>) query.list();
		return stages;
	}

	@Override
	public ArrayList<Subjects> getSubjectByDidAndStaid(int did, int stid) {
		ArrayList<Subjects> subjects = new ArrayList<Subjects>();
		String hql = "from Subjects where did=:did and stid=:stid";
		Query query = session.createQuery(hql);
		query.setInteger("did", did);
		query.setInteger("stid", stid);
		subjects =  (ArrayList<Subjects>) query.list();
		return subjects;
	}

	@Override
	public ArrayList<Directions> getDirList(int order) {
		ArrayList<Directions> list = new ArrayList<Directions>();
		switch (order) {
		case 1:
			String hql = "from Directions";
			Query query = session.createQuery(hql);
			list = (ArrayList<Directions>) query.list();
			break;
		default:
			String hql2 = "from Directions order by did desc";
			Query query2 = session.createQuery(hql2);
			list = (ArrayList<Directions>) query2.list();
			break;
		}
		return list;
	}

	@Override
	public ArrayList<Stages> getStageList(int order) {
		ArrayList<Stages> list = new ArrayList<Stages>();
		switch (order) {
		case 1:
			String hql = "from Stages";
			Query query = session.createQuery(hql);
			list = (ArrayList<Stages>) query.list();
			break;

		default:
			String hql2 = "from Stages order by stid desc";
			Query query2 = session.createQuery(hql2);
			list = (ArrayList<Stages>) query2.list();
			break;
		}
		return list;
	}

	@Override
	public ArrayList<Testquestions> selectquestion(int subid) {
		ArrayList<Testquestions> list = new ArrayList<Testquestions>();
		String hql = "from Testquestions where subid=:subid";
		Query query = session.createQuery(hql);
		query.setInteger("subid", subid);
		list = (ArrayList<Testquestions>) query.list();
		return list;
	}

	//��ѯ��Ŀ
	@Override
	public ArrayList<Subjects> selectsubjects(int subid) {
		ArrayList<Subjects> list = new ArrayList<Subjects>();
		String hql = "from Subjects where subid=:subid";
		Query query = session.createQuery(hql);
		query.setInteger("subid", subid);
		list = (ArrayList<Subjects>) query.list();
		return list;
	}

	//����
	@Override
	public int addquestion(Testquestions t, int subid) {
		int i=1;
		try {
			Subjects s=(Subjects) session.get(Subjects.class, subid);
			t.setSubjects(s);
			t.setTopicbigtype("����");
			session.beginTransaction();
			session.save(t);
			session.beginTransaction().commit();
		} catch (Exception e) {
			i=0;
			session.beginTransaction().rollback();
		}
		return i;
	}

	//�޸�
	@Override
	public int updatequestion(Testquestions ut,int tqid) {
		int i=1;
		try {
			int subid=ut.getSubjects().getSubid();
			
			//Subjects s= (Subjects) session.get(Testquestions.class, subid);
			Testquestions t=(Testquestions) session.get(Testquestions.class, tqid);
			t.setSubjects(ut.getSubjects());
			t.setTqid(t.getTqid());
			t.setAnswer(ut.getAnswer());
			t.setChapters(ut.getChapters());
			t.setDifficulty(ut.getDifficulty());
			t.setOptionsA(ut.getOptionsA());
			t.setOptionsB(ut.getOptionsB());
			t.setOptionsC(ut.getOptionsC());
			t.setOptionsD(ut.getOptionsD());
			t.setTopicbigtype("����");
			t.setTopictype(ut.getTopictype());
			t.setTqcontent(ut.getTqcontent());
			t.setDifficulty(ut.getDifficulty());
			
			session.update(t);
			session.beginTransaction().commit();
		}catch (Exception e) {
			i=0;
			session.beginTransaction().rollback();
		}
		return i;
	}
	
	//ͨ��id��ѯ����ĵ�����ʾ���޸Ľ���
	@Override
	public ArrayList<Testquestions> selectquestionone(int tqid) {
		ArrayList<Testquestions> list = new ArrayList<Testquestions>();
		String hql = "from Testquestions where tqid=:tqid";
		Query query = session.createQuery(hql);
		query.setInteger("tqid", tqid);
		list = (ArrayList<Testquestions>) query.list();
		return list;
	}

	
	//��ҳ
	public PageBean question(int p,int subid) {
		System.out.println(p);
		PageBean pb=new PageBean();
		try {
			String hql = "from Testquestions where subid=:subid";
			Query query = session.createQuery(hql);
			query.setInteger("subid", subid);
			int count=query.list().size();
			pb.setPagesize(8);//ÿҳ����
			pb.setCount(count);//����
			//%�ж��������Ϊ0˵���в���һҳ��ʣ�࣬Ҫ��һҳ
			if(count%pb.getPagesize()!=0){
				pb.setPagetotal(count/pb.getPagesize()+1);
			}else{
				pb.setPagetotal(count/pb.getPagesize());//ҳ��
			}
			
			pb.setP(p);
			
			System.out.println(pb.getP());
			query.setFirstResult((pb.getP()-1)*pb.getPagesize());
			query.setMaxResults(pb.getPagesize());
			List<Testquestions> list=query.list();
			pb.setData(list);
			session.beginTransaction().commit();
		}catch (Exception e) {
			session.beginTransaction().rollback();
		}
		return pb;
	}

	@Override
	public ArrayList<Directions> getDirectionById(int did) {
		ArrayList<Directions> directions = new ArrayList<Directions>();
		String hql = "from Directions where did=:did";
		Query query = session.createQuery(hql);
		query.setInteger("did", did);
		directions = (ArrayList<Directions>) query.list();
		return directions;
	}


}
