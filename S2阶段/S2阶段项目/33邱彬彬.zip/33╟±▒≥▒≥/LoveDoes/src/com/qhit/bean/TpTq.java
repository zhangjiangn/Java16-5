package com.qhit.bean;

/**
 * TpTq entity. @author MyEclipse Persistence Tools
 */

public class TpTq implements java.io.Serializable {

	// Fields

	private Integer ssid;
	private Testpapers testpapers;
	private Testquestions testquestions;

	// Constructors

	/** default constructor */
	public TpTq() {
	}

	/** full constructor */
	public TpTq(Integer ssid, Testpapers testpapers, Testquestions testquestions) {
		this.ssid = ssid;
		this.testpapers = testpapers;
		this.testquestions = testquestions;
	}

	// Property accessors

	public Integer getSsid() {
		return this.ssid;
	}

	public void setSsid(Integer ssid) {
		this.ssid = ssid;
	}

	public Testpapers getTestpapers() {
		return this.testpapers;
	}

	public void setTestpapers(Testpapers testpapers) {
		this.testpapers = testpapers;
	}

	public Testquestions getTestquestions() {
		return this.testquestions;
	}

	public void setTestquestions(Testquestions testquestions) {
		this.testquestions = testquestions;
	}

}