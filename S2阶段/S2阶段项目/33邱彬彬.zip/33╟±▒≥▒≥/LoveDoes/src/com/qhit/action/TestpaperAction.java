package com.qhit.action;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.apache.struts2.ServletActionContext;

import com.qhit.bean.Classes;
import com.qhit.bean.Directions;
import com.qhit.bean.PageBean;
import com.qhit.bean.Stages;
import com.qhit.bean.Subjects;
import com.qhit.bean.Testpapers;
import com.qhit.bean.Testquestions;
import com.qhit.biz.HoutaiBiz;
import com.qhit.biz.TestpaperBiz;
import com.qhit.biz.impl.HoutaiBizImpl;
import com.qhit.biz.impl.TestpaperBizImpl;



public class TestpaperAction {
	//����Ա��¼-�Ծ�����
	private HoutaiBiz houtaiBiz=new HoutaiBizImpl();
	private TestpaperBiz testpaper=new TestpaperBizImpl();
	private ArrayList<Directions> dirList ;
	private ArrayList<Stages> staList ;
	private ArrayList<Subjects> subList;//��Ŀ��
	private ArrayList<Classes> classesList;//��༶
	private ArrayList<Testquestions> testquestionsList;//��༶
	private Testpapers testpapers;//�Ծ�
	

	public Testpapers getTestpapers() {
		return testpapers;
	}

	public void setTestpapers(Testpapers testpapers) {
		this.testpapers = testpapers;
	}

	

	private String dirOpValue;
	private String staOpVlaue;
	private String subOpVlaue;
	private String state;
	private String subid;
	private int tpid;
	private int cmd;//Ϊ���жϷ�ҳ�ǲ��Ǹս���
	private ArrayList checkbox;
	private String clas;
	
	
	
	
	

	public String getClas() {
		return clas;
	}

	public void setClas(String clas) {
		this.clas = clas;
	}

	public ArrayList getCheckbox() {
		return checkbox;
	}

	public void setCheckbox(ArrayList checkbox) {
		this.checkbox = checkbox;
	}

	public int getCmd() {
		return cmd;
	}

	public void setCmd(int cmd) {
		this.cmd = cmd;
	}

	//��ҳ
	private int p;
	private PageBean pb;
	
	public int getP() {
		return p;
	}

	public void setP(int p) {
		this.p = p;
	}

	public PageBean getPb() {
		return pb;
	}

	public void setPb(PageBean pb) {
		this.pb = pb;
	}

	public int getTpid() {
		return tpid;
	}

	public void setTpid(int tpid) {
		this.tpid = tpid;
	}

	public String getSubid() {
		return subid;
	}

	public void setSubid(String subid) {
		this.subid = subid;
	}

	private int subject;//��Ŀ
	

	private int stage;//�׶�
	private int direction;//����
	

	//�����ڱ��������Ŀ�Ŀ����ʾ
	private String directionName;//����id�鷽����
	private String stageName;//�׶�id��׶���
	
	
	public String getDirectionName() {
		return directionName;
	}

	public void setDirectionName(String directionName) {
		this.directionName = directionName;
	}

	public String getStageName() {
		return stageName;
	}

	public void setStageName(String stageName) {
		this.stageName = stageName;
	}



	
	
	//������Դ���ֵ
	private int a1;
	private int b1;
	private int c1;
	private int a2;
	private int b2;
	private int c2;
	


	public int getA1() {
		return a1;
	}

	public void setA1(int a1) {
		this.a1 = a1;
	}

	public int getB1() {
		return b1;
	}

	public void setB1(int b1) {
		this.b1 = b1;
	}

	public int getC1() {
		return c1;
	}

	public void setC1(int c1) {
		this.c1 = c1;
	}

	public int getA2() {
		return a2;
	}

	public void setA2(int a2) {
		this.a2 = a2;
	}

	public int getB2() {
		return b2;
	}

	public void setB2(int b2) {
		this.b2 = b2;
	}

	public int getC2() {
		return c2;
	}

	public void setC2(int c2) {
		this.c2 = c2;
	}

	public Object getArray() {
		return array;
	}

	public void setArray(Object array) {
		this.array = array;
	}

	public ArrayList<Testquestions> getTestquestionsList() {
		return testquestionsList;
	}

	public void setTestquestionsList(ArrayList<Testquestions> testquestionsList) {
		this.testquestionsList = testquestionsList;
	}
	public ArrayList<Classes> getClassesList() {
		return classesList;
	}

	public void setClassesList(ArrayList<Classes> classesList) {
		this.classesList = classesList;
	}
	public int getSubject() {
		return subject;
	}

	public void setSubject(int subject) {
		this.subject = subject;
	}

	public int getStage() {
		return stage;
	}

	public void setStage(int stage) {
		this.stage = stage;
	}

	public int getDirection() {
		return direction;
	}

	public void setDirection(int direction) {
		this.direction = direction;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getSubOpVlaue() {
		return subOpVlaue;
	}

	public void setSubOpVlaue(String subOpVlaue) {
		this.subOpVlaue = subOpVlaue;
	}

	private ArrayList<Subjects> subjects;
	private ArrayList<Testpapers> testpapersList;
	private Object array;
	
	

	

	public ArrayList<Testpapers> getTestpapersList() {
		return testpapersList;
	}

	public void setTestpapersList(ArrayList<Testpapers> testpapersList) {
		this.testpapersList = testpapersList;
	}

	public ArrayList<Subjects> getSubjects() {
		return subjects;
	}

	public void setSubjects(ArrayList<Subjects> subjects) {
		this.subjects = subjects;
	}

	public String getDirOpValue() {
		return dirOpValue;
	}

	public void setDirOpValue(String dirOpValue) {
		this.dirOpValue = dirOpValue;
	}

	public String getStaOpVlaue() {
		return staOpVlaue;
	}

	public void setStaOpVlaue(String staOpVlaue) {
		this.staOpVlaue = staOpVlaue;
	}

	public HoutaiBiz getHoutaiBiz() {
		return houtaiBiz;
	}

	public void setHoutaiBiz(HoutaiBiz houtaiBiz) {
		this.houtaiBiz = houtaiBiz;
	}

	public ArrayList<Directions> getDirList() {
		return dirList;
	}

	public void setDirList(ArrayList<Directions> dirList) {
		this.dirList = dirList;
	}

	public ArrayList<Stages> getStaList() {
		return staList;
	}

	public void setStaList(ArrayList<Stages> staList) {
		this.staList = staList;
	}
	
	
	
	//�ս���
	public String testpaperlist(){
		if(p==0){
			p=1;
		}
		directionName="JAVA";
		stageName="G1";
		dirList=houtaiBiz.selectDirections();
		staList=houtaiBiz.selectStages();
		subList = houtaiBiz.getSubjectByDidAndStaid(1, 1);
		pb=testpaper.selectTestpapers(p,1);
		 return "testpaperlist";
	}
	
	
	
	//�����¼�������
	public String shijian(){
		int did = Integer.parseInt(dirOpValue);
		int staid = Integer.parseInt(staOpVlaue);
		if(p==0){
			p=1;
		}

		directionName="JAVA";
		stageName="G1";
		
		dirList = houtaiBiz.getDirList(did);
		staList = houtaiBiz.getStageList(staid);
		System.out.println(did);
		System.out.println(staid);
		
		subList = houtaiBiz.getSubjectByDidAndStaid(did, staid);
		
		pb=testpaper.selectTestpapers(p,1);
		//ServletActionContext.getRequest().getSession().setAttribute("subList", subList);
		return "testpaperlist";
	}
	
	//��ѯ
	public String chaxun(){
//		int did = Integer.parseInt(dirOpValue);
//		int staid = Integer.parseInt(staOpVlaue);
		if(p==0){
			p=1;
		}
		//��ʾ��������Ŀ�Ŀһ��
		directionName=houtaiBiz.getDirectionById(direction).get(0).getDname();
		stageName=houtaiBiz.getStageById(stage).get(0).getStname();
		System.out.println("directionName:"+directionName);
		System.out.println("stageName:"+stageName);
		
//		for (Object c : checkbox) {
//			String tqid=(String) c;
//			System.out.println("xxxxxxxx"+tqid);
//			i=testpaper.associated(tp, tqid);
//		}
		
		dirList = houtaiBiz.getDirList(direction);
		staList = houtaiBiz.getStageList(stage);
		System.out.println(direction);
		System.out.println(stage);
		System.out.println(subject);
		
		try {
			state = java.net.URLDecoder.decode(state,"UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cmd=1;
		System.out.println("//ת���//"+state);
		System.out.println(p);
		subList = houtaiBiz.getSubjectByDidAndStaid(direction, stage);
		pb=testpaper.selectTestpapers(p,subject, state);
		return "testpaperlist";
		
	}
	
	//��ҳ������ʼ���Բ�༶
	public String beginexam(){
		//��༶
		classesList=testpaper.selectClasses();
		return "beginexam";
		
	}
	//selectsubjectgroupvolume.jsp
	
	//ѡ�����//�ս���
	public String selectsubjectgroupvolume(){
		int sub=Integer.parseInt(subid);
		subList=houtaiBiz.selectsubjects(sub);//���Ŀ����
		testquestionsList=houtaiBiz.selectquestion(sub);//������
		
		return "selectsubjectgroupvolume";
		
	}
	
	//ѡ�����/�����Ծ�
	public String createtestpaper(){
		int i=0;
		System.out.println("checkbox"+checkbox);
		int subi=Integer.parseInt(subid);
		//�����Ծ�
		testpapers= testpaper.createtestpaper(testpapers, subi);
		int tp=testpapers.getTpid();
		System.out.println("tp"+tp);
		for (Object c : checkbox) {
			String tqid=(String) c;
			System.out.println("xxxxxxxx"+tqid);
			i=testpaper.associated(tp, tqid);
		}
		if (i==1) {
			return "selectsubjectprompt";
		}
		return null;
		
	}
	
	//������//�ս���
	
	public String randomgrouppaper(){
		int sub=Integer.parseInt(subid);
		subList=houtaiBiz.selectsubjects(sub);//���Ŀ����
		
		
		
		
		return "randomgrouppaper";
	}
	
	
	//������//�ύ
	public String random(){
		int subi=Integer.parseInt(subid);
		//�����Ծ�tp-�Ծ�id
		testpapers= testpaper.createtestpaper(testpapers, subi);
		int tp=testpapers.getTpid();
		System.out.println("tp"+tp);
		String jiandan="��";
		String yiban="һ��";
		String kunnan="����";
		String danxuan="��ѡ";
		String duoxuan="��ѡ";
			testpaper.random(tp, a1,danxuan,jiandan);
			testpaper.random(tp, a2,duoxuan,jiandan);
			testpaper.random(tp, b1,danxuan,yiban);
			testpaper.random(tp, b2,duoxuan,yiban);
			testpaper.random(tp, c1,danxuan,kunnan);
			testpaper.random(tp, c2,duoxuan,kunnan);
		return null;
	}
	
	
	
	
	//��������
	public String endtest(){
		String s="���Խ���";
		System.out.println(tpid);
		testpaper.updatestate(tpid, s);
		return "endtest";
		
	}
	
	
	//��ʼ����
	public String begintest(){
		String s="������";
		System.out.println("��ʼ����tpid"+tpid);
		testpaper.begintest(tpid,s,clas);
		return null;
		
	}
	
	
	//ɾ���Ծ�
	public String deletetestpaper(){
		System.out.println(tpid);
		testpaper.deletetestpaper(tpid);
		return "deletetestpaper";
		
	}
	
	
	//�鿴�Ծ�
	public String looktestpaper(){
		System.out.println(tpid);
		testquestionsList=testpaper.looktestpaper(tpid);
		return "looktestpaper";
		
	}
	
	

	public TestpaperBiz getTestpaper() {
		return testpaper;
	}

	public void setTestpaper(TestpaperBiz testpaper) {
		this.testpaper = testpaper;
	}

	public ArrayList<Subjects> getSubList() {
		return subList;
	}

	public void setSubList(ArrayList<Subjects> subList) {
		this.subList = subList;
	}

}
