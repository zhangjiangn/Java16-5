package com.qhit.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;

import com.qhit.bean.Classes;
import com.qhit.bean.PageBean;
import com.qhit.bean.Stages;
import com.qhit.bean.Subjects;
import com.qhit.bean.Testpapers;
import com.qhit.bean.Testquestions;
import com.qhit.bean.TpTq;
import com.qhit.dao.TestpaperDao;

public class TestpaperDaoImpl implements TestpaperDao {

	@Override
	public ArrayList<Subjects> selectSubjects() {
		Query query=session.createQuery("from Subjects");
		return (ArrayList<Subjects>) query.list();
	}

	//��ѯ��ҳ
	@Override
	public PageBean selectTestpapers(int p,int subid,String state) {
		PageBean pb=new PageBean();
		try {
			String hql = "from Testpapers where subid=:subid and state=:state";
			Query query = session.createQuery(hql);
			query.setInteger("subid", subid);
			query.setString("state", state);
			int count=query.list().size();
			pb.setPagesize(4);//ÿҳ����
			pb.setCount(count);//����
			//%�ж��������Ϊ0˵���в���һҳ��ʣ�࣬Ҫ��һҳ
			if(count%pb.getPagesize()!=0){
				pb.setPagetotal(count/pb.getPagesize()+1);
			}else{
				pb.setPagetotal(count/pb.getPagesize());//ҳ��
			}
			
			pb.setP(p);
			
			System.out.println(pb.getP());
			query.setFirstResult((pb.getP()-1)*pb.getPagesize());
			query.setMaxResults(pb.getPagesize());
			List<Testquestions> list=query.list();
			pb.setData(list);
			session.beginTransaction().commit();
		}catch (Exception e) {
			session.beginTransaction().rollback();
		}
		return pb;
	}

	//�ս���ӷ�ҳ
	@Override
	public PageBean selectTestpapers(int p,int subid) {
		PageBean pb=new PageBean();
		try {
			String hql = "from Testpapers where subid=:subid";
			Query query = session.createQuery(hql);
			query.setInteger("subid", subid);
			int count=query.list().size();
			pb.setPagesize(4);//ÿҳ����
			pb.setCount(count);//����
			//%�ж��������Ϊ0˵���в���һҳ��ʣ�࣬Ҫ��һҳ
			if(count%pb.getPagesize()!=0){
				pb.setPagetotal(count/pb.getPagesize()+1);
			}else{
				pb.setPagetotal(count/pb.getPagesize());//ҳ��
			}
			
			pb.setP(p);
			
			System.out.println(pb.getP());
			query.setFirstResult((pb.getP()-1)*pb.getPagesize());
			query.setMaxResults(pb.getPagesize());
			List<Testquestions> list=query.list();
			pb.setData(list);
			session.beginTransaction().commit();
		}catch (Exception e) {
			session.beginTransaction().rollback();
		}
		return pb;
	}

	//��༶
	@Override
	public ArrayList<Classes> selectClasses() {
		ArrayList<Classes> classes = new ArrayList<Classes>();
		String hql = "from Classes";
		Query query = session.createQuery(hql);
		
		return (ArrayList<Classes>) query.list();
	}

	//�ı��Ծ�״̬
	@Override
	public ArrayList<Testpapers> updatestate(int tpid,String state) {
		try {
			
			Testpapers t=(Testpapers) session.get(Testpapers.class, tpid);
			t.setTpid(t.getTpid());
			t.setState(state);
			
			session.update(t);
			session.beginTransaction().commit();
		}catch (Exception e) {
			session.beginTransaction().rollback();
		}
		return null;
	}

	//ɾ���Ծ�
	@Override
	public ArrayList<Testpapers> deletetestpaper(int tpid) {
try {
			
			Testpapers tt=(Testpapers) session.load(Testpapers.class, tpid);
			
			session.delete(tt);
			session.beginTransaction().commit();
		}catch (Exception e) {
			session.beginTransaction().rollback();
		}
		return null;
	}

	//ͨ���Ծ�id������
	@Override
	public ArrayList<Testquestions> looktestpaper(int tpid) {
		String hql = "from Testquestions where tqid in(select t.testquestions from TpTq t where t.testpapers=:tpid)";
		Query query = session.createQuery(hql);
		query.setInteger("tpid", tpid);
		
		return (ArrayList<Testquestions>) query.list();
	}

	//add�����Ծ�
	@Override
	public Testpapers createtestpaper(Testpapers ts,int subid) {
		
		
			Subjects s=(Subjects) session.get(Subjects.class, subid);
			ts.setSubjects(s);
			session.beginTransaction();
			session.save(ts);
			session.beginTransaction().commit();
			
			String hql="from Testpapers order by tpid desc";
			Query query = session.createQuery(hql);
			session.beginTransaction().commit();
			ArrayList<Testpapers> testpapers =(ArrayList<Testpapers>) query.list();
			Testpapers tp=testpapers.get(0);
		
		return tp;
	}

	//��ϵ��
	@Override
	public int associated(int tpid, String tqid) {
		System.out.println("tpid"+tpid);
		System.out.println("tqid"+tqid);
		int i=1;
		TpTq tptq=new TpTq();
		try {
			Testpapers tp=(Testpapers) session.get(Testpapers.class, tpid);
			tptq.setTestpapers(tp);
			int tt=Integer.parseInt(tqid);
			Testquestions tq=(Testquestions) session.get(Testquestions.class, tt);
			tptq.setTestquestions(tq);
			session.beginTransaction();
			session.save(tptq);
			session.beginTransaction().commit();
		} catch (Exception e) {
			i=0;
			session.beginTransaction().rollback();
		}
		return i;
	}

	//��ʼ����
	@Override
	public ArrayList<Testpapers> begintest(int tpid, String state, String clas) {
try {
			
			Testpapers t=(Testpapers) session.get(Testpapers.class, tpid);
			String hql = " from Classes c where c.cname=:clas";
			Query query = session.createQuery(hql);
			query.setString("clas", clas);
			ArrayList<Classes> classes =(ArrayList<Classes>) query.list();
			Classes cl=classes.get(0);
			int cid=cl.getCid();
			System.out.println("cid////////"+cid);
			Classes c=(Classes) session.get(Classes.class, cid);
			t.setState(state);
			t.setClasses(c);
			session.update(t);
			session.beginTransaction().commit();
		}catch (Exception e) {
			session.beginTransaction().rollback();
		}
		return null;
	}

	//������
	@Override
	public int random(int tp, int abc, String danxuan, String jiandan) {
		System.out.println("tp"+tp);
		System.out.println("abc"+abc);
		System.out.println("danxuan"+danxuan);
		System.out.println("jiandan"+jiandan);
		int i=1;
		try {
			//String sql = "select top "+abc+" tqid from testquestions where difficulty='"+jiandan+"' and topictype='"+danxuan+"'";
			String sql = "SELECT top "+abc+" tqid FROM testquestions where difficulty='"+jiandan+"' and topictype='"+danxuan+"' ORDER BY NEWID()";
			Query query = session.createSQLQuery(sql);
			ArrayList testquestions =(ArrayList) query.list();
			System.out.println(testquestions);
			for (Object t : testquestions) {
				TpTq tptq=new TpTq();
				System.out.println(t);
				String tqid=t.toString();
				System.out.println("xxxxxxxx"+tqid);
				Testpapers tpp=(Testpapers) session.get(Testpapers.class, tp);
				tptq.setTestpapers(tpp);
				int tt=Integer.parseInt(tqid);
				Testquestions tq=(Testquestions) session.get(Testquestions.class, tt);
				tptq.setTestquestions(tq);
				session.beginTransaction();
				session.save(tptq);
				session.beginTransaction().commit();
			}
			
		} catch (Exception e) {
			i=0;
			session.beginTransaction().rollback();
		}
		return i;
	}

	
	
	

	

}
