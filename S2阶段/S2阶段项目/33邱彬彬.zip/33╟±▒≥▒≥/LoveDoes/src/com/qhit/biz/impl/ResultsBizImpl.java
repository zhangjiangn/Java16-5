package com.qhit.biz.impl;

import java.util.ArrayList;

import com.qhit.bean.Grades;
import com.qhit.bean.Students;
import com.qhit.bean.StudentsTq;
import com.qhit.bean.Subjects;
import com.qhit.bean.Testpapers;
import com.qhit.biz.ResultsBiz;
import com.qhit.dao.ResultsDao;
import com.qhit.dao.impl.ResultsDaoImpl;


public class ResultsBizImpl implements ResultsBiz {
	private ResultsDao dao=new ResultsDaoImpl();

	@Override
	public ArrayList<Grades> selectGrades(int tpid) {
		// TODO Auto-generated method stub
		return dao.selectGrades(tpid);
	}

	@Override
	public ArrayList<Students> selectStudents(int sid) {
		// TODO Auto-generated method stub
		return dao.selectStudents(sid);
	}

	@Override
	public Testpapers selectTestpapers(int tpid) {
		// TODO Auto-generated method stub
		return dao.selectTestpapers(tpid);
	}

	@Override
	public StudentsTq selectStudenrsTq(int sid, int ssid) {
		// TODO Auto-generated method stub
		return dao.selectStudenrsTq(sid, ssid);
	}

	

}
