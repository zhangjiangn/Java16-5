package com.qhit.dao;

import java.util.ArrayList;

import org.hibernate.Session;

import com.qhit.bean.Grades;
import com.qhit.bean.Students;
import com.qhit.bean.StudentsTq;
import com.qhit.bean.Subjects;
import com.qhit.bean.Testpapers;

public interface ResultsDao {
	
	public Session session=HibernateSessionFactory.getSession();
	public ArrayList<Grades> selectGrades(int tpid);//ͨ���Ծ�id�鿼����Ϣ
	public ArrayList<Students> selectStudents(int sid);//ͨ��ѧ��id��ѧ��
	public Testpapers selectTestpapers(int tpid);//ͨ���Ծ�id���Ծ���Ϣ
	public StudentsTq selectStudenrsTq(int sid, int ssid);

}
