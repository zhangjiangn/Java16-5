package com.qhit.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Stages entity. @author MyEclipse Persistence Tools
 */

public class Stages implements java.io.Serializable {

	// Fields

	private Integer stid;
	private String stname;
	private Set subjectses = new HashSet(0);

	// Constructors

	/** default constructor */
	public Stages() {
	}

	/** minimal constructor */
	public Stages(Integer stid, String stname) {
		this.stid = stid;
		this.stname = stname;
	}

	/** full constructor */
	public Stages(Integer stid, String stname, Set subjectses) {
		this.stid = stid;
		this.stname = stname;
		this.subjectses = subjectses;
	}

	// Property accessors

	public Integer getStid() {
		return this.stid;
	}

	public void setStid(Integer stid) {
		this.stid = stid;
	}

	public String getStname() {
		return this.stname;
	}

	public void setStname(String stname) {
		this.stname = stname;
	}

	public Set getSubjectses() {
		return this.subjectses;
	}

	public void setSubjectses(Set subjectses) {
		this.subjectses = subjectses;
	}

}