package com.qhit.action;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import com.qhit.bean.Classes;
import com.qhit.bean.Directions;
import com.qhit.bean.Grades;
import com.qhit.bean.PageBean;
import com.qhit.bean.Stages;
import com.qhit.bean.Students;
import com.qhit.bean.StudentsTq;
import com.qhit.bean.Subjects;
import com.qhit.bean.Testpapers;
import com.qhit.bean.Testquestions;
import com.qhit.biz.HoutaiBiz;
import com.qhit.biz.OnlinetestBiz;
import com.qhit.biz.ResultsBiz;
import com.qhit.biz.TestpaperBiz;
import com.qhit.biz.impl.HoutaiBizImpl;
import com.qhit.biz.impl.OnlinetestBizImpl;
import com.qhit.biz.impl.ResultsBizImpl;
import com.qhit.biz.impl.TestpaperBizImpl;

public class ResultsAction {
	//����Ա��¼-�ɼ�����
	private HoutaiBiz houtaiBiz = new HoutaiBizImpl();
	private TestpaperBiz testpaper = new TestpaperBizImpl();
	private ResultsBiz ResuitsBiz = new ResultsBizImpl();
	private OnlinetestBiz onlinetest=new OnlinetestBizImpl();
	private ArrayList<Directions> dirList;
	private ArrayList<Stages> staList;
	private ArrayList<Subjects> subList;// ��Ŀ��
	// ��ҳ
	private int p;
	private PageBean pb;

	private int subject;// ��Ŀ
	private int stage;// �׶�
	private int direction;// ����
	private String dirOpValue;
	private String staOpVlaue;

	private String subOpVlaue;
	private String state;

	private ArrayList<Testquestions> testquestionsList;// ��༶
	private int tpid;
	
	
	//�����ڱ��������Ŀ�Ŀ����ʾ
	private String directionName;//����id�鷽����
	private String stageName;//�׶�id��׶���
	
	
	//�鿴�ɼ�
	
	private String headings;//�Ծ�����
	private ArrayList<Classes> classesList;//��༶
	private ArrayList<Grades> gradesList;
	private ArrayList StudentsTqanswerList = new ArrayList();
	private int sid;// ѧ��id
	private Testpapers testpapers;
	private ArrayList<StudentsTq> studentsTq=new ArrayList<StudentsTq>();

	

	

	public Testpapers getTestpapers() {
		return testpapers;
	}

	public ArrayList<StudentsTq> getStudentsTq() {
		return studentsTq;
	}

	public void setStudentsTq(ArrayList<StudentsTq> studentsTq) {
		this.studentsTq = studentsTq;
	}

	public void setTestpapers(Testpapers testpapers) {
		this.testpapers = testpapers;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public OnlinetestBiz getOnlinetest() {
		return onlinetest;
	}

	public void setOnlinetest(OnlinetestBiz onlinetest) {
		this.onlinetest = onlinetest;
	}

	

	public ArrayList getStudentsTqanswerList() {
		return StudentsTqanswerList;
	}

	public void setStudentsTqanswerList(ArrayList studentsTqanswerList) {
		StudentsTqanswerList = studentsTqanswerList;
	}

	public ArrayList<Grades> getGradesList() {
		return gradesList;
	}

	public void setGradesList(ArrayList<Grades> gradesList) {
		this.gradesList = gradesList;
	}

	public ArrayList<Classes> getClassesList() {
		return classesList;
	}

	public void setClassesList(ArrayList<Classes> classesList) {
		this.classesList = classesList;
	}

	public String getHeadings() {
		return headings;
	}

	public void setHeadings(String headings) {
		this.headings = headings;
	}

	// �������ɼ�����
	public String resultslist() {
		dirList = houtaiBiz.selectDirections();
		staList = houtaiBiz.selectStages();
		if (p == 0) {
			p = 1;
		}
		directionName="JAVA";
		stageName="G1";
		
		String state = "������";
		System.out.println(p);
		subList = houtaiBiz.getSubjectByDidAndStaid(1, 1);
		subject = 1;
		pb = testpaper.selectTestpapers(p, subject, state);
		return "resultslist";
	}

	// �ɼ�����ҳ���ѯ����ҳ//��ѯ
	public String chaxun() {
		// int did = Integer.parseInt(dirOpValue);
		// int staid = Integer.parseInt(staOpVlaue);
		if (p == 0) {
			p = 1;
		}
		//��ʾ��������Ŀ�Ŀһ��
		directionName=houtaiBiz.getDirectionById(direction).get(0).getDname();
		stageName=houtaiBiz.getStageById(stage).get(0).getStname();
		
		dirList = houtaiBiz.getDirList(direction);
		staList = houtaiBiz.getStageList(stage);
		System.out.println(direction);
		System.out.println(stage);
		System.out.println(subject);
		System.out.println(p);
		try {
			state = java.net.URLDecoder.decode(state, "UTF-8");//����ת��
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("//ת���//" + state);
		subList = houtaiBiz.getSubjectByDidAndStaid(direction, stage);
		pb = testpaper.selectTestpapers(p, subject, state);
		return "resultslist";

	}

	// �����¼�������
	public String shijian() {
		int did = Integer.parseInt(dirOpValue);
		int staid = Integer.parseInt(staOpVlaue);
		if (p == 0) {
			p = 1;
		}
		// dirList = houtaiBiz.selectDirections();//����
		// staList = houtaiBiz.selectStages();//�׶�
		// System.out.println(did);
		// System.out.println(staid);
		dirList = houtaiBiz.getDirList(did);
		staList = houtaiBiz.getStageList(staid);
		System.out.println(did);
		System.out.println(staid);

		subList = houtaiBiz.getSubjectByDidAndStaid(did, staid);// ͨ������׶β��Ŀ
		System.out.println("subject" + subject);
		subject = 1;
		pb = testpaper.selectTestpapers(p, subject, state);
		// pb=testpaper.selectTestpapers(p,1);
		return "resultslist";
	}

	// �鿴�Ծ�����
	public String looktestpaper() {
		System.out.println(tpid);
		testquestionsList = testpaper.looktestpaper(tpid);
		return "looktestpaper";

	}
	
	//�鿴�ɼ�
	public String lookresults(){
		
		//��༶
		classesList=testpaper.selectClasses();
		//�������Ϣ-ͨ���Ծ�id��ѯ���Դ𰸱���Ķ�����Ϣ
		gradesList=ResuitsBiz.selectGrades(tpid);
		return "lookresults";
	}
	
	//�鿴�ɼ�//�鿴����
	public String lookdetails(){
		
		
		
		//��༶
		classesList=testpaper.selectClasses();
		//�������Ϣ-ͨ���Ծ�id��ѯ���Դ𰸱���Ķ�����Ϣ
		gradesList=ResuitsBiz.selectGrades(tpid);
		testquestionsList=testpaper.looktestpaper(tpid);
		
		
		ArrayList ssidList=onlinetest.selectTpTqid(tpid);//���Ծ���Ӧ��ļ��ϵ�id
		testpapers=ResuitsBiz.selectTestpapers(tpid);//ͨ���Ծ�id���Ծ�
		System.out.println("ssidList:"+ssidList);
		for (int i = 0; i < ssidList.size(); i++) {
			System.out.println(ssidList.get(i).toString());
			String ssidString=ssidList.get(i).toString();
			int ssid=Integer.parseInt(ssidString);
			
			//StudentsTqanswerList.add(onlinetest.selectStudenrsTqsanwer(sid, ssid).toString());
			studentsTq.add(ResuitsBiz.selectStudenrsTq(sid, ssid));
		}
		System.out.println("ѧ����StudentsTqanswerList:"+StudentsTqanswerList);
		System.out.println(studentsTq);
		
		return "lookdetails";
	}
	
	
	
	
	
	

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getDirOpValue() {
		return dirOpValue;
	}

	public void setDirOpValue(String dirOpValue) {
		this.dirOpValue = dirOpValue;
	}

	public String getStaOpVlaue() {
		return staOpVlaue;
	}

	public void setStaOpVlaue(String staOpVlaue) {
		this.staOpVlaue = staOpVlaue;
	}

	public String getSubOpVlaue() {
		return subOpVlaue;
	}

	public void setSubOpVlaue(String subOpVlaue) {
		this.subOpVlaue = subOpVlaue;
	}

	public ArrayList<Testquestions> getTestquestionsList() {
		return testquestionsList;
	}

	public void setTestquestionsList(ArrayList<Testquestions> testquestionsList) {
		this.testquestionsList = testquestionsList;
	}

	public int getTpid() {
		return tpid;
	}

	public void setTpid(int tpid) {
		this.tpid = tpid;
	}

	public int getSubject() {
		return subject;
	}

	public void setSubject(int subject) {
		this.subject = subject;
	}

	public int getStage() {
		return stage;
	}

	public void setStage(int stage) {
		this.stage = stage;
	}

	public int getDirection() {
		return direction;
	}

	public void setDirection(int direction) {
		this.direction = direction;
	}

	public HoutaiBiz getHoutaiBiz() {
		return houtaiBiz;
	}

	public void setHoutaiBiz(HoutaiBiz houtaiBiz) {
		this.houtaiBiz = houtaiBiz;
	}

	public TestpaperBiz getTestpaper() {
		return testpaper;
	}

	public void setTestpaper(TestpaperBiz testpaper) {
		this.testpaper = testpaper;
	}

	public ResultsBiz getResuitsBiz() {
		return ResuitsBiz;
	}

	public void setResuitsBiz(ResultsBiz resuitsBiz) {
		ResuitsBiz = resuitsBiz;
	}

	public ArrayList<Directions> getDirList() {
		return dirList;
	}

	public void setDirList(ArrayList<Directions> dirList) {
		this.dirList = dirList;
	}

	public ArrayList<Stages> getStaList() {
		return staList;
	}

	public void setStaList(ArrayList<Stages> staList) {
		this.staList = staList;
	}

	public ArrayList<Subjects> getSubList() {
		return subList;
	}

	public void setSubList(ArrayList<Subjects> subList) {
		this.subList = subList;
	}

	public int getP() {
		return p;
	}

	public void setP(int p) {
		this.p = p;
	}

	public PageBean getPb() {
		return pb;
	}

	public void setPb(PageBean pb) {
		this.pb = pb;
	}
	public String getDirectionName() {
		return directionName;
	}

	public void setDirectionName(String directionName) {
		this.directionName = directionName;
	}

	public String getStageName() {
		return stageName;
	}

	public void setStageName(String stageName) {
		this.stageName = stageName;
	}

}
