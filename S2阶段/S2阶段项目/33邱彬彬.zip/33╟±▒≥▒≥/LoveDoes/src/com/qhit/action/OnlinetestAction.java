package com.qhit.action;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.qhit.bean.Classes;
import com.qhit.bean.StudentsTq;
import com.qhit.bean.Testpapers;
import com.qhit.bean.Testquestions;
import com.qhit.bean.TpTq;
import com.qhit.biz.HoutaiBiz;
import com.qhit.biz.OnlinetestBiz;
import com.qhit.biz.TestpaperBiz;
import com.qhit.biz.impl.HoutaiBizImpl;
import com.qhit.biz.impl.OnlinetestBizImpl;
import com.qhit.biz.impl.TestpaperBizImpl;


public class OnlinetestAction {
//ѧ����½-���߿���
	private OnlinetestBiz onlinetest=new OnlinetestBizImpl();
	private HoutaiBiz houtaiBiz=new HoutaiBizImpl();
	private TestpaperBiz testpaper=new TestpaperBizImpl();
	
	private ArrayList<Classes> classes;
	private ArrayList<Testquestions> testquestions;
	private String cla;
	private String claid;
	private String sanswer;//ѡ�Ĵ�
	

	public String getSanswer() {
		return sanswer;
	}

	public void setSanswer(String sanswer) {
		this.sanswer = sanswer;
	}

	public ArrayList<Testquestions> getTestquestions() {
		return testquestions;
	}

	public void setTestquestions(ArrayList<Testquestions> testquestions) {
		this.testquestions = testquestions;
	}

	public int getTqid() {
		return tqid;
	}

	public void setTqid(int tqid) {
		this.tqid = tqid;
	}

	private int tpid;//�Ծ�id
	private ArrayList<TpTq> tptq;
	private int tqid;//����id
	
	

	private int sid;//����id
	private ArrayList tqidList = new ArrayList();
	private ArrayList answerList = new ArrayList();
	private ArrayList<StudentsTq> studentstqList;
	private ArrayList StudentsTqanswerList = new ArrayList();
	private String starttime;//����ʱ��
	
	public String getStarttime() {
		return starttime;
	}

	public void setStarttime(String starttime) {
		this.starttime = starttime;
	}
	
	private double eachscore;
	
	
	public double getEachscore() {
		return eachscore;
	}

	public void setEachscore(double eachscore) {
		this.eachscore = eachscore;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public ArrayList getStudentsTqanswerList() {
		return StudentsTqanswerList;
	}

	public void setStudentsTqanswerList(ArrayList studentsTqanswerList) {
		StudentsTqanswerList = studentsTqanswerList;
	}

	public ArrayList<StudentsTq> getStudentstqList() {
		return studentstqList;
	}

	public void setStudentstqList(ArrayList<StudentsTq> studentstqList) {
		this.studentstqList = studentstqList;
	}

	


	
	public ArrayList getAnswerList() {
		return answerList;
	}

	public void setAnswerList(ArrayList answerList) {
		this.answerList = answerList;
	}

	public ArrayList getTqidList() {
		return tqidList;
	}

	public void setTqidList(ArrayList tqidList) {
		this.tqidList = tqidList;
	}

	
	
	
	
	public ArrayList<TpTq> getTptq() {
		return tptq;
	}

	public void setTptq(ArrayList<TpTq> tptq) {
		this.tptq = tptq;
	}

	private Testpapers testpapers;
	
	
	public HoutaiBiz getHoutaiBiz() {
		return houtaiBiz;
	}

	public void setHoutaiBiz(HoutaiBiz houtaiBiz) {
		this.houtaiBiz = houtaiBiz;
	}

	public TestpaperBiz getTestpaper() {
		return testpaper;
	}

	public void setTestpaper(TestpaperBiz testpaper) {
		this.testpaper = testpaper;
	}

	public Testpapers getTestpapers() {
		return testpapers;
	}

	public void setTestpapers(Testpapers testpapers) {
		this.testpapers = testpapers;
	}

	

	public int getTpid() {
		return tpid;
	}

	public void setTpid(int tpid) {
		this.tpid = tpid;
	}

	public String getClaid() {
		return claid;
	}

	public void setClaid(String claid) {
		this.claid = claid;
	}

	private ArrayList<Testpapers> testpapersList;
	
	public ArrayList<Classes> getClasses() {
		return classes;
	}

	public ArrayList<Testpapers> getTestpapersList() {
		return testpapersList;
	}

	public void setTestpapersList(ArrayList<Testpapers> testpapersList) {
		this.testpapersList = testpapersList;
	}

	public void setClasses(ArrayList<Classes> classes) {
		this.classes = classes;
	}

	public String getCla() {
		return cla;
	}

	public void setCla(String cla) {
		this.cla = cla;
	}

	public OnlinetestBiz getOnlinetest() {
		return onlinetest;
	}

	public void setOnlinetest(OnlinetestBiz onlinetest) {
		this.onlinetest = onlinetest;
	}

	

	//������Ϣ
	public String personalinformation(){
		HttpSession session=ServletActionContext.getRequest().getSession();
		String name=(String) session.getAttribute("name");
		String pwd=(String) session.getAttribute("pwd");
		
		classes=onlinetest.selectClasses(name, pwd);
		Object o=classes.get(0);
		cla=(String) o;
		System.out.println(classes);
		
		return "personalinformation";
	}
	
	//�������߿���
	public  String onlinetest(){
		HttpSession session=ServletActionContext.getRequest().getSession();
		String name=(String) session.getAttribute("name");
		String pwd=(String) session.getAttribute("pwd");
		classes=onlinetest.selectClassesid(name, pwd);
		System.out.println(classes);
		Object o=classes.get(0);
		System.out.println(o);
		claid=o.toString();
		//��ʾ
		String state="������";
		testpapersList=onlinetest.selectTestpapers(claid, state);
		System.out.println(testpapersList);
		
		return "onlinetest";
	}
	
	//��ʼ����-ulli
	public  String begintest(){
		testpapers=onlinetest.selectTestpapers(tpid);//ͷ��
		tptq=onlinetest.selectTpTq(tpid);//�����������
		p=0;
		testquestions=houtaiBiz.selectquestionone(tqid);//�ײ�
		
		//�����ݿ������ӳ�ʼ��null
		ArrayList ssidList=onlinetest.selectTpTqid(tpid);//���Ծ���Ӧ��ļ��ϵ�id

		HttpSession session=ServletActionContext.getRequest().getSession();
		String name=(String) session.getAttribute("name");
		String pwd=(String) session.getAttribute("pwd");
		sid=onlinetest.selectStudentsid(name,pwd);
		
		ArrayList ssidList1=onlinetest.selectTpTqid(tpid);//���Ծ���Ӧ��ļ��ϵ�id
		System.out.println("ssidList:"+ssidList1);
			
			int ssid=Integer.parseInt(ssidList1.get(0).toString());
			System.out.println(ssid);
			
			studentstqList =onlinetest.selectsssidyesno(sid,ssid);//��ѯ�Ƿ�������
			int size=studentstqList.size();
		
		if(size==0){//�ж����ݿ����Ƿ����ӹ�
			for (int i = 0; i < tptq.size(); i++) {
				String ssidString=ssidList1.get(i).toString();
				int ssid1=Integer.parseInt(ssidString);
				System.out.println(ssid1);
				sanswer="null";
				onlinetest.addStudentsTq(sid, ssid1, sanswer);//�����ݿ������ӳ�ʼ��null
			}
		}
			
			
		
		
		
		return "begintest";
	}
	private int p;
	public int getP() {
		return p;
	}

	public void setP(int p) {
		this.p = p;
	}

	//��ʼ����-��һ����һ��
	public  String begintest2(){
		testpapers=onlinetest.selectTestpapers(tpid);//ͷ��
		tptq=onlinetest.selectTpTq(tpid);//�����������
		System.out.println(tptq);
		System.out.println(tptq.size());
		
		for (int i = 0; i < tptq.size(); i++) {
			System.out.println("tptq:"+tptq.get(i).getTestquestions().getTqid().toString());
			tqidList.add(tptq.get(i).getTestquestions().getTqid().toString());
		}
			System.out.println(tqidList);
		
		if(p<0){
			p=0;
			int tqqid=Integer.parseInt(tptq.get(p).getTestquestions().getTqid().toString());
			testquestions=houtaiBiz.selectquestionone(tqqid);//�ײ�
		}else if(p>=tptq.size()){
			p=tptq.size()-1;
			int tqqid=Integer.parseInt(tptq.get(p).getTestquestions().getTqid().toString());
			testquestions=houtaiBiz.selectquestionone(tqqid);//�ײ�
		}else{
			int tqqid=Integer.parseInt(tptq.get(p).getTestquestions().getTqid().toString());
			testquestions=houtaiBiz.selectquestionone(tqqid);//�ײ�
		}
		System.out.println("p:"+p);
		
		//�����ݿ�����ѡ�еĴ�
		System.out.println(tpid);
		System.out.println(tqid);
		int ssid=onlinetest.selectTpTqid(tpid, tqid);
		System.out.println("ssid:"+ssid);
		System.out.println("sanswer:"+sanswer);
		HttpSession session=ServletActionContext.getRequest().getSession();
		String name=(String) session.getAttribute("name");
		String pwd=(String) session.getAttribute("pwd");
		sid=onlinetest.selectStudentsid(name,pwd);
		if(sanswer.equals("undefined")){
		}else{
			//ѡ����ǲŻ�ִ��
			System.out.println("ssid-----"+ssid);
			int sssid=onlinetest.selectStudentsTqsssid(sid,ssid);//��ѯsssid
			System.out.println("sssid:"+sssid);
			//�Ѵ��������ݿ��޸ĵ�ԭʼ��
			onlinetest.updatesanswer(sssid,sanswer);//ͨ��sssid�����޸Ĵ�
		}
		
		
		
		return "begintest";
	}
	
	//����ɼ�
	public String countscore(){
		tptq =onlinetest.selectTpTq(tpid);//�����������//���
		for (int i = 0; i < tptq.size(); i++) {
			System.out.println("tptq:"+tptq.get(i).getTestquestions().getAnswer().toString());
			answerList.add(tptq.get(i).getTestquestions().getAnswer().toString());
		}
		System.out.println("����answerList:"+answerList);
		HttpSession session=ServletActionContext.getRequest().getSession();
		String name=(String) session.getAttribute("name");
		String pwd=(String) session.getAttribute("pwd");
		sid=onlinetest.selectStudentsid(name,pwd);
		ArrayList ssidList=onlinetest.selectTpTqid(tpid);//���Ծ���Ӧ��ļ��ϵ�id
		System.out.println("ssidList:"+ssidList);
		for (int i = 0; i < ssidList.size(); i++) {
			System.out.println(ssidList.get(i).toString());
			String ssidString=ssidList.get(i).toString();
			int ssid=Integer.parseInt(ssidString);
			
			StudentsTqanswerList.add(onlinetest.selectStudenrsTqsanwer(sid, ssid).toString());
			
		}
		System.out.println("����answerList:"+answerList);
		System.out.println("ѧ����StudentsTqanswerList:"+StudentsTqanswerList);
		
		int x=0;
		double score=0;
		for (int i = 0; i < answerList.size(); i++) {
			System.out.println("����answerList:"+answerList.get(i).toString());
			System.out.println("ѧ����StudentsTqanswerList:"+StudentsTqanswerList.get(i).toString());
			String ad=answerList.get(i).toString();
			String sd=StudentsTqanswerList.get(i).toString();
			if(ad.equals(sd)){
				score=score+eachscore;
				x++;
			}
			
		}System.out.println(score);
		int grade=(int) score;
		String stringgrade=String.valueOf(grade);//string���͵÷�
		System.out.println("�÷�"+grade);
		System.out.println(stringgrade);
		
		//��ȡ��ǰʱ��
		Date day=new Date();    

		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 

		System.out.println(df.format(day));  //��ȡ��ǰʱ�� 
		String endtime=df.format(day);
		
		//�÷����������ݿ�
		onlinetest.addGrades(sid,tpid,starttime,endtime,stringgrade);
		
		
		
		//��ʾ
		ServletActionContext.getRequest().getSession().setAttribute("prompt", "��������"+x+"���⣬�÷֣�"+grade);
		
		return "prompt";
		
	}
	
	
	
}
