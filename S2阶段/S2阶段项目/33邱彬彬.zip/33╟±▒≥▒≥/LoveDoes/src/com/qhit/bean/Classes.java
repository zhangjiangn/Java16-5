package com.qhit.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Classes entity. @author MyEclipse Persistence Tools
 */

public class Classes implements java.io.Serializable {

	// Fields

	private Integer cid;
	private Directions directions;
	private String code;
	private String cname;
	private String headteacher;
	private String lecturer;
	private String begintime;
	private String state;
	private String cremark;
	private Set studentses = new HashSet(0);
	private Set testpaperses = new HashSet(0);

	// Constructors

	/** default constructor */
	public Classes() {
	}

	/** minimal constructor */
	public Classes(Integer cid, Directions directions, String code,
			String cname, String headteacher, String lecturer,
			String begintime, String state) {
		this.cid = cid;
		this.directions = directions;
		this.code = code;
		this.cname = cname;
		this.headteacher = headteacher;
		this.lecturer = lecturer;
		this.begintime = begintime;
		this.state = state;
	}

	/** full constructor */
	public Classes(Integer cid, Directions directions, String code,
			String cname, String headteacher, String lecturer,
			String begintime, String state, String cremark, Set studentses,
			Set testpaperses) {
		this.cid = cid;
		this.directions = directions;
		this.code = code;
		this.cname = cname;
		this.headteacher = headteacher;
		this.lecturer = lecturer;
		this.begintime = begintime;
		this.state = state;
		this.cremark = cremark;
		this.studentses = studentses;
		this.testpaperses = testpaperses;
	}

	// Property accessors

	public Integer getCid() {
		return this.cid;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}

	public Directions getDirections() {
		return this.directions;
	}

	public void setDirections(Directions directions) {
		this.directions = directions;
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getCname() {
		return this.cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getHeadteacher() {
		return this.headteacher;
	}

	public void setHeadteacher(String headteacher) {
		this.headteacher = headteacher;
	}

	public String getLecturer() {
		return this.lecturer;
	}

	public void setLecturer(String lecturer) {
		this.lecturer = lecturer;
	}

	public String getBegintime() {
		return this.begintime;
	}

	public void setBegintime(String begintime) {
		this.begintime = begintime;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCremark() {
		return this.cremark;
	}

	public void setCremark(String cremark) {
		this.cremark = cremark;
	}

	public Set getStudentses() {
		return this.studentses;
	}

	public void setStudentses(Set studentses) {
		this.studentses = studentses;
	}

	public Set getTestpaperses() {
		return this.testpaperses;
	}

	public void setTestpaperses(Set testpaperses) {
		this.testpaperses = testpaperses;
	}

}