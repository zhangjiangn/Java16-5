package com.qhit.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Subjects entity. @author MyEclipse Persistence Tools
 */

public class Subjects implements java.io.Serializable {

	// Fields

	private Integer subid;
	private Stages stages;
	private Directions directions;
	private String subname;
	private Set testquestionses = new HashSet(0);
	private Set testpaperses = new HashSet(0);
	private int count;


	// Constructors

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	/** default constructor */
	public Subjects() {
	}

	/** minimal constructor */
	public Subjects(Integer subid, Stages stages, Directions directions,
			String subname) {
		this.subid = subid;
		this.stages = stages;
		this.directions = directions;
		this.subname = subname;
	}

	/** full constructor */
	public Subjects(Integer subid, Stages stages, Directions directions,
			String subname, Set testquestionses, Set testpaperses) {
		this.subid = subid;
		this.stages = stages;
		this.directions = directions;
		this.subname = subname;
		this.testquestionses = testquestionses;
		this.testpaperses = testpaperses;
	}

	// Property accessors

	public Integer getSubid() {
		return this.subid;
	}

	public void setSubid(Integer subid) {
		this.subid = subid;
	}

	public Stages getStages() {
		return this.stages;
	}

	public void setStages(Stages stages) {
		this.stages = stages;
	}

	public Directions getDirections() {
		return this.directions;
	}

	public void setDirections(Directions directions) {
		this.directions = directions;
	}

	public String getSubname() {
		return this.subname;
	}

	public void setSubname(String subname) {
		this.subname = subname;
	}

	public Set getTestquestionses() {
		return this.testquestionses;
	}

	public void setTestquestionses(Set testquestionses) {
		this.testquestionses = testquestionses;
	}

	public Set getTestpaperses() {
		return this.testpaperses;
	}

	public void setTestpaperses(Set testpaperses) {
		this.testpaperses = testpaperses;
	}

}