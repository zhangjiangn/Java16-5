package com.qhit.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Students entity. @author MyEclipse Persistence Tools
 */

public class Students implements java.io.Serializable {

	// Fields

	private Integer sid;
	private Classes classes;
	private String studentid;
	private String sname;
	private String spwd;
	private String ssex;
	private String schoolyear;
	private String stel;
	private Set studentsTqs = new HashSet(0);

	// Constructors

	/** default constructor */
	public Students() {
	}

	/** minimal constructor */
	public Students(Integer sid, Classes classes, String studentid,
			String sname, String spwd, String ssex, String schoolyear,
			String stel) {
		this.sid = sid;
		this.classes = classes;
		this.studentid = studentid;
		this.sname = sname;
		this.spwd = spwd;
		this.ssex = ssex;
		this.schoolyear = schoolyear;
		this.stel = stel;
	}

	/** full constructor */
	public Students(Integer sid, Classes classes, String studentid,
			String sname, String spwd, String ssex, String schoolyear,
			String stel, Set studentsTqs) {
		this.sid = sid;
		this.classes = classes;
		this.studentid = studentid;
		this.sname = sname;
		this.spwd = spwd;
		this.ssex = ssex;
		this.schoolyear = schoolyear;
		this.stel = stel;
		this.studentsTqs = studentsTqs;
	}

	// Property accessors

	public Integer getSid() {
		return this.sid;
	}

	public void setSid(Integer sid) {
		this.sid = sid;
	}

	public Classes getClasses() {
		return this.classes;
	}

	public void setClasses(Classes classes) {
		this.classes = classes;
	}

	public String getStudentid() {
		return this.studentid;
	}

	public void setStudentid(String studentid) {
		this.studentid = studentid;
	}

	public String getSname() {
		return this.sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getSpwd() {
		return this.spwd;
	}

	public void setSpwd(String spwd) {
		this.spwd = spwd;
	}

	public String getSsex() {
		return this.ssex;
	}

	public void setSsex(String ssex) {
		this.ssex = ssex;
	}

	public String getSchoolyear() {
		return this.schoolyear;
	}

	public void setSchoolyear(String schoolyear) {
		this.schoolyear = schoolyear;
	}

	public String getStel() {
		return this.stel;
	}

	public void setStel(String stel) {
		this.stel = stel;
	}

	public Set getStudentsTqs() {
		return this.studentsTqs;
	}

	public void setStudentsTqs(Set studentsTqs) {
		this.studentsTqs = studentsTqs;
	}

}