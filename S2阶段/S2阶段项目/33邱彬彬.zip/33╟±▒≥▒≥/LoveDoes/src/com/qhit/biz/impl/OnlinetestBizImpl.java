package com.qhit.biz.impl;

import java.util.ArrayList;

import com.qhit.bean.Classes;
import com.qhit.bean.StudentsTq;
import com.qhit.bean.Testpapers;
import com.qhit.bean.TpTq;
import com.qhit.biz.OnlinetestBiz;
import com.qhit.dao.OnlinetestDao;
import com.qhit.dao.impl.OnlinetestDaoImpl;

public class OnlinetestBizImpl implements OnlinetestBiz {
	OnlinetestDao dao=new OnlinetestDaoImpl();

	@Override
	public ArrayList<Classes> selectClasses(String name, String pwd) {
		// TODO Auto-generated method stub
		return dao.selectClasses(name, pwd);
	}

	@Override
	public ArrayList<Testpapers> selectTestpapers(String cname, String state) {
		// TODO Auto-generated method stub
		return dao.selectTestpapers(cname, state);
	}

	@Override
	public ArrayList<Classes> selectClassesid(String name, String pwd) {
		// TODO Auto-generated method stub
		return dao.selectClassesid(name, pwd);
	}

	@Override
	public Testpapers selectTestpapers(int tpid) {
		// TODO Auto-generated method stub
		return dao.selectTestpapers(tpid);
	}

	@Override
	public ArrayList<TpTq> selectTpTq(int tpid) {
		// TODO Auto-generated method stub
		return dao.selectTpTq(tpid);
	}

	@Override
	public int selectTpTqid(int tpid, int tqid) {
		// TODO Auto-generated method stub
		return dao.selectTpTqid(tpid, tqid);
	}

	@Override
	public int addStudentsTq(int sid, int ssid, String sanswer) {
		// TODO Auto-generated method stub
		return dao.addStudentsTq(sid, ssid, sanswer);
	}

	@Override
	public int selectStudentsid(String name, String pwd) {
		// TODO Auto-generated method stub
		return dao.selectStudentsid(name, pwd);
	}

	@Override
	public ArrayList<TpTq> selectTpTqid(int tpid) {
		// TODO Auto-generated method stub
		return dao.selectTpTqid(tpid);
	}

	@Override
	public String selectStudenrsTqsanwer(int sid, int ssid) {
		// TODO Auto-generated method stub
		return dao.selectStudenrsTqsanwer(sid, ssid);
	}

	@Override
	public int selectStudentsTqsssid(int sid, int ssid) {
		// TODO Auto-generated method stub
		return dao.selectStudentsTqsssid(sid, ssid);
	}

	@Override
	public int updatesanswer(int sssid, String sanswer) {
		// TODO Auto-generated method stub
		return dao.updatesanswer(sssid, sanswer);
	}

	@Override
	public ArrayList<StudentsTq> selectsssidyesno(int sid, int ssid) {
		// TODO Auto-generated method stub
		return dao.selectsssidyesno(sid, ssid);
	}

	@Override
	public int addGrades(int sid, int tpid, String starttime, String endtime,
			String grade) {
		// TODO Auto-generated method stub
		return dao.addGrades(sid, tpid, starttime, endtime, grade);
	}
		
	

	

}
