package com.qhit.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Testpapers entity. @author MyEclipse Persistence Tools
 */

public class Testpapers implements java.io.Serializable {

	// Fields

	private Integer tpid;
	private Classes classes;
	private Subjects subjects;
	private String topicbigtype;
	private String headings;
	private String totalscore;
	private String texttime;
	private String totalquestions;
	private String eachscore;
	private String state;
	private String starttime;
	private Set studentsTqs = new HashSet(0);
	private Set tpTqs = new HashSet(0);

	// Constructors

	/** default constructor */
	public Testpapers() {
	}

	/** minimal constructor */
	public Testpapers(Integer tpid, Subjects subjects, String topicbigtype,
			String headings, String totalscore, String texttime,
			String totalquestions, String eachscore, String state) {
		this.tpid = tpid;
		this.subjects = subjects;
		this.topicbigtype = topicbigtype;
		this.headings = headings;
		this.totalscore = totalscore;
		this.texttime = texttime;
		this.totalquestions = totalquestions;
		this.eachscore = eachscore;
		this.state = state;
	}

	/** full constructor */
	public Testpapers(Integer tpid, Classes classes, Subjects subjects,
			String topicbigtype, String headings, String totalscore,
			String texttime, String totalquestions, String eachscore,
			String state, String starttime, Set studentsTqs, Set tpTqs) {
		this.tpid = tpid;
		this.classes = classes;
		this.subjects = subjects;
		this.topicbigtype = topicbigtype;
		this.headings = headings;
		this.totalscore = totalscore;
		this.texttime = texttime;
		this.totalquestions = totalquestions;
		this.eachscore = eachscore;
		this.state = state;
		this.starttime = starttime;
		this.studentsTqs = studentsTqs;
		this.tpTqs = tpTqs;
	}

	// Property accessors

	public Integer getTpid() {
		return this.tpid;
	}

	public void setTpid(Integer tpid) {
		this.tpid = tpid;
	}

	public Classes getClasses() {
		return this.classes;
	}

	public void setClasses(Classes classes) {
		this.classes = classes;
	}

	public Subjects getSubjects() {
		return this.subjects;
	}

	public void setSubjects(Subjects subjects) {
		this.subjects = subjects;
	}

	public String getTopicbigtype() {
		return this.topicbigtype;
	}

	public void setTopicbigtype(String topicbigtype) {
		this.topicbigtype = topicbigtype;
	}

	public String getHeadings() {
		return this.headings;
	}

	public void setHeadings(String headings) {
		this.headings = headings;
	}

	public String getTotalscore() {
		return this.totalscore;
	}

	public void setTotalscore(String totalscore) {
		this.totalscore = totalscore;
	}

	public String getTexttime() {
		return this.texttime;
	}

	public void setTexttime(String texttime) {
		this.texttime = texttime;
	}

	public String getTotalquestions() {
		return this.totalquestions;
	}

	public void setTotalquestions(String totalquestions) {
		this.totalquestions = totalquestions;
	}

	public String getEachscore() {
		return this.eachscore;
	}

	public void setEachscore(String eachscore) {
		this.eachscore = eachscore;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getStarttime() {
		return this.starttime;
	}

	public void setStarttime(String starttime) {
		this.starttime = starttime;
	}

	public Set getStudentsTqs() {
		return this.studentsTqs;
	}

	public void setStudentsTqs(Set studentsTqs) {
		this.studentsTqs = studentsTqs;
	}

	public Set getTpTqs() {
		return this.tpTqs;
	}

	public void setTpTqs(Set tpTqs) {
		this.tpTqs = tpTqs;
	}

}