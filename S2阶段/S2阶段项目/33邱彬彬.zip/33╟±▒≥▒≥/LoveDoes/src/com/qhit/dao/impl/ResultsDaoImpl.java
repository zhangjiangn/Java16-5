package com.qhit.dao.impl;

import java.util.ArrayList;

import org.hibernate.Query;

import com.qhit.bean.Grades;
import com.qhit.bean.Students;
import com.qhit.bean.StudentsTq;
import com.qhit.bean.Testpapers;
import com.qhit.dao.ResultsDao;

public class ResultsDaoImpl implements ResultsDao {
	//�ɼ�����
	@Override
	public ArrayList<Grades> selectGrades(int tpid) {
		String hql="from Grades where tpid=:tpid";
		Query query = session.createQuery(hql);
		query.setInteger("tpid", tpid);
		return (ArrayList<Grades>) query.list();
	}

	@Override
	public ArrayList<Students> selectStudents(int sid) {
		String hql="from Students where sid=:sid";
		Query query = session.createQuery(hql);
		query.setInteger("sid", sid);
		return (ArrayList<Students>) query.list();
	}

	@Override
	public Testpapers selectTestpapers(int tpid) {
		String hql="from Testpapers where tpid=:tpid";
		Query query = session.createQuery(hql);
		query.setInteger("tpid", tpid);
		return (Testpapers) query.uniqueResult();
	}
	
	@Override
	public StudentsTq selectStudenrsTq(int sid, int ssid) {
		String hql = "from StudentsTq where sid=:sid and ssid=:ssid";
		Query query = session.createQuery(hql);
		query.setInteger("sid", sid);
		query.setInteger("ssid", ssid);
		ArrayList<StudentsTq> list=(ArrayList<StudentsTq>) query.list();
		
		return list.get(0);
	}

	
	
}
