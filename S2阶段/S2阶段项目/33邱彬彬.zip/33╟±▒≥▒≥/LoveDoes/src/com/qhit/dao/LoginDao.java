package com.qhit.dao;

import org.hibernate.Session;

import com.qhit.bean.Students;
import com.qhit.bean.Users;

public interface LoginDao {
	
	
	public Session session=HibernateSessionFactory.getSession();
	public Students loginStudent(String name,String pwd);
	public Users loginUsers(String name,String pwd);

}
