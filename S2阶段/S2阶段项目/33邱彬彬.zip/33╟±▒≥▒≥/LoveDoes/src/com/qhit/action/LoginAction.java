package com.qhit.action;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.qhit.bean.Students;
import com.qhit.bean.Users;
import com.qhit.biz.LoginBiz;
import com.qhit.biz.impl.LoginBizImpl;

public class LoginAction {
	//��½
	private String name;
	private String pwd;
	private int role;
	private Users users;
	private Students stu;
	private LoginBiz loginbiz=new LoginBizImpl();
	
	
	public String Login(){
		
		
		System.out.println(name);
		System.out.println(pwd);
		System.out.println(role);
		
		
		
		HttpSession session=ServletActionContext.getRequest().getSession();
		session.setAttribute("role", role);
		if(role==1){
			stu= loginbiz.loginStudent(name, pwd);
				if(stu!=null){
					session.setAttribute("stu", stu);
					session.setAttribute("name", name);
					session.setAttribute("pwd", pwd);
					return "index";
				}else{
				    return "login";
				}
		}else{
			users=loginbiz.loginUsers(name, pwd);
				if(users!=null){
					session.setAttribute("users", users);
					return "index";
				}else{
				    return "login";
				}
		}
		
		
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getPwd() {
		return pwd;
	}


	public void setPwd(String pwd) {
		this.pwd = pwd;
	}


	public int getRole() {
		return role;
	}


	public void setRole(int role) {
		this.role = role;
	}


	public Users getUsers() {
		return users;
	}


	public void setUsers(Users users) {
		this.users = users;
	}


	public Students getStu() {
		return stu;
	}


	public void setStu(Students stu) {
		this.stu = stu;
	}


	public LoginBiz getLoginbiz() {
		return loginbiz;
	}


	public void setLoginbiz(LoginBiz loginbiz) {
		this.loginbiz = loginbiz;
	}
	
	
	
	
	
	

}
