package com.test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tools.PageBean;

import com.bean.Shijuan;
import com.bean.Shiti;
import com.bean.StrutsShiti;
import com.biz.Chengjibiz;
import com.biz.Kaoshibiz;
import com.biz.impl.Chengjibizimpl;
import com.biz.impl.Kaoshibizimpl;
import com.dao.HibernateSessionFactory;
import com.util.PageBeans;




public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Session session=HibernateSessionFactory.getSession();
		Criteria criteria=session.createCriteria(StrutsShiti.class)
		.add(Restrictions.eq("jid", 12)).add(Restrictions.eq("sid", 1))
		.add(Restrictions.ne("daan", "NULL"));
		List<StrutsShiti> list=criteria.list();
		for (StrutsShiti strutsShiti : list) {
			System.out.println(strutsShiti.getDaan());
		}
	}
}
	

