package com.util;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import com.bean.Kemu;
import com.bean.Shiti;
import com.biz.Tikubiz;
import com.biz.impl.Tikubizimpl;




import jxl.Sheet;
import jxl.Workbook;

public class ExcelDao {

     	/**
         * ��ѯָ��Ŀ¼�е��ӱ��������е�����
         * @param file �ļ�����·��
         * @return
         */
        public static List<Object[]> getAllByExcel(String file){
        	Tikubiz biz=new Tikubizimpl();
        	Tikubiz biz1=new Tikubizimpl();
            List<Object[]> list=new ArrayList<Object[]>();
            try {
                Workbook rwb=Workbook.getWorkbook(new File(file));
                Sheet rs=rwb.getSheet(0);//����rwb.getSheet(0)
                int clos=rs.getColumns();//�õ����е���
                int rows=rs.getRows();//�õ����е���
                
                System.out.println("clos"+clos+" rows:"+rows);
                for (int i = 1; i < rows; i++) {
                    for (int j = 0; j < clos; j++) {
                        //��һ�����������ڶ���������
                        String a1=rs.getCell(j++, i).getContents();//Ĭ������߱��Ҳ��һ�� ���������j++  content
                        String a2=rs.getCell(j++, i).getContents();//A
                        String a3=rs.getCell(j++, i).getContents();//B
                        String a4=rs.getCell(j++, i).getContents();//C
                        String a5=rs.getCell(j++, i).getContents();//D
                        String a6=rs.getCell(j++, i).getContents();//answer
                        String a7=rs.getCell(j++, i).getContents();//sub
                        String a8=rs.getCell(j++, i).getContents();//level
                        String a9=rs.getCell(j++, i).getContents();//type
                        String a10=rs.getCell(j++, i).getContents();
                      
                        Shiti a=new Shiti();
                        a.setZhuti(a1);
                        a.setOptionA(a2);
                        a.setOptionB(a3);
                        a.setOptionC(a4);
                        a.setOptionD(a5);
                        a.setDaan(a6);
                       List<Kemu> list2=biz1.selects(a7);
                       for (Kemu kemu : list2) {
						a.setKid(kemu.getKid());
					}
                       a.setNanyidu(a8);
                       a.setTixiaolie(a9);
                       a.setZhangjie(a10);
                        biz.insert(a);
                    }
                }
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } 
            return list;
            
        }
    }
