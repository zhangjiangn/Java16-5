package com.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import tools.PageBean;

import com.bean.Fangxiang;
import com.bean.Kemu;
import com.bean.Shiti;
import com.biz.Tikubiz;
import com.biz.impl.Tikubizimpl;

public class Tikuaction {
	private List<Shiti> list;
	private Shiti shiti;
	private Shiti shiti1;
	private Tikubiz biz=new Tikubizimpl();
	private List<Fangxiang> list1;
	private List<Kemu> list2;
	private Kemu kemu;
	private PageBean pb;
	public int kid;
	public String fangke() {
		list1=biz.selectfang();
		list2=biz.selectku();
		HttpServletRequest request=ServletActionContext.getRequest();
		String k=request.getParameter("na");
		int kid=Integer.parseInt(k);
		if (kid==0) {
			kid=1;
			int s=biz.count(kid);
			request.setAttribute("s", s);
			request.setAttribute("hkid", kid);
			return "fangke";
		}else if (kid==1) {
			int s=biz.count(kid);
			request.setAttribute("s", s);
			request.setAttribute("hkid", kid);
			return "fxkm";
		} else {
			int c=biz.count(kid);
			kemu=biz.selectmu(kid);
			request.setAttribute("on", c);
			request.setAttribute("hkid", kid);
			return "xiangmu";
		}		
	}
	public String tiku() {
		HttpServletRequest request=ServletActionContext.getRequest();
		Integer kid=Integer.parseInt(request.getParameter("kid").trim());
		request.setAttribute("hkid", kid);
		Integer p=1;
		String ps=request.getParameter("sp");
		if(ps!=null){
		p=Integer.parseInt(ps.trim());
		};	
		pb=biz.selectshiti(kid,p);
		
		return "tiku";
		
	}
	
	public String fenye() {
		HttpServletRequest request=ServletActionContext.getRequest();
		Integer kid=Integer.parseInt(request.getParameter("kid").trim());
		request.setAttribute("hkid", kid);
		Integer p=1;
		String ps=request.getParameter("sp");
		if(ps!=null){
		p=Integer.parseInt(ps.trim());
		};	
		pb=biz.selectshiti(kid,p);
		return "fenye";	
	}
	public String addtiku() {
		HttpServletRequest request=ServletActionContext.getRequest();
		String name=request.getParameter("kname");
		int kid=biz.selectke(name);
		System.out.println(kid);
		shiti1.setTidalie("����");
		shiti1.setKid(kid);
		shiti1.setShijuans(null);
		int s=biz.insert(shiti1);
		System.out.println(s);
		if (s==0) {
			return "add";
		} else {
			return "notadd";
		}
	}
	public String select() {
		HttpServletRequest request=ServletActionContext.getRequest();
		int kid=Integer.parseInt(request.getParameter("kid").trim());
		kemu=biz.selectmu(kid);
		int tid=Integer.parseInt(request.getParameter("tid").trim());
		shiti=biz.selectdan(tid);
		return "select";
		
	}

	
	
	
	
	
	
	
	public List<Shiti> getList() {
		return list;
	}
	public void setList(List<Shiti> list) {
		this.list = list;
	}
	public Shiti getShiti() {
		return shiti;
	}
	public void setShiti(Shiti shiti) {
		this.shiti = shiti;
	}
	public List<Fangxiang> getList1() {
		return list1;
	}
	public void setList1(List<Fangxiang> list1) {
		this.list1 = list1;
	}
	public List<Kemu> getList2() {
		return list2;
	}
	public void setList2(List<Kemu> list2) {
		this.list2 = list2;
	}
	public Kemu getKemu() {
		return kemu;
	}
	public void setKemu(Kemu kemu) {
		this.kemu = kemu;
	}
	public PageBean getPb() {
		return pb;
	}
	public void setPb(PageBean pb) {
		this.pb = pb;
	}
	public Shiti getShiti1() {
		return shiti1;
	}
	public void setShiti1(Shiti shiti1) {
		this.shiti1 = shiti1;
	}
	
	
}
