package com.action;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import tools.PageBean;

import com.biz.Tikubiz;
import com.biz.impl.Tikubizimpl;
import com.util.ExcelDao;






public class UploadAction {
//	private String name;
//	private File upload;//���ļ��ϴ��ؼ�����ͬ������˽����ϴ��ļ����ݵ���ʱ�ļ�
//	private String uploadFileName;//�ļ��ϴ��ؼ���+Name�����ϴ��ļ����ļ���
	//private String uploadContentType;//�ļ��ϴ��ؼ���+Type�����ϴ��ļ���MIME����
	private String name;
	private File filename;
	private String filenameFileName;
	private String filenameContentType;
	private PageBean pb;
	private int kid;
	private Tikubiz biz=new Tikubizimpl();
	private String downfile_name;
	private InputStream downfile_is;
	
	public String upload(){
		if(filename!=null){
			try {
				InputStream is=new FileInputStream(filename);
				String filepath=ServletActionContext.getServletContext().getRealPath("/")
					+"upload/"+filenameFileName;
				OutputStream os=new FileOutputStream(filepath);
				byte[] buffer=new byte[8096];
				int len=0;
				while ((len=is.read(buffer))!=-1) {
					os.write(buffer, 0, len);
				}
				ExcelDao ed=new ExcelDao();
				//�õ�excel��������
				List list=ed.getAllByExcel(filepath);
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		HttpServletRequest request=ServletActionContext.getRequest();
		kid=Integer.parseInt(request.getParameter("hkid").trim());
		pb=biz.selectshiti(kid, 1);
		request.setAttribute("filenameFileName", filenameFileName);
		request.setAttribute("hkid", kid);
		return "upload";
	}
	public String download(){
	
		return "download";
		
	}
	public InputStream getInputStream(){
		String filepath=ServletActionContext.getServletContext().getRealPath("/upload/Topic.xls");
		System.out.println(filepath);
	try {
		downfile_is=new FileInputStream(filepath);
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		return downfile_is; 
		//ServletActionContext.getServletContext().getResourceAsStream("dowlad/Topic.xls");
	}
	

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}
	public File getFilename() {
		return filename;
	}
	public void setFilename(File filename) {
		this.filename = filename;
	}
	public String getFilenameFileName() {
		return filenameFileName;
	}
	public void setFilenameFileName(String filenameFileName) {
		this.filenameFileName = filenameFileName;
	}
	public String getFilenameContentType() {
		return filenameContentType;
	}
	public void setFilenameContentType(String filenameContentType) {
		this.filenameContentType = filenameContentType;
	}
	public PageBean getPb() {
		return pb;
	}
	public void setPb(PageBean pb) {
		this.pb = pb;
	}
	public int getKid() {
		return kid;
	}
	public void setKid(int kid) {
		this.kid = kid;
	}
	public String getDownfile_name() {
		return downfile_name;
	}
	public void setDownfile_name(String downfileName) {
		downfile_name = downfileName;
	}
	public InputStream getDownfile_is() {
		return downfile_is;
	}
	public void setDownfile_is(InputStream downfileIs) {
		downfile_is = downfileIs;
	}


	
		
	
	


}
