package com.action;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.bean.Shiti;
import com.biz.Tikubiz;
import com.biz.impl.Tikubizimpl;

public class XiugaiActopn {
	private Shiti shiti1;
	private String[] option;
	private Tikubiz biz=new Tikubizimpl();
	public String update() {
		HttpServletRequest request=ServletActionContext.getRequest();
		Shiti shiti=biz.selectdan(shiti1.getTid());
		shiti.setKid(shiti1.getKid());
		shiti.setZhuti(shiti1.getZhuti());
		shiti.setOptionA(shiti1.getOptionA());
		shiti.setOptionB(shiti1.getOptionB());
		shiti.setOptionC(shiti1.getOptionC());
		shiti.setOptionD(shiti1.getOptionD());
		shiti.setTidalie(shiti1.getTidalie());
		shiti.setTixiaolie(shiti1.getTixiaolie());
		String daan=" ";
		for (String string : option) {
			daan+=string+"";
		}
	
		shiti.setDaan(daan);
		shiti.setNanyidu(shiti1.getNanyidu());
		shiti.setZhangjie(shiti1.getZhangjie());
		int s=biz.update(shiti);
		if (s==0) {
			return "update";
		} else {
			return "notupdate";
		}
	}
	public Shiti getShiti1() {
		return shiti1;
	}
	public void setShiti1(Shiti shiti1) {
		this.shiti1 = shiti1;
	}
	public String[] getOption() {
		return option;
	}
	public void setOption(String[] option) {
		this.option = option;
	}
	

}
