package com.bean;



/**
 * Kemu entity. @author MyEclipse Persistence Tools
 */

public class Kemu  implements java.io.Serializable {


    // Fields    

     private Integer kid;
     private Jieduan jieduan;
     private Fangxiang fangxiang;
     private String kname;


    // Constructors

    /** default constructor */
    public Kemu() {
    }

	/** minimal constructor */
    public Kemu(Jieduan jieduan, Fangxiang fangxiang) {
        this.jieduan = jieduan;
        this.fangxiang = fangxiang;
    }
    
    /** full constructor */
    public Kemu(Jieduan jieduan, Fangxiang fangxiang, String kname) {
        this.jieduan = jieduan;
        this.fangxiang = fangxiang;
        this.kname = kname;
    }

   
    // Property accessors

    public Integer getKid() {
        return this.kid;
    }
    
    public void setKid(Integer kid) {
        this.kid = kid;
    }

    public Jieduan getJieduan() {
        return this.jieduan;
    }
    
    public void setJieduan(Jieduan jieduan) {
        this.jieduan = jieduan;
    }

    public Fangxiang getFangxiang() {
        return this.fangxiang;
    }
    
    public void setFangxiang(Fangxiang fangxiang) {
        this.fangxiang = fangxiang;
    }

    public String getKname() {
        return this.kname;
    }
    
    public void setKname(String kname) {
        this.kname = kname;
    }
   








}