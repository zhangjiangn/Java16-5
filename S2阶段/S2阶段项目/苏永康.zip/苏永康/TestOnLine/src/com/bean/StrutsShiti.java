package com.bean;



/**
 * StrutsShiti entity. @author MyEclipse Persistence Tools
 */

public class StrutsShiti  implements java.io.Serializable {


    // Fields    

     private Integer stid;
     private Integer sid;
     private Integer jid;
     private Integer tid;
     private String daan;
     private String dantifen;
     private String zqdaan;

    // Constructors

    /** default constructor */
    public StrutsShiti() {
    }

	/** minimal constructor */
    public StrutsShiti(Integer sid, Integer jid, Integer tid) {
        this.sid = sid;
        this.jid = jid;
        this.tid = tid;
    }
    
    /** full constructor */
  
    // Property accessors

    public Integer getStid() {
        return this.stid;
    }
    
    public StrutsShiti(Integer stid, Integer sid, Integer jid, Integer tid,
			String daan, String dantifen, String zqdaan) {
		super();
		this.stid = stid;
		this.sid = sid;
		this.jid = jid;
		this.tid = tid;
		this.daan = daan;
		this.dantifen = dantifen;
		this.zqdaan = zqdaan;
	}

	public String getDantifen() {
		return dantifen;
	}

	public void setDantifen(String dantifen) {
		this.dantifen = dantifen;
	}

	public String getZqdaan() {
		return zqdaan;
	}

	public void setZqdaan(String zqdaan) {
		this.zqdaan = zqdaan;
	}

	public void setStid(Integer stid) {
        this.stid = stid;
    }

    public Integer getSid() {
        return this.sid;
    }
    
    public void setSid(Integer sid) {
        this.sid = sid;
    }

    public Integer getJid() {
        return this.jid;
    }
    
    public void setJid(Integer jid) {
        this.jid = jid;
    }

    public Integer getTid() {
        return this.tid;
    }
    
    public void setTid(Integer tid) {
        this.tid = tid;
    }

    public String getDaan() {
        return this.daan;
    }
    
    public void setDaan(String daan) {
        this.daan = daan;
    }
   








}