package com.bean;



/**
 * Chengji entity. @author MyEclipse Persistence Tools
 */

public class Chengji  implements java.io.Serializable {


    // Fields    

     private Integer cjid;
     private Integer sid;
     private Integer jid;
     private String kais;
     private String jies;
     private Integer chengji;


    // Constructors

    /** default constructor */
    public Chengji() {
    }

	/** minimal constructor */
    public Chengji(Integer sid, Integer jid) {
        this.sid = sid;
        this.jid = jid;
    }
    
    /** full constructor */
    public Chengji(Integer sid, Integer jid, String kais, String jies, Integer chengji) {
        this.sid = sid;
        this.jid = jid;
        this.kais = kais;
        this.jies = jies;
        this.chengji = chengji;
    }

   
    // Property accessors

    public Integer getCjid() {
        return this.cjid;
    }
    
    public void setCjid(Integer cjid) {
        this.cjid = cjid;
    }

    public Integer getSid() {
        return this.sid;
    }
    
    public void setSid(Integer sid) {
        this.sid = sid;
    }

    public Integer getJid() {
        return this.jid;
    }
    
    public void setJid(Integer jid) {
        this.jid = jid;
    }

    public String getKais() {
        return this.kais;
    }
    
    public void setKais(String kais) {
        this.kais = kais;
    }

    public String getJies() {
        return this.jies;
    }
    
    public void setJies(String jies) {
        this.jies = jies;
    }

    public Integer getChengji() {
        return this.chengji;
    }
    
    public void setChengji(Integer chengji) {
        this.chengji = chengji;
    }
   








}