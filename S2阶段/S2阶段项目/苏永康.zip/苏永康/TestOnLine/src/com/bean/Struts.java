package com.bean;



/**
 * Struts entity. @author MyEclipse Persistence Tools
 */

public class Struts  implements java.io.Serializable {


    // Fields    

     private Integer sid;
     private Clases clases;
     private String sname;
     private String szhanghao;
     private String spwd;
     private String xinbie;
     private String nianling;
     private String role;


    // Constructors

    /** default constructor */
    public Struts() {
    }

	/** minimal constructor */
    public Struts(Clases clases) {
        this.clases = clases;
    }
    
    /** full constructor */
    public Struts(Clases clases, String sname, String szhanghao, String spwd, String xinbie, String nianling, String role) {
        this.clases = clases;
        this.sname = sname;
        this.szhanghao = szhanghao;
        this.spwd = spwd;
        this.xinbie = xinbie;
        this.nianling = nianling;
        this.role = role;
    }

   
    // Property accessors

    public Integer getSid() {
        return this.sid;
    }
    
    public void setSid(Integer sid) {
        this.sid = sid;
    }

    public Clases getClases() {
        return this.clases;
    }
    
    public void setClases(Clases clases) {
        this.clases = clases;
    }

    public String getSname() {
        return this.sname;
    }
    
    public void setSname(String sname) {
        this.sname = sname;
    }

    public String getSzhanghao() {
        return this.szhanghao;
    }
    
    public void setSzhanghao(String szhanghao) {
        this.szhanghao = szhanghao;
    }

    public String getSpwd() {
        return this.spwd;
    }
    
    public void setSpwd(String spwd) {
        this.spwd = spwd;
    }

    public String getXinbie() {
        return this.xinbie;
    }
    
    public void setXinbie(String xinbie) {
        this.xinbie = xinbie;
    }

    public String getNianling() {
        return this.nianling;
    }
    
    public void setNianling(String nianling) {
        this.nianling = nianling;
    }

    public String getRole() {
        return this.role;
    }
    
    public void setRole(String role) {
        this.role = role;
    }
   








}