package com.bean;

import java.util.HashSet;
import java.util.Set;


/**
 * Jieduan entity. @author MyEclipse Persistence Tools
 */

public class Jieduan  implements java.io.Serializable {


    // Fields    

     private Integer jid;
     private String jname;
     private Set kemus = new HashSet(0);


    // Constructors

    /** default constructor */
    public Jieduan() {
    }

    
    /** full constructor */
    public Jieduan(String jname, Set kemus) {
        this.jname = jname;
        this.kemus = kemus;
    }

   
    // Property accessors

    public Integer getJid() {
        return this.jid;
    }
    
    public void setJid(Integer jid) {
        this.jid = jid;
    }

    public String getJname() {
        return this.jname;
    }
    
    public void setJname(String jname) {
        this.jname = jname;
    }

    public Set getKemus() {
        return this.kemus;
    }
    
    public void setKemus(Set kemus) {
        this.kemus = kemus;
    }
   








}