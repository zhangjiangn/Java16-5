package com.bean;

import java.util.HashSet;
import java.util.Set;


/**
 * Fangxiang entity. @author MyEclipse Persistence Tools
 */

public class Fangxiang  implements java.io.Serializable {


    // Fields    

     private Integer fid;
     private Fangxiang fangxiang;
     private String fname;
     private Set kemus = new HashSet(0);
     private Set fangxiangs = new HashSet(0);


    // Constructors

    /** default constructor */
    public Fangxiang() {
    }

	/** minimal constructor */
    public Fangxiang(Fangxiang fangxiang) {
        this.fangxiang = fangxiang;
    }
    
    /** full constructor */
    public Fangxiang(Fangxiang fangxiang, String fname, Set kemus, Set fangxiangs) {
        this.fangxiang = fangxiang;
        this.fname = fname;
        this.kemus = kemus;
        this.fangxiangs = fangxiangs;
    }

   
    // Property accessors

    public Integer getFid() {
        return this.fid;
    }
    
    public void setFid(Integer fid) {
        this.fid = fid;
    }

    public Fangxiang getFangxiang() {
        return this.fangxiang;
    }
    
    public void setFangxiang(Fangxiang fangxiang) {
        this.fangxiang = fangxiang;
    }

    public String getFname() {
        return this.fname;
    }
    
    public void setFname(String fname) {
        this.fname = fname;
    }

    public Set getKemus() {
        return this.kemus;
    }
    
    public void setKemus(Set kemus) {
        this.kemus = kemus;
    }

    public Set getFangxiangs() {
        return this.fangxiangs;
    }
    
    public void setFangxiangs(Set fangxiangs) {
        this.fangxiangs = fangxiangs;
    }
   








}