package com.bean;

import java.util.HashSet;
import java.util.Set;

public class Shiti {
	
	private Integer tid;
    private Integer kid;
    private String tidalie;
    private String tixiaolie;
    private String zhuti;
    private String optionA;
    private String optionB;
    private String optionC;
    private String optionD;
    private String daan;
    private String nanyidu;
    private String zhangjie;
    private Set shijuans = new HashSet(0);
    
    
    
	public Shiti() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Shiti(Integer tid, Integer kid, String tidalie, String tixiaolie,
			String zhuti, String optionA, String optionB, String optionC,
			String optionD, String daan, String nanyidu, String zhangjie,
			Set shijuans) {
		super();
		this.tid = tid;
		this.kid = kid;
		this.tidalie = tidalie;
		this.tixiaolie = tixiaolie;
		this.zhuti = zhuti;
		this.optionA = optionA;
		this.optionB = optionB;
		this.optionC = optionC;
		this.optionD = optionD;
		this.daan = daan;
		this.nanyidu = nanyidu;
		this.zhangjie = zhangjie;
		this.shijuans = shijuans;
	}
	public Integer getTid() {
		return tid;
	}
	public void setTid(Integer tid) {
		this.tid = tid;
	}
	public Integer getKid() {
		return kid;
	}
	public void setKid(Integer kid) {
		this.kid = kid;
	}
	public String getTidalie() {
		return tidalie;
	}
	public void setTidalie(String tidalie) {
		this.tidalie = tidalie;
	}
	public String getTixiaolie() {
		return tixiaolie;
	}
	public void setTixiaolie(String tixiaolie) {
		this.tixiaolie = tixiaolie;
	}
	public String getZhuti() {
		return zhuti;
	}
	public void setZhuti(String zhuti) {
		this.zhuti = zhuti;
	}
	public String getOptionA() {
		return optionA;
	}
	public void setOptionA(String optionA) {
		this.optionA = optionA;
	}
	public String getOptionB() {
		return optionB;
	}
	public void setOptionB(String optionB) {
		this.optionB = optionB;
	}
	public String getOptionC() {
		return optionC;
	}
	public void setOptionC(String optionC) {
		this.optionC = optionC;
	}
	public String getOptionD() {
		return optionD;
	}
	public void setOptionD(String optionD) {
		this.optionD = optionD;
	}
	public String getDaan() {
		return daan;
	}
	public void setDaan(String daan) {
		this.daan = daan;
	}
	public String getNanyidu() {
		return nanyidu;
	}
	public void setNanyidu(String nanyidu) {
		this.nanyidu = nanyidu;
	}
	public String getZhangjie() {
		return zhangjie;
	}
	public void setZhangjie(String zhangjie) {
		this.zhangjie = zhangjie;
	}
	public Set getShijuans() {
		return shijuans;
	}
	public void setShijuans(Set shijuans) {
		this.shijuans = shijuans;
	}
    
}
