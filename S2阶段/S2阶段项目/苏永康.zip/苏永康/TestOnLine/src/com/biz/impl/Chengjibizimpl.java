package com.biz.impl;

import java.util.List;

import tools.PageBean;

import com.bean.Clases;
import com.bean.Fangxiang;
import com.bean.Jieduan;
import com.bean.Kemu;
import com.bean.Shijuan;
import com.bean.Shiti;
import com.bean.Struts;
import com.bean.StrutsShiti;
import com.biz.Chengjibiz;
import com.dao.Chengjidao;
import com.dao.impl.Chengjidaoimpl;

public class Chengjibizimpl implements Chengjibiz {
public Chengjidao dao=new Chengjidaoimpl();

public List<Fangxiang> fangxiangs() {
	// TODO Auto-generated method stub
	return dao.fangxiangs();
}

public PageBean fenye(int p) {
	// TODO Auto-generated method stub
	return dao.fenye(p);
}

public List<Jieduan> jieduans() {
	// TODO Auto-generated method stub
	return dao.jieduans();
}

public List<Kemu> kemus() {
	// TODO Auto-generated method stub
	return dao.kemus();
}



public Shijuan Shijuan(int jid) {
	// TODO Auto-generated method stub
	return dao.Shijuan(jid);
}

public List<Struts> struts(int sid) {
	// TODO Auto-generated method stub
	return dao.struts(sid);
}

public int shiti(int tid) {
	// TODO Auto-generated method stub
	return dao.shiti(tid);
}

public int strut(int tid) {
	// TODO Auto-generated method stub
	return dao.strut(tid);
}

public List<Clases> list() {
	// TODO Auto-generated method stub
	return dao.list();
}

public List<StrutsShiti> strutsShitis(int jid) {
	// TODO Auto-generated method stub
	return dao.strutsShitis(jid);
}

public Shijuan shijuans(int jid) {
	// TODO Auto-generated method stub
	return dao.shijuans(jid);
}

public Struts stru(int sid) {
	// TODO Auto-generated method stub
	return dao.stru(sid);
}

public Shiti shi(int sid) {
	// TODO Auto-generated method stub

	return dao.shi(sid);
}

public List<Shijuan> shijuan(String kmname, String jiedname, String fanxname,
		String sjlie) {
	// TODO Auto-generated method stub
	return dao.shijuan(kmname, jiedname, fanxname, sjlie);
}

public int sid(String sname) {
	// TODO Auto-generated method stub
	return dao.sid(sname);
}

public List<StrutsShiti> strutsshitis(int jid, int sid) {
	// TODO Auto-generated method stub
	return dao.strutsshitis(jid, sid);
}






}
