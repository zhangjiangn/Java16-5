package com.biz.impl;


import java.util.List;

import tools.PageBean;

import com.bean.Fangxiang;
import com.bean.Kemu;
import com.bean.Shiti;
import com.biz.Tikubiz;
import com.dao.Tikudao;
import com.dao.impl.Tikudaoimpl;

public class Tikubizimpl implements Tikubiz {
	public Tikudao dao=new Tikudaoimpl();

	public int insert(Shiti shiti) {
		// TODO Auto-generated method stub
		
		return dao.insert(shiti);
	}
	public Shiti selectdan(int tid) {
		// TODO Auto-generated method stub
		return dao.selectdan(tid);
	}


	public int update(Shiti shiti) {
		// TODO Auto-generated method stub
		return dao.update(shiti);
	}


	public List<Fangxiang> selectfang() {
		// TODO Auto-generated method stub
		return dao.selectfang();
	}


	public List<Kemu> selectku() {
		// TODO Auto-generated method stub
		return dao.selectku();
	}


	public PageBean selectshiti(int kid,int p) {
		// TODO Auto-generated method stub
		return dao.selectshiti(kid,p);
	}
	public int count(int kid) {
		// TODO Auto-generated method stub
		return dao.count(kid);
	}
	public Kemu selectmu(int kid) {
		// TODO Auto-generated method stub
		return dao.selectmu(kid);
	}
	public int selectke(String name) {
		// TODO Auto-generated method stub
		return dao.selectke(name);
	}
	public List<Kemu> selects(String kname) {
		// TODO Auto-generated method stub
		return dao.selects(kname);
	}
}
