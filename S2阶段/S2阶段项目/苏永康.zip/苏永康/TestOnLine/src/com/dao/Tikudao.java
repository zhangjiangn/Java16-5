package com.dao;

import java.util.List;

import org.hibernate.Session;

import tools.PageBean;

import com.bean.Fangxiang;
import com.bean.Kemu;
import com.bean.Shiti;

public interface Tikudao {
	
	public Session session=HibernateSessionFactory.getSession();
	public PageBean selectshiti(int kid,int p);
	public int insert(Shiti shiti);
	public Shiti selectdan(int tid);
	public int update(Shiti shiti);
	public List<Fangxiang> selectfang();
	public List<Kemu> selectku();
	public int count(int kid);
	public Kemu selectmu(int kid);
	public int selectke(String name);
	public List<Kemu> selects(String kname);
}
