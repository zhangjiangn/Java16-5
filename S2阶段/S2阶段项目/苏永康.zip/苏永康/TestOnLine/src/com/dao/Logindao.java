package com.dao;

import java.util.List;

import org.hibernate.Session;

import com.bean.Emp;
import com.bean.Struts;

public interface Logindao {
	public Session session=HibernateSessionFactory.getSession();
	public Emp login(String sname,String spwd); 
	public Struts Logins(String sname,String spwd);
}
