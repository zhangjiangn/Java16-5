package com.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tools.PageBean;

import com.bean.Clases;
import com.bean.Fangxiang;
import com.bean.Jieduan;
import com.bean.Kemu;
import com.bean.Shijuan;
import com.bean.Shiti;
import com.bean.Struts;
import com.bean.StrutsShiti;
import com.dao.Chengjidao;

public class Chengjidaoimpl implements Chengjidao{

	public List<Fangxiang> fangxiangs() {
		// TODO Auto-generated method stub
		String hql="from Fangxiang";
		List<Fangxiang> list=session.createQuery(hql).list();
		
		return list;
	}

	public PageBean fenye(int p) {
		// TODO Auto-generated method stub
		PageBean pb=new PageBean();
		Criteria criteria=session.createCriteria(Shijuan.class).add(Restrictions.eq("sjztai", "���Խ���"));	
		Projection projections=Projections.rowCount();
		criteria.setProjection(projections);
		int count=(Integer) criteria.uniqueResult();	
		pb.setPagesize(10);
		pb.setCount(count);
		pb.setP(p);		
		String hql="from Shijuan where sjztai in (:sjztai)";
		Query query=session.createQuery(hql);
		query.setString("sjztai", "���Խ���");
		int k=pb.getPagesize();
		query.setFirstResult((pb.getP()-1)*k)
				.setMaxResults(k);			
		List<Shijuan> list=query.list();
		pb.setData(list);
		return pb;
	}
	public List<Jieduan> jieduans() {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		String hql="from Jieduan";
		List<Jieduan> list=session.createQuery(hql).list();
		
		return list;
	}

	public List<Kemu> kemus() {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		String hql="from Kemu";
		List<Kemu> list=session.createQuery(hql).list();
		
		return list;
	}

 

	public Shijuan Shijuan(int jid) {
		// TODO Auto-generated method stub
		Shijuan shijuan=(Shijuan) session.get(Shijuan.class, jid);
		return shijuan;
	}

	public List<Struts> struts(int sid) {
		// TODO Auto-generated method stub
		Criteria criteria=session.createCriteria(Struts.class).add(Restrictions.eq("sid", sid));
		List<Struts> list=criteria.list();
		return list;
	}

	public int shiti(int tid) {
		int s=0;
		// TODO Auto-generated method stub
		Criteria criteria=session.createCriteria(StrutsShiti.class).add(Restrictions.eq("jid", tid));
		List<StrutsShiti> list=criteria.list();
		for (StrutsShiti strutsShiti : list) {
			s=strutsShiti.getSid();
		}
		return s;
	}

	public int strut(int tid) {
		int s=0;
		// TODO Auto-generated method stub
		Criteria criteria=session.createCriteria(StrutsShiti.class).add(Restrictions.eq("jid", tid));
		List<StrutsShiti> list=criteria.list();
		for (StrutsShiti strutsShiti : list) {
			s=strutsShiti.getJid();
		}
		return s;
	}

	public List<Clases> list() {
		// TODO Auto-generated method stub
		Criteria criteria=session.createCriteria(Clases.class);
			List<Clases> list=criteria.list();
		return list;
	}

	public List<StrutsShiti> strutsShitis(int jid) {
		// TODO Auto-generated method stub
		Criteria criteria=session.createCriteria(StrutsShiti.class).add(Restrictions.eq("jid", jid)).add(Restrictions.ne("daan", "NULL"));
		List<StrutsShiti> list=criteria.list();
		return list;
	}

	public Shijuan shijuans(int jid) {
		// TODO Auto-generated method stub
		Shijuan shijuan=(Shijuan) session.get(Shijuan.class, jid);
		return shijuan;
	}

	public Struts stru(int sid) {
		// TODO Auto-generated method stub
		Struts struts=(Struts) session.get(Struts.class, sid);
		
		return struts;
	}

	public Shiti shi(int sid) {
		// TODO Auto-generated method stub
		Shiti shiti=(Shiti) session.get(Shiti.class, sid);
		return shiti;
	}

	public List<Shijuan> shijuan(String kmname, String jiedname, String fanxname,
			 String sjlie) {
		// TODO Auto-generated method stub

		Criteria criteria=session.createCriteria(Shijuan.class)
						.add(Restrictions.eq("kmname", kmname))
						.add(Restrictions.eq("jiedname", jiedname))
						.add(Restrictions.eq("fanxname", fanxname))
						.add(Restrictions.eq("sjlie", sjlie))
						.add(Restrictions.eq("sjztai", "���Խ���"));
		 List<Shijuan> list=criteria.list();
		
		return list;
	}

	public int sid(String sname) {
		int s=0;
		// TODO Auto-generated method stub
		Criteria criteria=session.createCriteria(Struts.class).add(Restrictions.eq("sname", sname));
		List<Struts> list=criteria.list();
		for (Struts struts : list) {
			s=struts.getSid();
		}
		return s;
	}

	public List<StrutsShiti> strutsshitis(int jid, int sid) {
		// TODO Auto-generated method stub
		Criteria criteria=session.createCriteria(StrutsShiti.class).add(Restrictions.eq("jid", jid)).add(Restrictions.eq("sid", sid)).add(Restrictions.ne("daan", "NULL"));
		List<StrutsShiti> list=criteria.list();
		return list;
	}


}
