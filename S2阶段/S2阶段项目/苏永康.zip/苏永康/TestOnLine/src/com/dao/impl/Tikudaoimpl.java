package com.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tools.PageBean;

import com.bean.Fangxiang;
import com.bean.Kemu;
import com.bean.Shiti;
import com.dao.Tikudao;

public class Tikudaoimpl implements Tikudao {

	public int insert(Shiti shiti) {
		// TODO Auto-generated method stub
		int s=0;
		try {
			session.beginTransaction();
			session.save(shiti);
			session.beginTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			s=1;
		}
		return s;
	}

	

	public PageBean selectshiti(int kid,int p) {
		// TODO Auto-generated method stub
		PageBean pb=new PageBean();
		Criteria criteria=session.createCriteria(Shiti.class).add(Restrictions.eq("kid", kid));
		Projection projections=Projections.rowCount();
		criteria.setProjection(projections);
		int count=(Integer) criteria.uniqueResult();	
		pb.setPagesize(10);
		pb.setCount(count);
		pb.setP(p);
		
		String hql="from Shiti where kid in (:kid)";
		Query query=session.createQuery(hql);
		String sl=String.valueOf(kid);
		int k=pb.getPagesize();
		query.setFirstResult((pb.getP()-1)*k)
				.setMaxResults(k)
				.setString("kid", sl);
		List<Shiti> list=query.list();
		pb.setData(list);
		return pb;
	}



	public Shiti selectdan(int tid) {
		// TODO Auto-generated method stub
		Shiti shiti=(Shiti) session.get(Shiti.class, tid);
		return shiti;
	}



	public int update(Shiti shiti) {
		// TODO Auto-generated method stub
		int s=0;
		try {
			session.beginTransaction();
			session.update(shiti);
			session.flush();
			session.beginTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			s=1;
		}
		return s;
	}



	public List<Fangxiang> selectfang() {
		// TODO Auto-generated method stub
		String hql="from Fangxiang";
		 List<Fangxiang> list=session.createQuery(hql).list();
		return list;
	}



	public List<Kemu> selectku() {
		// TODO Auto-generated method stub
		String hql="from Kemu";
		List<Kemu> list=session.createQuery(hql).list();
		return list;
	}



	public int count(int kid) {
		// TODO Auto-generated method stub
		int s=0;
		Criteria criteria=session.createCriteria(Shiti.class).add(Restrictions.eq("kid", kid));
		Projection projections=Projections.rowCount();
		criteria.setProjection(projections);
		 s=(Integer) criteria.uniqueResult();	
		return s;
	}



	public Kemu selectmu(int kid) {
		// TODO Auto-generated method stub
		Kemu kemu=(Kemu) session.get(Kemu.class, kid);
		return kemu;
	}
	public List<Kemu> selects(String kname) {
		// TODO Auto-generated method stub
		Criteria criteria=session.createCriteria(Kemu.class).add(Restrictions.eq("kname", kname));
		List<Kemu> list=criteria.list();
		return list;
	}


	public int selectke(String name) {
		// TODO Auto-generated method stub
		int s=0;
		Criteria criteria=session.createCriteria(Kemu.class).add(Restrictions.eq("kname", name));
		List<Kemu> list=criteria.list();
		for (Kemu kemu : list) {
			s=kemu.getKid();
		}
		return s;
	}

}
