package com.dao;

import java.util.List;

import org.hibernate.Session;

import tools.PageBean;

import com.bean.Clases;
import com.bean.Shijuan;
import com.bean.Shiti;
import com.bean.StrutsShiti;
import com.util.PageBeans;

public interface Kaoshidao {
	public Session session=HibernateSessionFactory.getSession();
	public List<Shijuan> shijuan(int jid);
	public Shijuan shijian(int jid);
	public Shiti shiti(int p,int jid);
	public int insertss(StrutsShiti strutsShiti);
	public int updatess(int sid,int tid,int jid,String daan,String zqdaan,String dantifen);
	public List<StrutsShiti> panduan(int sid,int jid);
	public List<StrutsShiti> chankang(int sid);
	public int update(int sid,String zqdaan);
}
