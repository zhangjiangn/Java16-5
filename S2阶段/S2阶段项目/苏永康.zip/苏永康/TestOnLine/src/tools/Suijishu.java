package tools;

import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

public class Suijishu {
	
	public 	Set<Integer>  shuijishu(int shu) {
		
		 Random ran = new Random();  
	     Set<Integer> set = new TreeSet<Integer>(); 
	     while (true) {  
	         int a = ran.nextInt(20);  
	         set.add(a);  
	         if (set.size()>(shu-1)) {  
	        	 return set;  
	         }  
	     }
		
	
	
}}
