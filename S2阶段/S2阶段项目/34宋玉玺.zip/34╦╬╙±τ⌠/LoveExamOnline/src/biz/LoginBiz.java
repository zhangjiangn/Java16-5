package biz;

import bean.Students;
import bean.Users;

public interface LoginBiz {
	public Students stuLogin(String sname,String spwd);
	public Users userLogin(String uname,String upwd);
}
