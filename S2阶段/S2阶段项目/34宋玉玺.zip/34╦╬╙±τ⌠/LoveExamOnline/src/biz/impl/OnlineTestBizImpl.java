package biz.impl;

import java.util.List;

import dao.OnlineTestDao;
import dao.impl.OnlineTestDaoImpl;
import bean.Grades;
import bean.PageBean;
import bean.StudentsTq;
import bean.Testpapers;
import bean.Testquestions;
import bean.TpTq;
import biz.OnlineTestBiz;

public class OnlineTestBizImpl implements OnlineTestBiz {
	OnlineTestDao dao=new OnlineTestDaoImpl();

	public PageBean querytestpapers(int p,int cid,String state) {
		
		return dao.querytestpapers(p,cid,state);
	}

	public Testpapers tp(int tpid) {
		
		return dao.tp(tpid);
	}

	public List<TpTq> pq(int tpid) {
		
		return dao.pq(tpid);
	}

	public Testquestions tq(int tqid) {
		
		return dao.tq(tqid);
	}

	public int addstutq(int sid, int ssid) {
		
		return dao.addstutq(sid, ssid);
	}

	public int updatestutq(int sssid, String sanswer) {
		
		return dao.updatestutq(sssid, sanswer);
	}

	public List<StudentsTq> stq(int tpid) {
		
		return dao.stq(tpid);
	}

	public int addgrades(Grades grade) {
		
		return dao.addgrades(grade);
	}
}
