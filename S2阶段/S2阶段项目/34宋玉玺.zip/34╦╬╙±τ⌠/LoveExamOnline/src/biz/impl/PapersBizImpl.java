package biz.impl;

import java.util.List;

import dao.PapersDao;
import dao.impl.PapersDaoImpl;
import bean.Classes;
import bean.Directions;
import bean.PageBean;
import bean.Stages;
import bean.Subjects;
import bean.Testpapers;
import bean.TpTq;
import biz.PapersBiz;

public class PapersBizImpl implements PapersBiz {
	PapersDao dao=new PapersDaoImpl();

	public List<Directions> queryDirections() {
		
		return dao.queryDirections();
	}
	public List<Stages> queryStages() {
		
		return dao.queryStages();
	}


	public PageBean showpapers(int p, int subid,String topicbigtype,String state) {
		
		return dao.showpapers(p, subid, topicbigtype, state);
	}

	public List<Subjects> querySubjects(int did, int stid) {
		
		return dao.querySubjects(did, stid);
	}

	public PageBean showpapersall(int p) {
		
		return dao.showpapersall(p);
	}
	public int addpapers(Testpapers testpapers) {
		
		return dao.addpapers(testpapers);
	}
	public PageBean queryTestquestions(int p, int subid) {
		
		return dao.queryTestquestions(p, subid);
	}
	public int addtp_tq(Testpapers tp, int tqid) {
		
		return dao.addtp_tq(tp, tqid);
	}
	public PageBean pq(int p,int tpid){
		
		return dao.pq(p,tpid);
	}
	public int beginexam(int tpid, int cid,Testpapers tp) {
		
		return dao.beginexam(tpid, cid, tp);
	}
	public List<Classes> queryclasses() {
		
		return dao.queryclasses();
	}
	public int endexam(int tpid) {
		
		return dao.endexam(tpid);
	}
	public int randomaddpapers(int subid,int tpid, int number, String topictype,
			String difficulty) {
		
		return dao.randomaddpapers(subid,tpid, number, topictype, difficulty);
	}
	

}
