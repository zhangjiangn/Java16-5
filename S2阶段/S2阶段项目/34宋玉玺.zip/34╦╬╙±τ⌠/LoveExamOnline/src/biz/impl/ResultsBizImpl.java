package biz.impl;

import java.util.List;

import dao.ResultsDao;
import dao.impl.ResultsDaoImpl;

import bean.Classes;
import bean.Directions;
import bean.Grades;
import bean.PageBean;
import bean.Stages;
import bean.Subjects;
import biz.ResultsBiz;

public class ResultsBizImpl implements ResultsBiz {
	ResultsDao dao=new ResultsDaoImpl();
	public PageBean cquerytestpapers(int p, int subid, String topicbigtype,
			String state) {
		
		return dao.cquerytestpapers(p, subid, topicbigtype, state);
	}

	public List<Directions> queryDirections() {
		
		return dao.queryDirections();
	}

	public List<Stages> queryStages() {
		
		return dao.queryStages();
	}

	public List<Subjects> querySubjects(int did, int stid) {
		
		return dao.querySubjects(did, stid);
	}

	public PageBean querytestpapers(int p, String state) {
		
		return dao.querytestpapers(p, state);
	}

	public PageBean pq(int p, int tpid) {
		
		return dao.pq(p, tpid);
	}

	public List<Classes> queryclasses() {
		
		return dao.queryclasses();
	}

	public PageBean cquerygrades(int p, int tpid, int cid) {
		
		return dao.cquerygrades(p, tpid, cid);
	}

	public PageBean ccquerygrades(int p, int tpid, int cid, String sname) {
		
		return dao.ccquerygrades(p, tpid, cid, sname);
	}

	public PageBean querygrades(int p, int tpid) {
		
		return dao.querygrades(p, tpid);
	}

	public PageBean querystutq(int p, int sid, int tpid) {
		
		return dao.querystutq(p, sid, tpid);
	}

	public Grades singlegrades(int sid, int tpid) {
		
		return dao.singlegrades(sid, tpid);
	}

}
