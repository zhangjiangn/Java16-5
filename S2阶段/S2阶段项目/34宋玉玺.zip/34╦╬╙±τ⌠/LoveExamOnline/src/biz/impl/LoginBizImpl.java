package biz.impl;

import dao.LoginDao;
import dao.impl.LoginDaoImpl;
import bean.Students;
import bean.Users;
import biz.LoginBiz;

public class LoginBizImpl implements LoginBiz {
	LoginDao dao=new LoginDaoImpl();
	public Students stuLogin(String sname,String spwd) {
		
		return dao.stuLogin(sname, spwd);
	}

	public Users userLogin(String uname,String upwd) {
		return dao.userLogin(uname, upwd);
	}

}
