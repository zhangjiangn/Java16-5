package biz.impl;

import java.util.List;

import dao.QuestionsDao;
import dao.impl.QuestionsDaoImpl;

import bean.Directions;
import bean.PageBean;
import bean.Stages;
import bean.Subjects;
import bean.Testquestions;
import biz.QuestionsBiz;

public class QuestionsBizImpl implements QuestionsBiz {
	QuestionsDao dao=new QuestionsDaoImpl();
	public List<Directions> queryDirections() {
		
		return dao.queryDirections();
	}
	
	public List<Stages> queryStages() {
		
		return dao.queryStages();
	}
	
	public List<Directions> queryDirections(int did) {
		
		return dao.queryDirections(did);
	}

	public List<Stages> queryStages(int stid) {
		
		return dao.queryStages(stid);
	}
	
	public List<Subjects> querySubjects() {
		
		return dao.querySubjects();
	}
	
	public List<Subjects> querySubjects(int did,int stid) {
		
		return dao.querySubjects(did, stid);
	}
	
	public int queryTQcount(int subid) {
		
		return dao.queryTQcount(subid);
	}
	
	

	public List<Testquestions> queryTestquestions(int subid) {
		
		return dao.queryTestquestions(subid);
	}
	
	public int addquestions(Testquestions testquestions) {
		
		return dao.addquestions(testquestions);
	}

	public int updatequestions(Testquestions testquestions,int subid) {
		
		return dao.updatequestions(testquestions,subid);
	}

	public Testquestions querytestquestions(int tqid) {
		
		return dao.querytestquestions(tqid);
	}

	public PageBean pb(int p, int subid) {
		
		return dao.pb(p, subid);
	}

}
