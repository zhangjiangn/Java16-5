package biz;

import java.util.List;

import bean.Directions;
import bean.PageBean;
import bean.Stages;
import bean.Subjects;
import bean.Testquestions;

public interface QuestionsBiz {
	public List<Directions> queryDirections();
	public List<Stages> queryStages();
	public List<Directions> queryDirections(int did);
	public List<Stages> queryStages(int stid);
	public List<Subjects> querySubjects();
	public List<Subjects> querySubjects(int did,int stid);
	public int queryTQcount(int subid);
	public List<Testquestions>queryTestquestions(int subid);
	public int addquestions(Testquestions testquestions);
	public int updatequestions(Testquestions testquestions,int subid);
	public Testquestions querytestquestions(int tqid);
	public PageBean pb(int p,int subid);
	
}
