package biz;

import java.util.List;

import bean.Grades;
import bean.PageBean;
import bean.StudentsTq;
import bean.Testpapers;
import bean.Testquestions;
import bean.TpTq;

public interface OnlineTestBiz {
	public PageBean querytestpapers(int p,int cid,String state);
	public Testpapers tp(int tpid);
	public List<TpTq> pq(int tpid);
	public Testquestions tq(int tqid);
	public int addstutq(int sid,int ssid);
	public int updatestutq(int sssid,String sanswer);
	public List<StudentsTq> stq(int tpid);
	public int addgrades(Grades grade);
}
