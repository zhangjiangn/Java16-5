package biz;

import java.util.List;

import bean.Classes;
import bean.Directions;
import bean.Grades;
import bean.PageBean;
import bean.Stages;
import bean.Subjects;

public interface ResultsBiz {
	public List<Directions> queryDirections();
	public List<Stages> queryStages();
	public List<Subjects> querySubjects(int did,int stid);
	public PageBean querytestpapers(int p,String state);
	public PageBean cquerytestpapers(int p, int subid,String topicbigtype,String state);
	public PageBean pq(int p,int tpid);
	public List<Classes> queryclasses();
	public PageBean querygrades(int p,int tpid);
	public PageBean cquerygrades(int p,int tpid,int cid);
	public PageBean ccquerygrades(int p,int tpid,int cid,String sname);
	public Grades singlegrades(int sid,int tpid);
	public PageBean querystutq(int p,int sid,int tpid);
}
