package dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import bean.Students;
import bean.Users;

public interface LoginDao {
	public Session getsSession();
	public Transaction transaction();
	public Students stuLogin(String sname,String spwd);
	public Users userLogin(String uname,String upwd);
}
