package dao.impl;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import bean.Students;
import bean.Users;
import dao.HibernateSessionFactory;
import dao.LoginDao;

public class LoginDaoImpl implements LoginDao {

	public Session getsSession() {
		return HibernateSessionFactory.getSession();
	}
	public Transaction transaction() {
		return getsSession().beginTransaction();
	}

	public Students stuLogin(String sname,String spwd) {
		String hql="select s from Students s where s.sname=? and s.spwd=?";
		Query query=getsSession().createQuery(hql);
		query.setString(0, sname);
		query.setString(1, spwd);
		
		return (Students)query.uniqueResult();
	}

	public Users userLogin(String uname,String upwd) {
		String hql="select u from Users u where u.uname=? and u.upwd=?";
		Query query=getsSession().createQuery(hql);
		query.setString(0, uname);
		query.setString(1, upwd);
		
		return (Users) query.uniqueResult();
	}

}
