package dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;

import bean.Directions;
import bean.PageBean;
import bean.Stages;
import bean.Subjects;
import bean.Testquestions;

import dao.HibernateSessionFactory;
import dao.QuestionsDao;

public class QuestionsDaoImpl implements QuestionsDao {
	public Session getSession() {
		return HibernateSessionFactory.getSession();
	}
	public Transaction transaction() {
		return getSession().beginTransaction();
	}
	
	
	public List<Directions> queryDirections() {
		Query query=getSession().createQuery("from Directions");
		return query.list();
	}
	public List<Stages> queryStages() {
		Query query=getSession().createQuery("from Stages");
		return query.list();
	}
	public List<Directions> queryDirections(int did) {
		List<Directions> list=new ArrayList<Directions>();
		switch (did) {
		case 1:
			Query query1=getSession().createQuery("from Directions");
			list=query1.list();
			break;

		default:
			Query query2=getSession().createQuery("from Directions order by did desc");
			list=query2.list();
			break;
		}
		return list;
	}
	
	public List<Stages> queryStages(int stid) {
		List<Stages> list=new ArrayList<Stages>();
		switch (stid) {
		case 1:
			Query query1=getSession().createQuery("from Stages");
			list=query1.list();
			break;

		default:
			Query query2=getSession().createQuery("from Stages order by stid desc");
			list=query2.list();
			break;
		}
		return list;
	}
	
	public List<Subjects> querySubjects() {
		String hql="select distinct sub from Subjects sub join sub.directions join sub.stages";
		Query query=getSession().createQuery(hql);
		return query.list();
	}
	public List<Subjects> querySubjects(int did,int stid) {
		String hql="select distinct sub from Subjects sub join sub.directions join sub.stages where sub.directions.did=? and sub.stages.stid=?";
		Query query=getSession().createQuery(hql);
		query.setInteger(0, did);
		query.setInteger(1, stid);
		return query.list();
	}

	public int queryTQcount(int subid) {
		String sql="select count(*) from Testquestions where subid=?";
		SQLQuery query=getSession().createSQLQuery(sql);
		query.setInteger(0, subid);
		Object o=query.uniqueResult();
		int count;
		if(o==null){
			count=0;
		}else{
			count=Integer.parseInt(o.toString());
		}
		return count;
	}
	
	public List<Testquestions> queryTestquestions(int subid) {
		String hql="select tq from Testquestions tq where tq.subjects.subid=?";
		Query query=getSession().createQuery(hql);
		query.setInteger(0, subid);
		return query.list();
	}
	
	public int addquestions(Testquestions testquestions) {
		int i=1;
		try {
			getSession().save(testquestions);
			transaction();
			transaction().commit();
		} catch (Exception e) {
			i=0;
			transaction().rollback();
		}
		getSession().close();
		return i;
	}
	
	public Testquestions querytestquestions(int tqid) {
		String hql="select tq from Testquestions tq where tq.tqid=?";
		Query query=getSession().createQuery(hql);
		query.setInteger(0, tqid);
		return (Testquestions)query.uniqueResult();
	}
	public int updatequestions(Testquestions testquestions,int subid) {
		int i=1;
		try {
			Subjects subjects=(Subjects)getSession().get(Subjects.class, subid);
			Testquestions tq=(Testquestions)getSession().get(Testquestions.class, testquestions.getTqid());
			tq.setSubjects(subjects);
			tq.setTopicbigtype(testquestions.getTopicbigtype());
			tq.setTopictype(testquestions.getTopictype());
			tq.setTqcontent(testquestions.getTqcontent());
			tq.setOptionsA(testquestions.getOptionsA());
			tq.setOptionsB(testquestions.getOptionsB());
			tq.setOptionsC(testquestions.getOptionsC());
			tq.setOptionsD(testquestions.getOptionsD());
			tq.setAnswer(testquestions.getAnswer());
			tq.setChapters(testquestions.getChapters());
			getSession().update(tq);
			transaction();
			transaction().commit();
		} catch (Exception e) {
			i=0;
			transaction().rollback();
		}	
		getSession().close();
		return i;
	}
	public PageBean pb(int p, int subid) {
		PageBean pb=new PageBean();
        try {
        	pb.setPagesize(4);
            String hql="select tq from Testquestions tq where tq.subjects.subid=?";//��ȡ��ѯ���
            Query query= getSession().createQuery(hql);//.setCacheable(true);
            query.setInteger(0, subid);
            //��ѯ��������
            int count=query.list().size();
            pb.setPagetotal(count/pb.getPagesize());
            pb.setCount(count);
            pb.setP(p);
            //ָ�����Ǹ�����ʼ��ѯ������������λ���Ǵ�0��ʼ�ģ�
            query.setFirstResult((pb.getP()-1)*pb.getPagesize());
            //��ҳʱ��һ������Ѱ�Ķ�����
            query.setMaxResults(pb.getPagesize());
            List queryTestquestions=query.list();        
            pb.setData(queryTestquestions);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return  pb;
	}

}
