package dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import bean.Grades;
import bean.PageBean;
import bean.Students;
import bean.StudentsTq;
import bean.Testpapers;
import bean.Testquestions;
import bean.TpTq;

import dao.HibernateSessionFactory;
import dao.OnlineTestDao;

public class OnlineTestDaoImpl implements OnlineTestDao {
	Session session=HibernateSessionFactory.getSession();
	
	public PageBean querytestpapers(int p,int cid,String state) {
		PageBean pb=new PageBean();
        try {
        	pb.setPagesize(4);
            String hql="select tp from Testpapers tp where tp.classes.cid=? and tp.state=?";//��ȡ��ѯ���
            Query query= session.createQuery(hql);//.setCacheable(true);
            query.setInteger(0, cid);
            query.setString(1, state);
            //��ѯ��������
            int count=query.list().size();
            pb.setPagetotal(count/pb.getPagesize());
            pb.setCount(count);
            pb.setP(p);
            //ָ�����Ǹ�����ʼ��ѯ������������λ���Ǵ�0��ʼ�ģ�
            query.setFirstResult((pb.getP()-1)*pb.getPagesize());
            //��ҳʱ��һ������Ѱ�Ķ�����
            query.setMaxResults(pb.getPagesize());
            List queryTestpapers=query.list();        
            pb.setData(queryTestpapers);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return  pb;
	}
	public Testpapers tp(int tpid){
		String hql="select tp from Testpapers tp where tp.tpid=?";
		Query query=session.createQuery(hql);
		query.setInteger(0, tpid);
		
		return (Testpapers)query.uniqueResult();
	}
	public List<TpTq> pq(int tpid){
		String hql="select pq from TpTq pq where pq.testpapers.tpid=?";
		Query query=session.createQuery(hql);
		query.setInteger(0, tpid);
		
		return query.list();
	}
	public Testquestions tq(int tqid){
		String hql="select tq from Testquestions tq where tq.tqid=?";
		Query query=session.createQuery(hql);
		query.setInteger(0, tqid);
		
		return (Testquestions)query.uniqueResult();
	}
	public int addstutq(int sid,int ssid){
		int i=1;
		Transaction transaction=session.beginTransaction();
		try {
			StudentsTq stp=new StudentsTq();
 			Students stu=(Students)session.get(Students.class, sid);
			TpTq pq=(TpTq)session.get(TpTq.class, ssid);
			stp.setStudents(stu);
			stp.setTpTq(pq);
			session.save(stp);
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			i=0;
			
		}
		return i;
	}
	public int updatestutq(int sssid,String sanswer){
		int i=1;
		Transaction transaction=session.beginTransaction();
		try {
			StudentsTq stp=(StudentsTq)session.get(StudentsTq.class, sssid);
			stp.setSanswer(sanswer);
			session.update(stp);
			transaction.commit();
		} catch (Exception e) {
			i=0;
		}
		return i;
	}
	public List<StudentsTq> stq(int tpid){
		String hql="select stq from StudentsTq stq where stq.tpTq.testpapers.tpid=? order by newid()";
		Query query=session.createQuery(hql);
		query.setInteger(0, tpid);
		
		return query.list();
		
	}
	public int addgrades(Grades grade){
		int i=1;
		Transaction transaction=session.beginTransaction();
		try {
			session.save(grade);
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			i=0;
			
		}
		return i;
	}
}
