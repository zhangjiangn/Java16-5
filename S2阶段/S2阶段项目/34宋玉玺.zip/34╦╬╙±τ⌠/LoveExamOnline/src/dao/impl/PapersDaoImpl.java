package dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;

import bean.Classes;
import bean.Directions;
import bean.PageBean;
import bean.Stages;
import bean.Subjects;
import bean.Testpapers;
import bean.Testquestions;
import bean.TpTq;

import dao.HibernateSessionFactory;
import dao.PapersDao;

public class PapersDaoImpl implements PapersDao {

	public Session getSession() {
		return HibernateSessionFactory.getSession();
	}
	public Transaction transaction() {
		return getSession().beginTransaction();
	}
	
	public List<Directions> queryDirections() {
		Query query=getSession().createQuery("from Directions");
		return query.list();
	}
	public List<Stages> queryStages() {
		Query query=getSession().createQuery("from Stages");
		return query.list();
	}
	
	public List<Subjects> querySubjects(int did,int stid) {
		String hql="select distinct sub from Subjects sub join sub.directions join sub.stages where sub.directions.did=? and sub.stages.stid=?";
		Query query=getSession().createQuery(hql);
		query.setInteger(0, did);
		query.setInteger(1, stid);
		return query.list();
	}
	public PageBean showpapersall(int p) {
		PageBean pb=new PageBean();
        try {
        	pb.setPagesize(6);
            String hql="select tp from Testpapers tp";//��ȡ��ѯ���
            Query query= getSession().createQuery(hql);//.setCacheable(true);
            //��ѯ��������
            int count=query.list().size();
            pb.setPagetotal(count/pb.getPagesize());
            pb.setCount(count);
            pb.setP(p);
            //ָ�����Ǹ�����ʼ��ѯ������������λ���Ǵ�0��ʼ�ģ�
            query.setFirstResult((pb.getP()-1)*pb.getPagesize());
            //��ҳʱ��һ������Ѱ�Ķ�����
            query.setMaxResults(pb.getPagesize());
            List queryTestpapers=query.list();        
            pb.setData(queryTestpapers);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return  pb;
	}
	public PageBean showpapers(int p, int subid,String topicbigtype,String state) {
		PageBean pb=new PageBean();
        try {
        	pb.setPagesize(6);
            String hql="select tp from Testpapers tp where tp.subjects.subid=? and tp.topicbigtype=? and tp.state=?";//��ȡ��ѯ���
            Query query= getSession().createQuery(hql);//.setCacheable(true);
            query.setInteger(0, subid);
            query.setString(1, topicbigtype);
            query.setString(2, state);
            //��ѯ��������
            int count=query.list().size();
            pb.setPagetotal(count/pb.getPagesize());
            pb.setCount(count);
            pb.setP(p);
            //ָ�����Ǹ�����ʼ��ѯ������������λ���Ǵ�0��ʼ�ģ�
            query.setFirstResult((pb.getP()-1)*pb.getPagesize());
            //��ҳʱ��һ������Ѱ�Ķ�����
            query.setMaxResults(pb.getPagesize());
            List queryTestpapers=query.list();        
            pb.setData(queryTestpapers);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return  pb;
	}

	public PageBean queryTestquestions(int p, int subid) {
		PageBean pb=new PageBean();
        try {
        	pb.setPagesize(100);
            String hql="select tq from Testquestions tq where tq.subjects.subid=?";//��ȡ��ѯ���
            Query query= getSession().createQuery(hql);//.setCacheable(true);
            query.setInteger(0, subid);
            //��ѯ��������
            int count=query.list().size();
            pb.setPagetotal(count/pb.getPagesize());
            pb.setCount(count);
            pb.setP(p);
            //ָ�����Ǹ�����ʼ��ѯ������������λ���Ǵ�0��ʼ�ģ�
            query.setFirstResult((pb.getP()-1)*pb.getPagesize());
            //��ҳʱ��һ������Ѱ�Ķ�����
            query.setMaxResults(pb.getPagesize());
            List queryTestquestions=query.list();        
            pb.setData(queryTestquestions);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return  pb;
	}
	
	public int addpapers(Testpapers testpapers) {
		int i=1;
		try {
			getSession().save(testpapers);
			transaction();
			transaction().commit();
		} catch (Exception e) {
			i=0;
			transaction().rollback();
		}
		getSession().close();
		return i;
	}
	public int addtp_tq(Testpapers tp,int tqid) {
		int i=1;
		try {
			TpTq pq=new TpTq();
			Testquestions tq=(Testquestions) getSession().get(Testquestions.class, tqid);
			pq.setTestpapers(tp);
			pq.setTestquestions(tq);
			getSession().save(pq);
			transaction();
			transaction().commit();
		} catch (Exception e) {
			i=0;
			transaction().rollback();
		}
		getSession().close();
		return i;
	}
	public PageBean pq(int p,int tpid){
		PageBean pb=new PageBean();
        try {
        	pb.setPagesize(1);
            String hql="select pq from TpTq pq where pq.testpapers.tpid=?";//��ȡ��ѯ���
            Query query= getSession().createQuery(hql);//.setCacheable(true);
            query.setInteger(0, tpid);
            //��ѯ��������
            int count=query.list().size();
            pb.setPagetotal(count/pb.getPagesize());
            pb.setCount(count);
            pb.setP(p);
            //ָ�����Ǹ�����ʼ��ѯ������������λ���Ǵ�0��ʼ�ģ�
            query.setFirstResult((pb.getP()-1)*pb.getPagesize());
            //��ҳʱ��һ������Ѱ�Ķ�����
            query.setMaxResults(pb.getPagesize());
            List pq=query.list();        
            pb.setData(pq);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return  pb;
	}
	public int beginexam(int tpid, int cid,Testpapers tp) {
		int i=1;
		try {
			Testpapers tp2=(Testpapers) getSession().get(Testpapers.class, tpid);
			Classes c=(Classes) getSession().get(Classes.class, cid);
			tp2.setClasses(c);
			tp2.setState("������");
			tp2.setStarttime(tp.getStarttime());
			getSession().update(tp2);
			transaction();
			transaction().commit();
			
		} catch (Exception e) {
			i=0;
		}
		getSession().close();
		return i;
	}
	public List<Classes> queryclasses() {
		Query query=getSession().createQuery("from Classes");
		return query.list();
	}
	public int endexam(int tpid) {
		int i=1;
		try {
			Testpapers tp=(Testpapers) getSession().get(Testpapers.class, tpid);
			tp.setState("���Խ���");
			getSession().update(tp);
			transaction();
			transaction().commit();
		} catch (Exception e) {
			i=0;
		}
		getSession().close();
		return i;
	}
	public int randomaddpapers(int subid,int tpid,int number,String topictype,String difficulty){
		int i=1;
		try {
			String sql="select top "+number+" tqid from testquestions where topictype=? and difficulty=? and subid=? order by newid()";
			Query query=getSession().createSQLQuery(sql);
			query.setString(0, topictype);
			query.setString(1, difficulty);
			query.setInteger(2, subid);
			for (Object o : query.list()) {
				TpTq pq=new TpTq();
				Testpapers tp=(Testpapers) getSession().get(Testpapers.class, tpid);
				Testquestions tq=(Testquestions) getSession().get(Testquestions.class, Integer.parseInt(o.toString()));
				pq.setTestpapers(tp);
				pq.setTestquestions(tq);
				getSession().save(pq);
				transaction();
				transaction().commit();
			}
		} catch (Exception e) {
			i=0;
			transaction().rollback();
		}
		getSession().close();
		return i;
	}
	
}	
