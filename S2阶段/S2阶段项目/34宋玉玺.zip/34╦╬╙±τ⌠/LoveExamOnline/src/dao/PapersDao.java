package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import bean.Classes;
import bean.Directions;
import bean.PageBean;
import bean.Stages;
import bean.Subjects;
import bean.Testpapers;
import bean.TpTq;

public interface PapersDao {
	public Session getSession();
	public Transaction transaction();
	
	public List<Directions> queryDirections();
	public List<Stages> queryStages();
	public List<Subjects> querySubjects(int did,int stid);
	public PageBean showpapersall(int p);
	public PageBean showpapers(int p,int subid,String topicbigtype,String state);
	public PageBean queryTestquestions(int p,int subid);
	public int addpapers(Testpapers testpapers);
	public int addtp_tq(Testpapers tp,int tqid);
	public PageBean pq(int p,int tpid);
	public List<Classes> queryclasses();
	public int beginexam(int tpid,int cid,Testpapers tp);
	public int endexam(int tpid);
	public int randomaddpapers(int subid,int tpid,int number,String topictype,String difficulty);
	
}
