package action;

import java.util.List;

import bean.Directions;
import bean.Grades;
import bean.PageBean;
import bean.Stages;
import biz.ResultsBiz;
import biz.impl.ResultsBizImpl;

public class ResultsAction {
	private List queryDirections;
	private List queryStages;
	private List querySubjects;
	private int did;
	private int stid;
	private int one;
	private int p;
	private int subid;
	private String topicbigtype;
	private PageBean querytestpapers;
	
	private PageBean pq;
	private int tpid;
	private String subname;
	private String spheadings;
	
	private List queryclasses;
	private int cid;
	private String sname;
	private PageBean querygrades;
	
	private int sid;
	private Grades singlegrades;
	private PageBean querystutq;
	
	private ResultsBiz dao=new ResultsBizImpl();
	
	public String querytestpapers(){
		queryDirections=dao.queryDirections();
		queryStages=dao.queryStages();
		querySubjects=dao.querySubjects(did, stid);
		querytestpapers=dao.querytestpapers(p, "������");
		return "showtestpapers";
		
	}
	public String cquerytestpapers(){
		queryDirections=dao.queryDirections();
		queryStages=dao.queryStages();
		querySubjects=dao.querySubjects(did, stid);
		querytestpapers=dao.cquerytestpapers(p, subid, topicbigtype, "������");
		return "showtestpapers";
		
	}
	public String toviewpapers(){
		pq=dao.pq(p, tpid);
		return "toview";
		
	}
	
	public String viewresults(){
		queryclasses=dao.queryclasses();
		System.out.println(sname);
		if(cid>0&&sname.equals("")){
			one=2;
			querygrades=dao.cquerygrades(p, tpid, cid);
		}else if(cid>0&&!sname.equals("")){
			one=2;
			querygrades=dao.ccquerygrades(p, tpid, cid, sname);
		}else{
			one=1;
			querygrades=dao.querygrades(p, tpid);
		}
		return "viewresults";
		
	} 
	public String checkthedetails(){
		singlegrades=dao.singlegrades(sid, tpid);
		querystutq=dao.querystutq(p, sid, tpid);
		return "checkthedetails";
		
	}
	public List getQueryDirections() {
		return queryDirections;
	}
	public void setQueryDirections(List queryDirections) {
		this.queryDirections = queryDirections;
	}
	public List getQueryStages() {
		return queryStages;
	}
	public void setQueryStages(List queryStages) {
		this.queryStages = queryStages;
	}
	public List getQuerySubjects() {
		return querySubjects;
	}
	public void setQuerySubjects(List querySubjects) {
		this.querySubjects = querySubjects;
	}
	public int getDid() {
		return did;
	}
	public void setDid(int did) {
		this.did = did;
	}
	public int getStid() {
		return stid;
	}
	public void setStid(int stid) {
		this.stid = stid;
	}
	public int getOne() {
		return one;
	}
	public void setOne(int one) {
		this.one = one;
	}
	public int getP() {
		return p;
	}
	public void setP(int p) {
		this.p = p;
	}
	public int getSubid() {
		return subid;
	}
	public void setSubid(int subid) {
		this.subid = subid;
	}
	public String getTopicbigtype() {
		return topicbigtype;
	}
	public void setTopicbigtype(String topicbigtype) {
		this.topicbigtype = topicbigtype;
	}
	public PageBean getQuerytestpapers() {
		return querytestpapers;
	}
	public void setQuerytestpapers(PageBean querytestpapers) {
		this.querytestpapers = querytestpapers;
	}
	public ResultsBiz getDao() {
		return dao;
	}
	public void setDao(ResultsBiz dao) {
		this.dao = dao;
	}
	public PageBean getPq() {
		return pq;
	}
	public void setPq(PageBean pq) {
		this.pq = pq;
	}
	public int getTpid() {
		return tpid;
	}
	public void setTpid(int tpid) {
		this.tpid = tpid;
	}
	public String getSubname() {
		return subname;
	}
	public void setSubname(String subname) {
		this.subname = subname;
	}
	public String getSpheadings() {
		return spheadings;
	}
	public void setSpheadings(String spheadings) {
		this.spheadings = spheadings;
	}
	public List getQueryclasses() {
		return queryclasses;
	}
	public void setQueryclasses(List queryclasses) {
		this.queryclasses = queryclasses;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public PageBean getQuerygrades() {
		return querygrades;
	}
	public void setQuerygrades(PageBean querygrades) {
		this.querygrades = querygrades;
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public Grades getSinglegrades() {
		return singlegrades;
	}
	public void setSinglegrades(Grades singlegrades) {
		this.singlegrades = singlegrades;
	}
	public PageBean getQuerystutq() {
		return querystutq;
	}
	public void setQuerystutq(PageBean querystutq) {
		this.querystutq = querystutq;
	}
	
	
	
	
}
