package action;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.sun.org.apache.bcel.internal.generic.NEW;

import bean.PageBean;
import bean.Subjects;
import bean.Testquestions;
import biz.QuestionsBiz;
import biz.impl.QuestionsBizImpl;

public class QuestionsAction {
	private List queryDirections;
	private List queryStages;
	private List<Subjects> querySubjects1;
	private List<Subjects> querySubjects=new ArrayList<Subjects>();
	private int did;
	private int stid;
	private int subid;
	private String subname;
	private int addquestions;
	private List<Testquestions> queryTestquestions;
	private Testquestions testquestions;
	private int tqid;
	private int updatequestions;
	private int p;
	private PageBean pb;
	//�ļ���
	private String name;
	//�ϴ��ļ��ؼ�����
	private File uploadfile;
	//�ϴ��ļ�����=�ϴ��ļ��ؼ�����+FileName
	private String uploadfileFileName;
	//�ϴ��ļ�����=�ϴ��ļ��ؼ�����+ContentType
	private String uploadfileContentType;
	//�����صķ������Դ��
	private String downfilename;
	//��ȡ������Դ���ݵ���
	private InputStream downfileis;
	
	private QuestionsBiz dao=new QuestionsBizImpl();
	
	public String classification(){
		queryDirections=dao.queryDirections();
		queryStages=dao.queryStages();
		querySubjects1=dao.querySubjects();
		for (Subjects sub : querySubjects1) {
			int count=dao.queryTQcount(sub.getSubid());
			sub.setCount(count);
			querySubjects.add(sub);
		}
		return "classification";
		
	}
	public String onchangeshow(){
		queryDirections=dao.queryDirections();
		queryStages=dao.queryStages();
		querySubjects1=dao.querySubjects(did, stid);
		for (Subjects sub : querySubjects1) {
			int count=dao.queryTQcount(sub.getSubid());
			sub.setCount(count);
			querySubjects.add(sub);
		}
		return "classification";	
	}
	
	public String showquestions(){
		pb=dao.pb(p, subid);
//		queryTestquestions=dao.queryTestquestions(subid);
		return "showquestions";	
	}
	
	public String addquestions(){
		addquestions=dao.addquestions(testquestions);
		return "addsuccess";
	}
	public String turnupdate(){	
		testquestions=dao.querytestquestions(tqid);	
		return "turnupdate";
		
	}
	public String updatequestions(){
		updatequestions=dao.updatequestions(testquestions,subid);
		return "updatesuccess";
		
	}
	public String upload(){
		try {
			InputStream is=new FileInputStream(uploadfile);
			String filepath=ServletActionContext.getServletContext().getRealPath("/")+
			"upload/"+uploadfileFileName;
			OutputStream os=new FileOutputStream(filepath);
			
			byte[] buffer=new byte[8096];
			int len=0;
			while ((len=is.read(buffer))!=-1) {
				os.write(buffer,0,len);			
			}
//			System.out.println(uploadfileFileName);
//			System.out.println(subid);
//			System.out.println(subname);
//			System.out.println(p);
			HttpSession session=ServletActionContext.getRequest().getSession();
			session.setAttribute("uploadfileFileName", uploadfileFileName);
			return "upload";
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
			
	}
public String download(){
		try {
			String filepath=ServletActionContext.getServletContext().getRealPath("/")+
			"upload/"+downfilename;
			downfileis=new FileInputStream(filepath);
			return "download";
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}
	
	
	public List getQueryDirections() {
		return queryDirections;
	}
	public void setQueryDirections(List queryDirections) {
		this.queryDirections = queryDirections;
	}
	public List getQueryStages() {
		return queryStages;
	}
	public void setQueryStages(List queryStages) {
		this.queryStages = queryStages;
	}
	public List<Subjects> getQuerySubjects1() {
		return querySubjects1;
	}
	public void setQuerySubjects1(List<Subjects> querySubjects1) {
		this.querySubjects1 = querySubjects1;
	}
	public List<Subjects> getQuerySubjects() {
		return querySubjects;
	}
	public void setQuerySubjects(List<Subjects> querySubjects) {
		this.querySubjects = querySubjects;
	}
	public int getDid() {
		return did;
	}
	public void setDid(int did) {
		this.did = did;
	}
	public int getStid() {
		return stid;
	}
	public void setStid(int stid) {
		this.stid = stid;
	}
	public int getSubid() {
		return subid;
	}
	public void setSubid(int subid) {
		this.subid = subid;
	}
	public List<Testquestions> getQueryTestquestions() {
		return queryTestquestions;
	}
	public void setQueryTestquestions(List<Testquestions> queryTestquestions) {
		this.queryTestquestions = queryTestquestions;
	}
	public QuestionsBiz getDao() {
		return dao;
	}
	public void setDao(QuestionsBiz dao) {
		this.dao = dao;
	}
	public String getSubname() {
		return subname;
	}
	public void setSubname(String subname) {
		this.subname = subname;
	}
	public Testquestions getTestquestions() {
		return testquestions;
	}
	public void setTestquestions(Testquestions testquestions) {
		this.testquestions = testquestions;
	}
	public int getTqid() {
		return tqid;
	}
	public void setTqid(int tqid) {
		this.tqid = tqid;
	}
	public int getAddquestions() {
		return addquestions;
	}
	public void setAddquestions(int addquestions) {
		this.addquestions = addquestions;
	}
	public int getUpdatequestions() {
		return updatequestions;
	}
	public void setUpdatequestions(int updatequestions) {
		this.updatequestions = updatequestions;
	}
	public int getP() {
		return p;
	}
	public void setP(int p) {
		this.p = p;
	}
	public PageBean getPb() {
		return pb;
	}
	public void setPb(PageBean pb) {
		this.pb = pb;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public File getUploadfile() {
		return uploadfile;
	}
	public void setUploadfile(File uploadfile) {
		this.uploadfile = uploadfile;
	}
	public String getUploadfileFileName() {
		return uploadfileFileName;
	}
	public void setUploadfileFileName(String uploadfileFileName) {
		this.uploadfileFileName = uploadfileFileName;
	}
	public String getUploadfileContentType() {
		return uploadfileContentType;
	}
	public void setUploadfileContentType(String uploadfileContentType) {
		this.uploadfileContentType = uploadfileContentType;
	}
	public String getDownfilename() {
		return downfilename;
	}
	public void setDownfilename(String downfilename) {
		this.downfilename = downfilename;
	}
	public InputStream getDownfileis() {
		return downfileis;
	}
	public void setDownfileis(InputStream downfileis) {
		this.downfileis = downfileis;
	}
	

	
	
}
