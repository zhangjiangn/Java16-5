package action;

import java.text.SimpleDateFormat;
import java.util.Date;

public class z {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date date=new Date();
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String endtime=sdf.format(date);
		System.out.println(endtime);
	}

}
