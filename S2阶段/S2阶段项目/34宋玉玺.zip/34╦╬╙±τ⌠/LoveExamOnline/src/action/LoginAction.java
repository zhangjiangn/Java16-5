package action;


import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import bean.Students;
import bean.Users;
import biz.LoginBiz;
import biz.impl.LoginBizImpl;



public class LoginAction {
	private String name;
	private String pwd;
	private int role;
	private Users user;
	private Students stu;
	private LoginBiz dao=new LoginBizImpl();
	
	public String login(){
		HttpSession session=ServletActionContext.getRequest().getSession();
		session.setAttribute("role", role);
		if(role==1){
			stu=dao.stuLogin(name, pwd);
			if(stu!=null){
				session.setAttribute("stu", stu);
				return "index";
			}else{
				return "login";
			}
		}else{
			user=dao.userLogin(name, pwd);
			if(user!=null){
				session.setAttribute("user", user);
				return "index";
			}else{
				return "login";
			}
		}
		
	}
//	public String backlogin(){
//		HttpSession session=ServletActionContext.getRequest().getSession();
//		int role=(Integer) session.getAttribute("role");
//		if(role==1){
//			session.removeAttribute("stu");
//		}else{
//			session.removeAttribute("user");
//		}
//		return "login";
//		
//	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public int getRole() {
		return role;
	}

	public void setRole(int role) {
		this.role = role;
	}

	public Users getUser() {
		return user;
	}

	public void setUser(Users user) {
		this.user = user;
	}

	public Students getStu() {
		return stu;
	}

	public void setStu(Students stu) {
		this.stu = stu;
	}

	public LoginBiz getDao() {
		return dao;
	}

	public void setDao(LoginBiz dao) {
		this.dao = dao;
	}
	
}
