package action;

import java.util.Iterator;
import java.util.List;

import bean.PageBean;
import bean.Subjects;
import bean.Testpapers;
import biz.PapersBiz;
import biz.QuestionsBiz;
import biz.impl.PapersBizImpl;
import biz.impl.QuestionsBizImpl;

public class PapersAction {
	private List queryDirections;
	private List queryStages;
	private List querySubjects;
	private int did;
	private int stid;
	private int one;
	private int p;
	private int subid;
	private String topicbigtype;
	private String state;
	private PageBean showpapers;
	private PageBean queryTestquestions;
	
	private Testpapers tp;
	private List tqchoose;
	private int judge;
	
	private PageBean pq;
	private int tpid;
	private String subname;
	private String spheadings;
	
	private List queryclasses;
	private int cid;
	private int beginexam;
	
	private int endexam;
	
	private int simple1;
	private int general1;
	private int difficult1;
	private int simple2;
	private int general2;
	private int difficult2;
	
	
	private PapersBiz dao=new PapersBizImpl();
	
	public String showpapersone(){
		queryDirections=dao.queryDirections();
		queryStages=dao.queryStages();
		querySubjects=dao.querySubjects(did, stid);
		showpapers=dao.showpapersall(p);
		return "showpapers";
		
	}
	public String showpapers(){
		queryDirections=dao.queryDirections();
		queryStages=dao.queryStages();
		querySubjects=dao.querySubjects(did, stid);
		showpapers=dao.showpapers(p, subid, topicbigtype, state);
		return "showpapers";
		
	}
	
	public String onchangeaddpapers(){
		queryDirections=dao.queryDirections();
		queryStages=dao.queryStages();
		querySubjects=dao.querySubjects(did, stid);
		Subjects subjects=(Subjects)querySubjects.get(0);
		subid=subjects.getSubid();
		queryTestquestions=dao.queryTestquestions(p, subid);
		return "turnaddpapers";
		
	}
	public String turnaddpapers(){
		queryDirections=dao.queryDirections();
		queryStages=dao.queryStages();
		querySubjects=dao.querySubjects(did, stid);
		queryTestquestions=dao.queryTestquestions(p, subid);
		return "turnaddpapers";
		
	}
	public String addpapers(){
		Subjects subjects=new Subjects();
		subjects.setSubid(subid);
		tp.setSubjects(subjects);
		if(tqchoose!=null){
			int i=dao.addpapers(tp);
			for (Object o : tqchoose) {
				int tqid=Integer.parseInt(o.toString());
				int j=dao.addtp_tq(tp,tqid);
			}
			judge=666;
		}
		return "addsuccess";
	}
	
	public String toviewpapers(){
		pq=dao.pq(p, tpid);
		return "toview";
		
	}
	 
	public String turnbeginexam(){
		queryclasses=dao.queryclasses();
		return "beginexam";
		
	}
	public String beginexam(){
		if(cid!=0){
			beginexam=dao.beginexam(tpid, cid,tp);
		}
		return "beginexamsuccess";
		
	}	
	
	public String endexam(){
		endexam=dao.endexam(tpid);
		return "endexamsuccess";
		
	}
	
	public String turnrandompapers(){
		queryDirections=dao.queryDirections();
		queryStages=dao.queryStages();
		querySubjects=dao.querySubjects(did, stid);
		
		return "turnrandompapers";
		
	}
	public String randompapers(){
		Subjects subjects=new Subjects();
		subjects.setSubid(subid);
		tp.setSubjects(subjects);
		
		int i=dao.addpapers(tp);
		if(i!=0){
			dao.randomaddpapers(subid,tp.getTpid(), simple1, "��ѡ", "��");
			dao.randomaddpapers(subid,tp.getTpid(), general1, "��ѡ", "һ��");
			dao.randomaddpapers(subid,tp.getTpid(), difficult1, "��ѡ", "����");
			dao.randomaddpapers(subid,tp.getTpid(), simple2, "��ѡ", "��");
			dao.randomaddpapers(subid,tp.getTpid(), general2, "��ѡ", "һ��");
			dao.randomaddpapers(subid,tp.getTpid(), difficult2, "��ѡ", "����");
			judge=666;
		}
		return "addsuccess";
		
	}
	
	
	public List getQueryDirections() {
		return queryDirections;
	}

	public void setQueryDirections(List queryDirections) {
		this.queryDirections = queryDirections;
	}

	public List getQueryStages() {
		return queryStages;
	}

	public void setQueryStages(List queryStages) {
		this.queryStages = queryStages;
	}

	public List getQuerySubjects() {
		return querySubjects;
	}

	public void setQuerySubjects(List querySubjects) {
		this.querySubjects = querySubjects;
	}

	public int getDid() {
		return did;
	}

	public void setDid(int did) {
		this.did = did;
	}

	public int getStid() {
		return stid;
	}

	public void setStid(int stid) {
		this.stid = stid;
	}

	public PageBean getShowpapers() {
		return showpapers;
	}

	public void setShowpapers(PageBean showpapers) {
		this.showpapers = showpapers;
	}

	public PapersBiz getDao() {
		return dao;
	}

	public void setDao(PapersBiz dao) {
		this.dao = dao;
	}

	public int getP() {
		return p;
	}

	public void setP(int p) {
		this.p = p;
	}

	public int getSubid() {
		return subid;
	}

	public void setSubid(int subid) {
		this.subid = subid;
	}

	public String getTopicbigtype() {
		return topicbigtype;
	}

	public void setTopicbigtype(String topicbigtype) {
		this.topicbigtype = topicbigtype;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	public int getOne() {
		return one;
	}
	public void setOne(int one) {
		this.one = one;
	}
	public PageBean getQueryTestquestions() {
		return queryTestquestions;
	}
	public void setQueryTestquestions(PageBean queryTestquestions) {
		this.queryTestquestions = queryTestquestions;
	}
	public Testpapers getTp() {
		return tp;
	}
	public void setTp(Testpapers tp) {
		this.tp = tp;
	}
	public List getTqchoose() {
		return tqchoose;
	}
	public void setTqchoose(List tqchoose) {
		this.tqchoose = tqchoose;
	}
	public int getJudge() {
		return judge;
	}
	public void setJudge(int judge) {
		this.judge = judge;
	}
	public PageBean getPq() {
		return pq;
	}
	public void setPq(PageBean pq) {
		this.pq = pq;
	}
	public int getTpid() {
		return tpid;
	}
	public void setTpid(int tpid) {
		this.tpid = tpid;
	}
	public String getSubname() {
		return subname;
	}
	public void setSubname(String subname) {
		this.subname = subname;
	}
	public String getSpheadings() {
		return spheadings;
	}
	public void setSpheadings(String spheadings) {
		this.spheadings = spheadings;
	}
	public List getQueryclasses() {
		return queryclasses;
	}
	public void setQueryclasses(List queryclasses) {
		this.queryclasses = queryclasses;
	}
	public int getBeginexam() {
		return beginexam;
	}
	public void setBeginexam(int beginexam) {
		this.beginexam = beginexam;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public int getEndexam() {
		return endexam;
	}
	public void setEndexam(int endexam) {
		this.endexam = endexam;
	}
	public int getSimple1() {
		return simple1;
	}
	public void setSimple1(int simple1) {
		this.simple1 = simple1;
	}
	public int getGeneral1() {
		return general1;
	}
	public void setGeneral1(int general1) {
		this.general1 = general1;
	}
	public int getDifficult1() {
		return difficult1;
	}
	public void setDifficult1(int difficult1) {
		this.difficult1 = difficult1;
	}
	public int getSimple2() {
		return simple2;
	}
	public void setSimple2(int simple2) {
		this.simple2 = simple2;
	}
	public int getGeneral2() {
		return general2;
	}
	public void setGeneral2(int general2) {
		this.general2 = general2;
	}
	public int getDifficult2() {
		return difficult2;
	}
	public void setDifficult2(int difficult2) {
		this.difficult2 = difficult2;
	}
	
	
	
	
	
}
