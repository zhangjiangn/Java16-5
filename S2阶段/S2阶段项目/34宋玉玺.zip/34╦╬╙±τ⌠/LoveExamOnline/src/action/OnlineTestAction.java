package action;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;

import dao.HibernateSessionFactory;

import bean.Grades;
import bean.PageBean;
import bean.Students;
import bean.StudentsTq;
import bean.Testpapers;
import bean.Testquestions;
import bean.TpTq;
import biz.OnlineTestBiz;
import biz.impl.OnlineTestBizImpl;

public class OnlineTestAction {
	private PageBean querytestpapers;
	private int p;
	private int tpid;
	private Testpapers tp;
	private List<TpTq> pq;
	private Testquestions tq;
	private int tqid;
	private int	a;
	private String sanswer;
	private String option;
	private String options;
	private List<StudentsTq> stutq;
	private int	math;
	private int	totalscore;
	
	private OnlineTestBiz dao=new OnlineTestBizImpl();
	
	public String onlinetestpapers(){
		HttpSession session=ServletActionContext.getRequest().getSession();
		Students stu= (Students) session.getAttribute("stu");
		querytestpapers=dao.querytestpapers(p, stu.getClasses().getCid(), "������");
		
		return "onlinetest";
	}
	public String begintest(){
		if(a==0){
			a=1;
		}
		tp=dao.tp(tpid);
		pq=dao.pq(tpid);
		stutq=dao.stq(tpid);
		System.out.println(tpid);
		System.out.println(stutq.size());
		HttpSession session=ServletActionContext.getRequest().getSession();
		Students stu= (Students) session.getAttribute("stu");
		if(stutq.size()==0){
			for(TpTq tt : pq) {
				dao.addstutq(stu.getSid(), tt.getSsid());	
			}
		}
		stutq=dao.stq(tpid);
		tq=stutq.get(a-1).getTpTq().getTestquestions();
		session.setAttribute("stq", stutq);
		return "begintest";
	
	}
	public String clicktq(){
		HttpSession session=ServletActionContext.getRequest().getSession();
		List<StudentsTq> stq=(List<StudentsTq>) session.getAttribute("stq");
		tp=dao.tp(tpid);
		if(a==0){
			a=1;
		}else if(a>stq.size()){
			a=stq.size();
		}
		tq=stq.get(a-1).getTpTq().getTestquestions();
		return "begintest";	
	}
	public String intestsingle(){
		HttpSession session=ServletActionContext.getRequest().getSession();
		List<StudentsTq> stq=(List<StudentsTq>) session.getAttribute("stq");
		tp=dao.tp(tpid);
		tq=stq.get(a-1).getTpTq().getTestquestions();
		sanswer=option;
		dao.updatestutq(stq.get(a-1).getSssid(), sanswer);
		return "begintest";
		
	}
	public String intestdouble(){
		HttpSession session=ServletActionContext.getRequest().getSession();
		List<StudentsTq> stq=(List<StudentsTq>) session.getAttribute("stq");
		tp=dao.tp(tpid);
		tq=stq.get(a-1).getTpTq().getTestquestions();
		sanswer=options;
		dao.updatestutq(stq.get(a-1).getSssid(), sanswer);
		return "begintest";
		
	}
	public String overtest(){
		HttpSession session=ServletActionContext.getRequest().getSession();
		Students stu= (Students) session.getAttribute("stu");
		List<StudentsTq> stq=(List<StudentsTq>) session.getAttribute("stq");
		tp=dao.tp(tpid);
		math=0;totalscore=0;
		for (StudentsTq one : stq) {
			if(one.getSanswer()!=null){
				if(one.getSanswer().equals(one.getTpTq().getTestquestions().getAnswer())){
					math=math+1;
					totalscore=totalscore+Integer.parseInt(one.getTpTq().getTestpapers().getEachscore().toString());
				}
			}
			
		}
		Session sessions=HibernateSessionFactory.getSession();
		Grades grade=new Grades();
		Students students=(Students) sessions.get(Students.class, stu.getSid());
		Testpapers testpapers=(Testpapers) sessions.get(Testpapers.class, tpid);
		grade.setStudents(students);
		grade.setTestpapers(testpapers);
		grade.setStarttime(tp.getStarttime());
		Date date=new Date();
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String endtime=sdf.format(date);
		System.out.println(endtime);
		grade.setEndtime(endtime);
		grade.setGrade(Integer.toString(totalscore));
		System.out.println("��ȷ����"+math);
		System.out.println("�÷֣�"+totalscore);
		dao.addgrades(grade);
		return "overtest";
		
	}
	public PageBean getQuerytestpapers() {
		return querytestpapers;
	}

	public void setQuerytestpapers(PageBean querytestpapers) {
		this.querytestpapers = querytestpapers;
	}

	public int getP() {
		return p;
	}

	public void setP(int p) {
		this.p = p;
	}

	public OnlineTestBiz getDao() {
		return dao;
	}

	public void setDao(OnlineTestBiz dao) {
		this.dao = dao;
	}
	public int getTpid() {
		return tpid;
	}
	public void setTpid(int tpid) {
		this.tpid = tpid;
	}
	public Testpapers getTp() {
		return tp;
	}
	public void setTp(Testpapers tp) {
		this.tp = tp;
	}
	public List<TpTq> getPq() {
		return pq;
	}
	public void setPq(List<TpTq> pq) {
		this.pq = pq;
	}
	public Testquestions getTq() {
		return tq;
	}
	public void setTq(Testquestions tq) {
		this.tq = tq;
	}
	public int getTqid() {
		return tqid;
	}
	public void setTqid(int tqid) {
		this.tqid = tqid;
	}
	public int getA() {
		return a;
	}
	public void setA(int a) {
		this.a = a;
	}
	public String getSanswer() {
		return sanswer;
	}
	public void setSanswer(String sanswer) {
		this.sanswer = sanswer;
	}
	public String getOption() {
		return option;
	}
	public void setOption(String option) {
		this.option = option;
	}
	public List<StudentsTq> getStutq() {
		return stutq;
	}
	public void setStutq(List<StudentsTq> stutq) {
		this.stutq = stutq;
	}
	public String getOptions() {
		return options;
	}
	public void setOptions(String options) {
		this.options = options;
	}
	public int getMath() {
		return math;
	}
	public void setMath(int math) {
		this.math = math;
	}
	public int getTotalscore() {
		return totalscore;
	}
	public void setTotalscore(int totalscore) {
		this.totalscore = totalscore;
	}


	
	
	
	
}
