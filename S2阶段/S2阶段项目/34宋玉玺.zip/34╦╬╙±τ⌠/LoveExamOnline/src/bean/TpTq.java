package bean;

import java.util.HashSet;
import java.util.Set;

/**
 * TpTq entity. @author MyEclipse Persistence Tools
 */

public class TpTq implements java.io.Serializable {

	// Fields

	private Integer ssid;
	private Testpapers testpapers;
	private Testquestions testquestions;
	private Set studentsTqs = new HashSet(0);

	// Constructors

	/** default constructor */
	public TpTq() {
	}

	/** minimal constructor */
	public TpTq(Integer ssid, Testpapers testpapers, Testquestions testquestions) {
		this.ssid = ssid;
		this.testpapers = testpapers;
		this.testquestions = testquestions;
	}

	/** full constructor */
	public TpTq(Integer ssid, Testpapers testpapers,
			Testquestions testquestions, Set studentsTqs) {
		this.ssid = ssid;
		this.testpapers = testpapers;
		this.testquestions = testquestions;
		this.studentsTqs = studentsTqs;
	}

	// Property accessors

	public Integer getSsid() {
		return this.ssid;
	}

	public void setSsid(Integer ssid) {
		this.ssid = ssid;
	}

	public Testpapers getTestpapers() {
		return this.testpapers;
	}

	public void setTestpapers(Testpapers testpapers) {
		this.testpapers = testpapers;
	}

	public Testquestions getTestquestions() {
		return this.testquestions;
	}

	public void setTestquestions(Testquestions testquestions) {
		this.testquestions = testquestions;
	}

	public Set getStudentsTqs() {
		return this.studentsTqs;
	}

	public void setStudentsTqs(Set studentsTqs) {
		this.studentsTqs = studentsTqs;
	}

}