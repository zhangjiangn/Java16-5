package bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Testquestions entity. @author MyEclipse Persistence Tools
 */

public class Testquestions implements java.io.Serializable {

	// Fields

	private Integer tqid;
	private Subjects subjects;
	private String topicbigtype;
	private String topictype;
	private String tqcontent;
	private String optionsA;
	private String optionsB;
	private String optionsC;
	private String optionsD;
	private String answer;
	private String difficulty;
	private String chapters;
	private Set tpTqs = new HashSet(0);

	// Constructors

	/** default constructor */
	public Testquestions() {
	}

	/** minimal constructor */
	public Testquestions(Integer tqid, Subjects subjects, String topicbigtype,
			String topictype, String tqcontent, String optionsA,
			String optionsB, String optionsC, String optionsD, String answer,
			String difficulty, String chapters) {
		this.tqid = tqid;
		this.subjects = subjects;
		this.topicbigtype = topicbigtype;
		this.topictype = topictype;
		this.tqcontent = tqcontent;
		this.optionsA = optionsA;
		this.optionsB = optionsB;
		this.optionsC = optionsC;
		this.optionsD = optionsD;
		this.answer = answer;
		this.difficulty = difficulty;
		this.chapters = chapters;
	}

	/** full constructor */
	public Testquestions(Integer tqid, Subjects subjects, String topicbigtype,
			String topictype, String tqcontent, String optionsA,
			String optionsB, String optionsC, String optionsD, String answer,
			String difficulty, String chapters, Set tpTqs) {
		this.tqid = tqid;
		this.subjects = subjects;
		this.topicbigtype = topicbigtype;
		this.topictype = topictype;
		this.tqcontent = tqcontent;
		this.optionsA = optionsA;
		this.optionsB = optionsB;
		this.optionsC = optionsC;
		this.optionsD = optionsD;
		this.answer = answer;
		this.difficulty = difficulty;
		this.chapters = chapters;
		this.tpTqs = tpTqs;
	}

	// Property accessors

	public Integer getTqid() {
		return this.tqid;
	}

	public void setTqid(Integer tqid) {
		this.tqid = tqid;
	}

	public Subjects getSubjects() {
		return this.subjects;
	}

	public void setSubjects(Subjects subjects) {
		this.subjects = subjects;
	}

	public String getTopicbigtype() {
		return this.topicbigtype;
	}

	public void setTopicbigtype(String topicbigtype) {
		this.topicbigtype = topicbigtype;
	}

	public String getTopictype() {
		return this.topictype;
	}

	public void setTopictype(String topictype) {
		this.topictype = topictype;
	}

	public String getTqcontent() {
		return this.tqcontent;
	}

	public void setTqcontent(String tqcontent) {
		this.tqcontent = tqcontent;
	}

	public String getOptionsA() {
		return this.optionsA;
	}

	public void setOptionsA(String optionsA) {
		this.optionsA = optionsA;
	}

	public String getOptionsB() {
		return this.optionsB;
	}

	public void setOptionsB(String optionsB) {
		this.optionsB = optionsB;
	}

	public String getOptionsC() {
		return this.optionsC;
	}

	public void setOptionsC(String optionsC) {
		this.optionsC = optionsC;
	}

	public String getOptionsD() {
		return this.optionsD;
	}

	public void setOptionsD(String optionsD) {
		this.optionsD = optionsD;
	}

	public String getAnswer() {
		return this.answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getDifficulty() {
		return this.difficulty;
	}

	public void setDifficulty(String difficulty) {
		this.difficulty = difficulty;
	}

	public String getChapters() {
		return this.chapters;
	}

	public void setChapters(String chapters) {
		this.chapters = chapters;
	}

	public Set getTpTqs() {
		return this.tpTqs;
	}

	public void setTpTqs(Set tpTqs) {
		this.tpTqs = tpTqs;
	}

}