package bean;

/**
 * Grades entity. @author MyEclipse Persistence Tools
 */

public class Grades implements java.io.Serializable {

	// Fields

	private Integer gid;
	private Students students;
	private Testpapers testpapers;
	private String starttime;
	private String endtime;
	private String grade;

	// Constructors

	/** default constructor */
	public Grades() {
	}

	/** full constructor */
	public Grades(Integer gid, Students students, Testpapers testpapers,
			String starttime, String endtime, String grade) {
		this.gid = gid;
		this.students = students;
		this.testpapers = testpapers;
		this.starttime = starttime;
		this.endtime = endtime;
		this.grade = grade;
	}

	// Property accessors

	public Integer getGid() {
		return this.gid;
	}

	public void setGid(Integer gid) {
		this.gid = gid;
	}

	public Students getStudents() {
		return this.students;
	}

	public void setStudents(Students students) {
		this.students = students;
	}

	public Testpapers getTestpapers() {
		return this.testpapers;
	}

	public void setTestpapers(Testpapers testpapers) {
		this.testpapers = testpapers;
	}

	public String getStarttime() {
		return this.starttime;
	}

	public void setStarttime(String starttime) {
		this.starttime = starttime;
	}

	public String getEndtime() {
		return this.endtime;
	}

	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}

	public String getGrade() {
		return this.grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

}