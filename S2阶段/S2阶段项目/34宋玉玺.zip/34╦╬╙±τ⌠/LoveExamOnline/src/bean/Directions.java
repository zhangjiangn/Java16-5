package bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Directions entity. @author MyEclipse Persistence Tools
 */

public class Directions implements java.io.Serializable {

	// Fields

	private Integer did;
	private String dname;
	private Set classeses = new HashSet(0);
	private Set subjectses = new HashSet(0);

	// Constructors

	/** default constructor */
	public Directions() {
	}

	/** minimal constructor */
	public Directions(Integer did, String dname) {
		this.did = did;
		this.dname = dname;
	}

	/** full constructor */
	public Directions(Integer did, String dname, Set classeses, Set subjectses) {
		this.did = did;
		this.dname = dname;
		this.classeses = classeses;
		this.subjectses = subjectses;
	}

	// Property accessors

	public Integer getDid() {
		return this.did;
	}

	public void setDid(Integer did) {
		this.did = did;
	}

	public String getDname() {
		return this.dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public Set getClasseses() {
		return this.classeses;
	}

	public void setClasseses(Set classeses) {
		this.classeses = classeses;
	}

	public Set getSubjectses() {
		return this.subjectses;
	}

	public void setSubjectses(Set subjectses) {
		this.subjectses = subjectses;
	}

}