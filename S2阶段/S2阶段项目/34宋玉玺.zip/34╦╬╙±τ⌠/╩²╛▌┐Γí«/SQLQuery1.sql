select * from users
select * from directions
select * from grades
select * from tp_tq
select * from stages
select * from students
select * from testpapers
select * from students_tq
select * from subjects

select * from testquestions
select * from classes
select count(*) from Testquestions tq where tq.subid=1
select * from Testquestions tq where tq.subid=2
