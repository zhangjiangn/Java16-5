package com.qhit.biz.impl;

import java.util.ArrayList;

import com.qhit.bean.Direction;
import com.qhit.bean.Paper;
import com.qhit.bean.Score;
import com.qhit.bean.Stage;
import com.qhit.bean.Student;
import com.qhit.bean.Subject;
import com.qhit.biz.ScoreBiz;
import com.qhit.dao.ScoreDao;
import com.qhit.dao.impl.ScoreDaoImpl;
import com.qhit.util.PageBean;

public class ScoreBizImpl implements ScoreBiz {

	private ScoreDao dao=new ScoreDaoImpl();
	
	public int getCountBypid(int pid) {
		
		return dao.getCountBypid(pid);
	}

	public ArrayList<Direction> getDirList() {
		
		return dao.getDirList();
	}

	public ArrayList<Paper> getPaper(int pid) {
		
		return dao.getPaper(pid);
	}

	public PageBean getPaperByPageBean(int p, int psubid) {
		
		return dao.getPaperByPageBean(p, psubid);
	}

	public int getPassCount(int pid) {
		
		return dao.getPassCount(pid);
	}

	public ArrayList<Score> getScoreByPid(int pid) {
		
		return dao.getScoreByPid(pid);
	}

	public ArrayList<Score> getScoreByPidAndSid(int pid, int sid) {
		
		return dao.getScoreByPidAndSid(pid, sid);
	}

	public ArrayList<Stage> getStageList() {
		
		return dao.getStageList();
	}

	public ArrayList<Student> getStudentsByNameStr(String snameStr) {
		
		return dao.getStudentsByNameStr(snameStr);
	}

	public ArrayList<Subject> getSubjectList() {
		
		return dao.getSubjectList();
	}

	public ArrayList<Subject> getSubjectListByDidAndStaid(int subdid,int substaid) {
		
		return dao.getSubjectListByDidAndStaid(subdid, substaid);
	}
	
	

}
