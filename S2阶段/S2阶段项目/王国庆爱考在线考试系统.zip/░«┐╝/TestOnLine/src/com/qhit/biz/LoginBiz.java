package com.qhit.biz;

import com.qhit.bean.Student;
import com.qhit.bean.Users;

public interface LoginBiz {
	
	public Student loginStudentByStu(String name,String pwd);
	public Users loginUsersByUsers(String name,String pwd);

}
