package com.qhit.dao.impl;

import org.hibernate.Query;

import com.qhit.bean.Student;
import com.qhit.bean.Users;
import com.qhit.dao.LoginDao;

public class LoginDaoImpl implements LoginDao {

	public Student loginStudentByStu(String name, String pwd) {
		
		Student stu = null;
		String hql = "from Student where sname=:name and spwd=:pwd";
		Query query= session.createQuery(hql);
		query.setString("name", name);
		query.setString("pwd", pwd);
		stu=(Student) query.uniqueResult();
		
		return stu;
	}

	public Users loginUsersByUsers(String name, String pwd) {
		
		Users u =null;
		String hql = "from Users where uname=:name and upwd=:pwd";
		Query query= session.createQuery(hql);
		query.setString("name", name);
		query.setString("pwd", pwd);
		u=(Users) query.uniqueResult();
		return u;
	}

}
