package com.qhit.action;

import org.apache.struts2.ServletActionContext;

import com.qhit.bean.Student;
import com.qhit.bean.Users;
import com.qhit.biz.LoginBiz;
import com.qhit.biz.impl.LoginBizImpl;

public class LoginAction {
	
	private String name;
	private String pwd;
	private String role;
	private LoginBiz lb = new LoginBizImpl();
	public String login(){
		try {
			int role1= Integer.parseInt(role);
			if(role1==1){
				Student stu =lb.getUsersByStu(name, pwd);
				if (stu!=null) {
					ServletActionContext.getRequest().getSession().setAttribute("student", stu);
					ServletActionContext.getRequest().getSession().setAttribute("role", 1);
					return "index";
				}else{
					return "erro";
				}
			}else if(role1!=1){
				Users u =lb.getUsersByUsers(name, pwd);
				if (u!=null) {
					ServletActionContext.getRequest().getSession().setAttribute("users", u);
					ServletActionContext.getRequest().getSession().setAttribute("role", 2);
					return "index";
				}else{
					return "erro";
				}
			}
		} catch (NumberFormatException e) {
			return "login";
		} catch(NullPointerException e1){
			return "login";
		}
		
		
		return "index";
	}
	
	public String logout(){
		ServletActionContext.getRequest().getSession().removeAttribute("users");
		ServletActionContext.getRequest().getSession().removeAttribute("student");
		ServletActionContext.getRequest().getSession().removeAttribute("role");
		return "top";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public LoginBiz getLb() {
		return lb;
	}

	public void setLb(LoginBiz lb) {
		this.lb = lb;
	}

	
	
	
}
