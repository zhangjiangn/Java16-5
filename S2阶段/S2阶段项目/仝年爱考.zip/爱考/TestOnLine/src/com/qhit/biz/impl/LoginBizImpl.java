package com.qhit.biz.impl;

import com.qhit.bean.Student;
import com.qhit.bean.Users;
import com.qhit.biz.LoginBiz;
import com.qhit.dao.LoginDao;
import com.qhit.dao.impl.LoginDaoImpl;

public class LoginBizImpl implements LoginBiz {
	
	private LoginDao dao=new LoginDaoImpl();

	public Student loginStudentByStu(String name, String pwd) {
		
		return dao.loginStudentByStu(name, pwd);
	}

	public Users loginUsersByUsers(String name, String pwd) {
		
		return dao.loginUsersByUsers(name, pwd);
	}

	

	

}
