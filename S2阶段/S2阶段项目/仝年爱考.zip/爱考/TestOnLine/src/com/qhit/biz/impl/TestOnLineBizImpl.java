package com.qhit.biz.impl;

import java.util.ArrayList;
import java.util.Date;

import com.qhit.bean.Paper;
import com.qhit.bean.PaperEq;
import com.qhit.bean.Score;
import com.qhit.bean.StuPaperEq;
import com.qhit.biz.TestOnLineBiz;
import com.qhit.dao.TestOnLineDao;
import com.qhit.dao.impl.TestOnLineDaoImpl;
import com.qhit.util.DateFormatUtil;
import com.qhit.util.PageBean;

public class TestOnLineBizImpl implements TestOnLineBiz {

	private DateFormatUtil  dfu = new DateFormatUtil();
	private TestOnLineDao dao = new TestOnLineDaoImpl();
	
	public PageBean getPaperByPageBean(int p, int pcid) {
		
		return dao.getPaperByPageBean(p, pcid);
	}

	public int addStuPaperEq(int sid, int pid, int eid, String stuanswer) {
		
		return dao.addStuPaperEq(sid, pid, eid, stuanswer);
	}

	public int finishExam(String startTime, String finishTime, int socre,
			int pid, int sid) {
		
		return dao.finishExam(startTime, finishTime, socre, pid, sid);
	}

	public String getDate(Date date) {
		
		return dfu.getDate(date);
	}

	public ArrayList<Paper> getPaperByPid(int pid) {
		
		return dao.getPaperByPid(pid);
	}

	public ArrayList<PaperEq> getPaperEqPid(int pid) {
		
		return dao.getPaperEqPid(pid);
	}

	public int getPaperTotalCountByPid(int pid) {
		
		return dao.getPaperTotalCountByPid(pid);
	}

	public int getScore(ArrayList<StuPaperEq> speList, int ptotalScore, int size) {
		
		return dao.getScore(speList, ptotalScore, size);
	}

	public StuPaperEq getStuAnswer(int sid, int pid, int eid) {
		
		return dao.getStuAnswer(sid, pid, eid);
	}

	public ArrayList<StuPaperEq> getStuAnswerAll(int sid, int pid) {
		
		return dao.getStuAnswerAll(sid, pid);
	}

	public ArrayList<Score> getStuSocreList(int pid, int sid) {
		
		return dao.getStuSocreList(pid, sid);
	}
	
	

}
