package com.qhit.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;

import com.qhit.bean.Direction;
import com.qhit.bean.ExamQuestion;
import com.qhit.bean.Stage;
import com.qhit.bean.Subject;
import com.qhit.biz.ExamBiz;
import com.qhit.biz.impl.ExamBizImpl;
import com.qhit.util.PageBean;

public class ExamAction {
	
	private ExamBiz testbiz=new ExamBizImpl();
	private ArrayList<Direction> dirList = new ArrayList<Direction>();
	private ArrayList<Stage> staList;
	private ArrayList<Subject> subject;
	private ArrayList<Stage> stage;
	private ArrayList<Subject> subList = new ArrayList<Subject>();
	private String dirOpValue;
	private String staOpVlaue;
	private int esubid;
	private ArrayList<ExamQuestion> EQList;
	private ExamQuestion examQuestions;
	private int p;
	private PageBean pbEQ;
	private int eid;
	private File uploadFile;
	private String uploadFileFileName;
	private String downFileName;
	private InputStream downFile_is;
	
	
	//�ϴ�
	public String uploadExQt(){
		String filePath= ServletActionContext.getServletContext().getRealPath("/")+"upload/";
		try {
			FileUtils.copyFile(uploadFile, new File(filePath, uploadFileFileName));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		return "info";
	}
	
	
	//����
	public String downExQt(){
		if (downFileName!=null) {
		
		try {
			String filePath= ServletActionContext.getServletContext().getRealPath("/")+"upload/"+downFileName;
			downFile_is = new FileInputStream(filePath);
			return "down";
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
		return null;
		
	}
	
	
	public String ExIndex(){
		dirList=testbiz.getDirList();
		staList=testbiz.getStageList();
		subject = testbiz.getSubjectByDidAndStaid(1, 1);
		stage = testbiz.getStageById(1);
		for (Subject sub : subject) {
			int esubid= sub.getSubid();
			int Num = testbiz.getCountBySubid(esubid);
			sub.setCount(Num);
			subList.add(sub);
		}
		ServletActionContext.getRequest().getSession().setAttribute("subList", subList);
		return "tikuindex";
	}
	
	
	public String EQInfo(){

		int up=1;
		if(p!=0)up=p;
		pbEQ = testbiz.getExamQuestionPageBean(up, esubid);
		subject = testbiz.getSubjectById(esubid);
		if (pbEQ!=null) {
			return "tikuInfo";
		}else{
			return "error";
		}
	}
	
	public String dirChange(){
		int did = Integer.parseInt(dirOpValue);
		int staid = Integer.parseInt(staOpVlaue);
		dirList = testbiz.getDirList(did);
		staList = testbiz.getStageList(staid);
		subject = testbiz.getSubjectByDidAndStaid(did, staid);
		stage = testbiz.getStageById(staid);
		for (Subject sub : subject) {
			int esubid= sub.getSubid();
			int Num = testbiz.getCountBySubid(esubid);
			sub.setCount(Num);
			subList.add(sub);
		}
		ServletActionContext.getRequest().getSession().setAttribute("subList", subList);
		return "tikuindex";
	}
	
	public String staChange(){
		int did = Integer.parseInt(dirOpValue);
		int staid = Integer.parseInt(staOpVlaue);
		dirList = testbiz.getDirList(did);
		staList = testbiz.getStageList(staid);
		subject = testbiz.getSubjectByDidAndStaid(did, staid);
		stage = testbiz.getStageById(staid);
		for (Subject sub : subject) {
			int esubid= sub.getSubid();
			int Num = testbiz.getCountBySubid(esubid);
			sub.setCount(Num);
			subList.add(sub);
		}
		ServletActionContext.getRequest().getSession().setAttribute("subList", subList);
		return "tikuindex";
	}
	
	//����
	public String addExamQuestion(){
		subject = testbiz.getSubjectById(esubid);
		
		return "addtiku";
	}
	
	public String addExamQuestionStart(){
		int i= testbiz.addExamQuestion(examQuestions,esubid);
		if (i==1) {
			ServletActionContext.getRequest().getSession().setAttribute("intext", "���ӳɹ�!");
			return "success";
		}else{
			ServletActionContext.getRequest().getSession().setAttribute("intext", "����ʧ��!");
			return "success";
		}
		
	}
	
	
	
	//�޸�
	public String updateExamQuestion(){
		subject = testbiz.getSubjectById(esubid);
		EQList = testbiz.getExamQuestionByEid(eid);
		return "updatetiku";
	}
	
	public String updateExamQuestionStart(){
		int i = testbiz.updateExamQuestion(examQuestions, esubid);
		if (i==1) {
			ServletActionContext.getRequest().getSession().setAttribute("intext", "�޸ĳɹ�!");
			return "success";
		}else{
			ServletActionContext.getRequest().getSession().setAttribute("intext", "�޸�ʧ��!");
			return "success";
		}
	}


	
	public ArrayList<Direction> getDirList() {
		return dirList;
	}
	public void setDirList(ArrayList<Direction> dirList) {
		this.dirList = dirList;
	}
	public ExamBiz getTestbiz() {
		return testbiz;
	}
	public void setTestbiz(ExamBiz testbiz) {
		this.testbiz = testbiz;
	}
	public ArrayList<Stage> getStaList() {
		return staList;
	}
	public void setStaList(ArrayList<Stage> staList) {
		this.staList = staList;
	}
	public ArrayList<Subject> getSubject() {
		return subject;
	}
	public void setSubject(ArrayList<Subject> subject) {
		this.subject = subject;
	}
	public ArrayList<Stage> getStage() {
		return stage;
	}
	public void setStage(ArrayList<Stage> stage) {
		this.stage = stage;
	}
	public ArrayList<Subject> getSubList() {
		return subList;
	}
	public void setSubList(ArrayList<Subject> subList) {
		this.subList = subList;
	}
	public String getDirOpValue() {
		return dirOpValue;
	}
	public void setDirOpValue(String dirOpValue) {
		this.dirOpValue = dirOpValue;
	}
	public String getStaOpVlaue() {
		return staOpVlaue;
	}
	public void setStaOpVlaue(String staOpVlaue) {
		this.staOpVlaue = staOpVlaue;
	}
	public int getEsubid() {
		return esubid;
	}
	public void setEsubid(int esubid) {
		this.esubid = esubid;
	}
	public ArrayList<ExamQuestion> getEQList() {
		return EQList;
	}
	public void setEQList(ArrayList<ExamQuestion> eQList) {
		EQList = eQList;
	}
	public ExamQuestion getExamQuestions() {
		return examQuestions;
	}
	public void setExamQuestions(ExamQuestion examQuestions) {
		this.examQuestions = examQuestions;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public File getUploadFile() {
		return uploadFile;
	}
	public void setUploadFile(File uploadFile) {
		this.uploadFile = uploadFile;
	}
	public String getUploadFileFileName() {
		return uploadFileFileName;
	}
	public void setUploadFileFileName(String uploadFileFileName) {
		this.uploadFileFileName = uploadFileFileName;
	}
	public String getDownFileName() {
		return downFileName;
	}
	public void setDownFileName(String downFileName) {
		this.downFileName = downFileName;
	}
	public InputStream getDownFile_is() {
		return downFile_is;
	}
	public void setDownFile_is(InputStream downFileIs) {
		downFile_is = downFileIs;
	}
	public int getP() {
		return p;
	}
	public void setP(int p) {
		this.p = p;
	}
	public PageBean getPbEQ() {
		return pbEQ;
	}
	public void setPbEQ(PageBean pbEQ) {
		this.pbEQ = pbEQ;
	}
	
	
}
