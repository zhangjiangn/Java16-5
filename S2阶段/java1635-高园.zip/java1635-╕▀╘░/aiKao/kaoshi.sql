--create database TestOnLine

--�û���   uid uname upwd role  ����Ա����ʦ
create table Users(
uid int primary key identity(1,1),
accnumber nvarchar(50),--�˺�
uname nvarchar(50),
upwd nvarchar(20),
sex nvarchar(20),
brith nvarchar(50),
education nvarchar(50),
tel nvarchar(50),
uroles nvarchar(50),
orther nvarchar(200)----��ע
) 
--�༶��   bjid��name
create table banji(
bjid int primary key identity(1,1),
bjname nvarchar(50),
)
insert into banji values ('3g4g')
insert into banji values ('java')
--ѧ����   stuid��bjid��name��������
create table Stu(
stuid int primary key identity(1,1),
stunumber nvarchar(50),--ѧ��
stugrade nvarchar(50),
stuname nvarchar(50),
stupwd nvarchar(20),
stusex nvarchar(20),
stustel nvarchar(50),
bjid int,
FOREIGN KEY (bjid) REFERENCES banji(bjid)
) 
insert into Stu(stuname,stupwd) values ('student','123')
insert into Users(uname,upwd) values ('admin','123')

select stuname,stupwd from stu
select uname,upwd from Users





















--�׶α�   jdid  jdname
create table jieduan(
jdid int primary key identity(1,1),
bjname nvarchar(50)
)
insert into jieduan values ('one')
insert into jieduan values ('two')
--�����   fxid
create table fangxiang(
fxid int primary key identity(1,1),
fxname nvarchar(50)
)
insert into fangxiang values ('java')
insert into fangxiang values ('3g4g')
--��Ŀ��   kmid��jdid��fxid��kmname
create table kemu(
kmid int primary key identity(1,1),
kmname nvarchar(50),
jdid int,
fxid int,
FOREIGN KEY (jdid) REFERENCES jieduan( jdid ),
FOREIGN KEY (fxid) REFERENCES fangxiang( fxid )
)
select * from jieduan
select * from fangxiang
select * from kemu

select j.bjname,f.fxname from jieduan j inner join fangxiang f on j.jdid=f.fxid

select count(*) s,kmid  from shiti group by kmid


insert into kemu values ('����',1,1)
insert into kemu values ('����',2,2)

--�����   stid��kmid����Ŀ�����͡���Ŀ���ͣ���ѡ/��ѡ����...
create table shiti(
stid int primary key identity(1,1),
stbigType nvarchar(50),
tmtype nvarchar(50),
tmNr nvarchar(200),
xuanxiangA nvarchar(200),
xuanxiangB nvarchar(200),
xuanxiangC nvarchar(200),
xuanxiangD nvarchar(200),
zhangjie nvarchar(50),
meitiFs int,
daan nvarchar(2),
nandu nvarchar(10),
kmid int,
FOREIGN KEY (kmid) REFERENCES kemu(kmid)
)
insert into shiti values ('java','java�﷨','����ѡ�����Ǹ�����ȷ�ı�ʾ��?','class','new','int','Student','T4',20,'D','��',1)
update shiti set tmtype='��ѡ' where stid=2













--�Ծ���   sjid��sj���͡��ο��༶���Ծ�״̬��������
create table shijuan(
sjid int primary key identity(1,1),
sjType nvarchar(20),
sjkm nvarchar(20),
sjbt nvarchar(20),
bjid int,----�ο��༶
FOREIGN KEY (bjid) REFERENCES banji(bjid),
kaoshiTime nvarchar(50),
sjzt nvarchar(40),
)

insert into shijuan values ('����','java','swing����',1,'60','δ����')


--�Ծ�_�����  ssid��sjid��stid
create table shijuan_shiti(
ssid int primary key identity(1,1),
sjid int,
stid int,
FOREIGN KEY (sjid) REFERENCES shijuan(sjid),
FOREIGN KEY (stid) REFERENCES shiti(stid),

)
select * from shijuan_shiti
insert into shijuan_shiti values (1,2)
--�ɼ���   cjid��stuid��sjid����ʼʱ�䡢����ʱ�䡢�ɼ�
create table chengji(
cjid int primary key identity(1,1),
stuid int,
sjid int,
FOREIGN KEY (stuid) REFERENCES Stu(stuid),
FOREIGN KEY (sjid) REFERENCES shijuan(sjid),
begintime nvarchar(20),
overtime nvarchar(20),
chengji int
)
--ѧ��_�����  stuid��sjid��stid��ѧ����
create table Stu_shiti(
sstuid int primary key identity(1,1),
stuid int,
sjid int,
stid int,
FOREIGN KEY (stuid) REFERENCES Stu(stuid),
FOREIGN KEY (sjid) REFERENCES shijuan(sjid),
FOREIGN KEY (stid) REFERENCES shiti(stid),
Stuanewr nvarchar(50)
) 


















select * from dbo.chengji
select * from dbo.Stu_shiti


select * from dbo.shijuan_shiti


select * from dbo.kemu
select * from dbo.Users
select * from dbo.Stu
select * from dbo.jieduan
select * from dbo.banji
select * from dbo.fangxiang


select * from dbo.shijuan
select * from dbo.shiti


insert into shijuan(sjbt,kaosiTime,sjzt)


insert into shiti(tmtype,meitiFs,kmid) values 