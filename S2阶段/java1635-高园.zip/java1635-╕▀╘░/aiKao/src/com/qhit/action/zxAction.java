package com.qhit.action;

import java.util.List;

import com.qhit.bean.Shijuan;
import com.qhit.bean.Shiti;
import com.qhit.bean.StuShiti;
import com.qhit.biz.zxBiz;
import com.qhit.biz.impl.zxBizimpl;
import com.qhit.util.PageBean;

public class zxAction {
	
private zxBiz biz=new zxBizimpl();

private StuShiti ss;
private Shiti shiti;

private List<Shijuan> list;
private List<Shiti> stlist;

private PageBean pbEQ;
private int p;

private int stid;
private String daan;


public String kaoshi(){
	
	int up=1;
	if(p!=0)up=p;
	pbEQ=biz.find(up);
	
	list=biz.stlist(shiti.getStid());
	return "kaoshi";
}

public String showlist(){
	list=biz.list();
	return "zxks";
}

public String duibianwer(){
		biz.addsss(daan);
		return "over";
	
	
}









public int getStid() {
	return stid;
}

public void setStid(int stid) {
	this.stid = stid;
}

public String getDaan() {
	return daan;
}

public void setDaan(String daan) {
	this.daan = daan;
}

public List<Shijuan> getList() {
	return list;
}

public void setList(List<Shijuan> list) {
	this.list = list;
}
public zxBiz getBiz() {
	return biz;
}
public void setBiz(zxBiz biz) {
	this.biz = biz;
}
public List<Shiti> getStlist() {
	return stlist;
}
public void setStlist(List<Shiti> stlist) {
	this.stlist = stlist;
}
public PageBean getPbEQ() {
	return pbEQ;
}
public void setPbEQ(PageBean pbEQ) {
	this.pbEQ = pbEQ;
}
public int getP() {
	return p;
}
public void setP(int p) {
	this.p = p;
}

public Shiti getShiti() {
	return shiti;
}

public void setShiti(Shiti shiti) {
	this.shiti = shiti;
}

}
