package com.qhit.biz.impl;

import java.util.List;

import org.hibernate.Session;

import com.qhit.bean.Fangxiang;
import com.qhit.bean.Jieduan;
import com.qhit.bean.Kemu;
import com.qhit.bean.Shijuan;
import com.qhit.bean.Shiti;
import com.qhit.biz.shijuanBiz;
import com.qhit.dao.HibernateSessionFactory;
import com.qhit.dao.shijuanDao;
import com.qhit.dao.impl.shijuanDaoimpl;
import com.qhit.util.PageBean;

public class shijuanBizimpl implements shijuanBiz {
private shijuanDao dao=new shijuanDaoimpl();

	public PageBean find(int p) {
		
		return dao.find(p);
	}

	public List<Fangxiang> sjFx() {
		// TODO Auto-generated method stub
		return dao.sjFx();
	}

	public List<Jieduan> sjjd() {
		// TODO Auto-generated method stub
		return dao.sjjd();
	}

	public List<Kemu> sjkm() {
		// TODO Auto-generated method stub
		return dao.sjkm();
	}

	public List<Shijuan> sjzt() {
		// TODO Auto-generated method stub
		return dao.sjzt();
	}

	public shijuanDao getDao() {
		return dao;
	}

	public void setDao(shijuanDao dao) {
		this.dao = dao;
	}

	public int addshijuan(Shijuan sj) {
	
		return dao.addshijuan(sj);
	}

	public List<Shiti> show() {
		// TODO Auto-generated method stub
		return dao.show();
	}

	public int updateZT(int sj) {
		// TODO Auto-generated method stub
		return dao.updateZT(sj);
	}

	public int stop(int sj) {
		// TODO Auto-generated method stub
		return dao.stop(sj);
	}

}
