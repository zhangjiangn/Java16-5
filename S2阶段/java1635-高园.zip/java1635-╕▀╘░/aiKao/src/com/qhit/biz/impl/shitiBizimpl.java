package com.qhit.biz.impl;

import java.util.ArrayList;
import java.util.List;

import com.qhit.bean.Kemu;
import com.qhit.bean.Shiti;
import com.qhit.biz.shitiBiz;
import com.qhit.dao.shitiDao;
import com.qhit.dao.impl.shitiDaoimpl;
import com.qhit.util.PageBean;

public class shitiBizimpl implements shitiBiz {
private shitiDao dao=new shitiDaoimpl();
	public List<Shiti> listshow() {
		// TODO Auto-generated method stub
		return dao.listshow();
	}
	public int addshiti(Shiti shiti){
		return dao.addshiti(shiti);
	}
	
	
	public shitiDao getDao() {
		return dao;
	}
	public void setDao(shitiDao dao) {
		this.dao = dao;
	}
	public PageBean find(int p) {
		// TODO Auto-generated method stub
		return dao.find(p);
	}
	public int UPDATEshiti(Shiti shiti) {
		// TODO Auto-generated method stub
		return dao.UPDATEshiti(shiti);
	}
	public List<Shiti> shitishow(int id) {
		// TODO Auto-generated method stub
		return dao.shitishow(id);
	}
	public PageBean getExamQuestionPageBean(int p) {
		// TODO Auto-generated method stub
		return dao.getExamQuestionPageBean(p);
	}
	public ArrayList<Kemu> getSubjectById(int subid) {
		// TODO Auto-generated method stub
		return dao.getSubjectById(subid);
	}

}
