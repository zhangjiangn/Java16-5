package com.qhit.tset;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.omg.CORBA.INTF_REPOS;

import com.qhit.bean.Jieduan;
import com.qhit.bean.Shijuan;
import com.qhit.bean.Shiti;
import com.qhit.bean.Stu;
import com.qhit.bean.StuShiti;
import com.qhit.dao.HibernateSessionFactory;

public class fdgfd {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
//		String hql="select s from Stu s where stuname=? and stupwd=?";
//		Query query=session.createQuery(hql);
//		query.setString(0,"zhangsan");
//		query.setString(1,"123");
////		Stu stu= (Stu) query.list();
////		System.out.println(stu.getStuname());
//		List<Stu> stu= query.list();
//		for (Stu stu2 : stu) {
//			System.out.println(stu2.getStuname());
//		}
		

//	   		String hql="select j.bjname,f.fxname from Jieduan j join j.kemus f on j.jdid=f.fxid";
//	   		Query query=session.createQuery(hql);
//	   		List<Jieduan> stu= query.list();
//	   		for(Jieduan j:stu){ 
//	   			System.out.println(j.getBjname());
//	   		} 
		
//		String kmid="java�﷨";
//		
//		String sql = "select count(*) from Shiti where tmtype='"+kmid+"' group by tmtype";
//		SQLQuery sqlquery = session.createSQLQuery(sql);
//		
//		Object o = sqlquery.list();
//		System.out.println(o.toString());
//		if (o==null) {
//			count = 0;
//		}else{
//			count = Integer.parseInt(o.toString());
//		}
//		
//		String hql="from Shiti s";
//		Query query=session.createQuery(hql);
//		List<Shiti> list=query.list();
//		for (Shiti shiti : list) {
//			System.out.println(shiti.getZhangjie());
//		}
//		int id=1;
//		String hql="from Shiti s where stid ="+id;
//		Query query=session.createQuery(hql);
//		
//		List<Shiti> list=query.list();
//		for (Shiti shiti : list) {
//			System.out.println(shiti.getDaan()+shiti.getTmNr());
//		}
		
//		String hql="select count(s) from Shiti s";
//		Query query=session.createQuery(hql);	
//		List<Object> list=query.list();
//		for (Object obj : list) {
//			System.out.println(obj);
//		}
		
		
//	   	String hql01="select s from Shijuan s join s.banji b";
//	   	Query query=session.createQuery(hql01);	
//			List<Object> list=query.list();
//			for (Object obj : list) {
//				System.out.println(obj);
//			}
		
	
//	  		int time=3600;
//			while (time>0) {
//				time--;
//				try {
//					Thread.sleep(1000);
//					int hh=time/60/60%60;
//					int mm=time/60%60;
//					int ss=time%60;
//					
//					System.out.println("��ʣ"+mm+"����"+ss+"��");
//					//<%="��ʣ"+hh+"Сʱ"+mm+"����"+ss+"��" %>
//					
//				} catch (Exception e) {
//					// TODO: handle exception
//					e.printStackTrace();
//				}
//			}
	
//		String hql = "select count(sj) from Chengji sj where chengji='"+100+"' group by chengji";
//		Query sqlquery = session.createQuery(hql);
//		Object o = sqlquery.list();
//		
//		int p=Integer.parseInt(o.toString());
//		System.out.println(p);
		Shijuan ss=(Shijuan)session.get(Shijuan.class, 1);
		Stu stu=(Stu)session.get(Stu.class, 1);
		Shiti shiti=(Shiti)session.get(Shiti.class, 1);
		StuShiti ss1=new StuShiti();
		ss1.setShijuan(ss);
		ss1.setShiti(shiti);
		ss1.setStu(stu);
		ss1.setStuanewr("A");
		
		session.beginTransaction();
		session.save(ss1);
		session.beginTransaction().commit();
		session.close();
		
	}

}
