package com.qhit.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import com.qhit.bean.Fangxiang;
import com.qhit.bean.Jieduan;
import com.qhit.bean.Shiti;
import com.qhit.bean.Stu;
import com.qhit.bean.Users;
import com.qhit.dao.HibernateSessionFactory;
import com.qhit.dao.loginDao;

public class loginDaoimpl implements loginDao {
	
	public Stu stulogin(String name, String pwd) {
		// TODO Auto-generated method stub
			
			Session session=HibernateSessionFactory.getSession();
			String hql="from Stu s where stuname=? and stupwd=?";
			Query query=session.createQuery(hql);
			query.setString(0,name);
			query.setString(1,pwd);
			
		    return (Stu)query.uniqueResult();
	}

	public Users userslogin(String name, String pwd) {
		Session session=HibernateSessionFactory.getSession();
		String hql="from Users s where s.uname=? and s.upwd=?";
		Query query=session.createQuery(hql);
		query.setString(0,name);
		query.setString(1,pwd);	
		return (Users)query.uniqueResult();
	}
/////����SCME��SCCE���ͽ׶Σ�G1��G2��G3��
	public ArrayList<Jieduan> list(int id) {
		Session session=HibernateSessionFactory.getSession();
		String hql="from Jieduan j";
		Query query=session.createQuery(hql);
		return (ArrayList<Jieduan>) query.list();
	}

	public ArrayList<Fangxiang> lists(int id) {
		Session session=HibernateSessionFactory.getSession();
		String hql="from Fangxiang f";
		Query query=session.createQuery(hql);
		return (ArrayList<Fangxiang>) query.list();
	}
//��ѯ���������
	public ArrayList<Shiti> find() {	
		Session session=HibernateSessionFactory.getSession();
		String hql="select count(st) s,kmid  from Shiti st group by kmid";
		Query query=session.createQuery(hql);
		return (ArrayList<Shiti>) query.list();
	}

	
}
