package com.qhit.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.qhit.bean.Fangxiang;
import com.qhit.bean.Jieduan;
import com.qhit.bean.Kemu;
import com.qhit.bean.Shijuan;
import com.qhit.bean.Shiti;
import com.qhit.dao.HibernateSessionFactory;
import com.qhit.dao.shijuanDao;
import com.qhit.util.PageBean;

public class shijuanDaoimpl implements shijuanDao {
	static Session session=HibernateSessionFactory.getSession();
	public PageBean find(int p) {
		PageBean pb = new PageBean();
		Transaction transaction = session.beginTransaction();
		String hql3="from Shijuan ";
		Query query = session.createQuery(hql3).setCacheable(true);
   		
   		
   		int count=query.list().size();
		pb.setPagesize(3);
		pb.setCount(count);
		pb.setP(p);
		query.setFirstResult((p-1)*3);
		query.setMaxResults(pb.getPagesize());
		List<Shijuan> sj = query.list();
		pb.setData(sj);
		transaction.commit();
		return pb;
	}

	public List<Fangxiang> sjFx() {
		
	   	 String hql1="from Fangxiang";
	   	 Query query2=session.createQuery(hql1);
	   	 List<Fangxiang> Fx= query2.list();
		 return Fx;
	}

	public List<Jieduan> sjjd() {
		String hql="from Jieduan";
   		Query query=session.createQuery(hql);
   		List<Jieduan> jd= query.list();
		return jd;
	}

	public List<Kemu> sjkm() {
		String hql2="from Kemu";
   		Query query1=session.createQuery(hql2);
   		List<Kemu> km= query1.list();
		return km;
	}

	public List<Shijuan> sjzt() {
		// TODO Auto-generated method stub
		return null;
	}

	public int addshijuan(Shijuan sj) {
		int i=0;
		try {
			Session session=HibernateSessionFactory.getSession();
			session.beginTransaction();
			session.update(sj);
			session.beginTransaction().commit();
		} catch (Exception e) {
			i=1;
		}	
		return i;
	}

	public List<Shiti> show() {
		String hql="from Shiti";
   		Query query=session.createQuery(hql);
   		List<Shiti> sj= query.list();
		return sj;
	}

	public int updateZT(int sj) {
		int i=0;
		try {
			Session session=HibernateSessionFactory.getSession();
			Shijuan sj0=(Shijuan)session.get(Shijuan.class, sj);
			sj0.setSjzt("������");
			
			session.beginTransaction();
			session.update(sj0);
			session.beginTransaction().commit();
		} catch (Exception e) {
			i=1;
		}	
		return i;
	}

	public int stop(int sj) {
		int i=0;
		try {
			Session session=HibernateSessionFactory.getSession();
			Shijuan sj0=(Shijuan)session.get(Shijuan.class, sj);
			sj0.setSjzt("��������");
			session.beginTransaction();
			session.update(sj0);
			session.beginTransaction().commit();
		} catch (Exception e) {
			i=1;
		}	
		return i;
	}

}
