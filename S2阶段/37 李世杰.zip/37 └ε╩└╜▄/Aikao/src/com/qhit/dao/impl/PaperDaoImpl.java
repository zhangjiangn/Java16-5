package com.qhit.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Transaction;

import com.qhit.bean.Classs;
import com.qhit.bean.Direction;
import com.qhit.bean.ExamQuestion;
import com.qhit.bean.Level;
import com.qhit.bean.Paper;
import com.qhit.bean.PaperEq;
import com.qhit.bean.Stage;
import com.qhit.bean.Subject;
import com.qhit.bean.Tatus;
import com.qhit.dao.PaperDao;
import com.qhit.util.PageBean;

public class PaperDaoImpl implements PaperDao {

	public ArrayList<Direction> getDirList() {
		String hql = "from Direction";
		Query query = session.createQuery(hql);
		return (ArrayList<Direction>) query.list();
	}

	public ArrayList<Stage> getStageList() {
		String hql = "from Stage";
		Query query = session.createQuery(hql);
		return (ArrayList<Stage>) query.list();
	}

	public ArrayList<Subject> getSubjectList() {
		String hql = "from Subject";
		Query query = session.createQuery(hql);
		return (ArrayList<Subject>) query.list();
	}

	public ArrayList<Direction> getDirList(int order) {
		ArrayList<Direction> list = new ArrayList<Direction>();
		switch (order) {
		case 1:
			String hql = "from Direction";
			Query query = session.createQuery(hql);
			list = (ArrayList<Direction>) query.list();
			break;
		default:
			String hql2 = "from Direction order by did desc";
			Query query2 = session.createQuery(hql2);
			list = (ArrayList<Direction>) query2.list();
			break;
		}
		return list;
	}

	public ArrayList<Stage> getStageList(int order) {
		ArrayList<Stage> list = new ArrayList<Stage>();
		switch (order) {
		case 1:
			String hql = "from Stage";
			Query query = session.createQuery(hql);
			list = (ArrayList<Stage>) query.list();
			break;
	
		default:
			String hql2 = "from Stage order by staid desc";
			Query query2 = session.createQuery(hql2);
			list = (ArrayList<Stage>) query2.list();
			break;
		}
		return list;
	}

	public ArrayList<Subject> getSubjectList(int order) {
		ArrayList<Subject> list = new ArrayList<Subject>();
		switch (order) {
		case 1:
			String hql = "from Subject";
			Query query = session.createQuery(hql);
			list = (ArrayList<Subject>) query.list();
			break;
	
		default:
			String hql2 = "from Subject order by staid desc";
			Query query2 = session.createQuery(hql2);
			list = (ArrayList<Subject>) query2.list();
			break;
		}
		return list;
	}

	public ArrayList<Tatus> getExamTatus(int order) {
		ArrayList<Tatus> list = new ArrayList<Tatus>();
		switch (order) {
		case 1:
			String hql = "from Tatus";
			Query query = session.createQuery(hql);
			list = (ArrayList<Tatus>) query.list();
			break;
		default:
			String hql2 = "from Tatus order by did desc";
			Query query2 = session.createQuery(hql2);
			list = (ArrayList<Tatus>) query2.list();
			break;
		}
		return list;
	}

	public ArrayList<Paper> getExamType(int order) {
		// TODO Auto-generated method stub
		return null;
	}

	public ArrayList<Paper> getPaperById(int pid) {
		String hql = "from Paper where pid=:pid";
		Query query = session.createQuery(hql);
		query.setInteger("pid", pid);
		return (ArrayList<Paper>) query.list();
	}

	public ArrayList<Subject> getSubjectListByDidAndStaid(int subdid, int substaid) {
		String hql = "from Subject where subdid=:subdid and substaid=:substaid";
		Query query = session.createQuery(hql);
		query.setInteger("subdid", subdid);
		query.setInteger("substaid", substaid);
		return (ArrayList<Subject>) query.list();
	}

	public PageBean getPaperByPageBean(int p, int pid) {
		PageBean pb = new PageBean();
		Transaction transaction = session.beginTransaction();
		try {
			String hql = "from Paper where pid=:pid";
			Query query = session.createQuery(hql).setCacheable(true);
			query.setInteger("pid", pid);
			int count=query.list().size();
			
			pb.setPagesize(5);
			pb.setCount(count);
			pb.setP(p);
			
			query.setFirstResult((p-1)*5);
			query.setMaxResults(pb.getPagesize());
			List<ExamQuestion> eqList = query.list();
			pb.setData(eqList);
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
		}
		return pb;
	}

	public PageBean getPaperByPageBean(int p, String pfirstType) {
		PageBean pb = new PageBean();
		Transaction transaction = session.beginTransaction();
		try {
			String hql = "from Paper where pfirstType=:pfirstType";
			Query query = session.createQuery(hql).setCacheable(true);
			query.setString("pfirstType", pfirstType);
			int count=query.list().size();
			
			pb.setPagesize(5);
			pb.setCount(count);
			pb.setP(p);
			
			query.setFirstResult((p-1)*5);
			query.setMaxResults(pb.getPagesize());
			List<ExamQuestion> eqList = query.list();
			pb.setData(eqList);
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
		}
		return pb;
	}

	public PageBean getPaperByPageBean(int p,int psubid, int ptaid) {
		PageBean pb = new PageBean();
		Transaction transaction = session.beginTransaction();
		try {
			String hql = "from Paper where psubid=:psubid and ptaid=:ptaid";
			Query query = session.createQuery(hql).setCacheable(true);
			query.setInteger("psubid", psubid);
			query.setInteger("ptaid", ptaid);
			int count=query.list().size();
			
			pb.setPagesize(5);
			pb.setCount(count);
			pb.setP(p);
			
			query.setFirstResult((p-1)*5);
			query.setMaxResults(pb.getPagesize());
			List<ExamQuestion> eqList = query.list();
			pb.setData(eqList);
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
		}
		return pb;
	}

	public PageBean getPaperByPageBeanBySubid(int p, int psubid) {
		PageBean pb = new PageBean();
		Transaction transaction = session.beginTransaction();
		try {
			String hql = "from Paper where psubid=:psubid";
			Query query = session.createQuery(hql).setCacheable(true);
			query.setInteger("psubid", psubid);
			int count=query.list().size();
			
			pb.setPagesize(5);
			pb.setCount(count);
			pb.setP(p);
			
			query.setFirstResult((p-1)*5);
			query.setMaxResults(pb.getPagesize());
			List<ExamQuestion> eqList = query.list();
			pb.setData(eqList);
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
		}
		return pb;
	}

	public PageBean getExamQuestionByPageBean(int p, int esubid) {
		PageBean pb = new PageBean();
		Transaction transaction = session.beginTransaction();
		try {
			String hql = "from ExamQuestion where esubid=:esubid";
			Query query = session.createQuery(hql).setCacheable(true);
			query.setInteger("esubid", esubid);
			int count=query.list().size();
			
			pb.setPagesize(5);
			pb.setCount(count);
			pb.setP(p);
			
			query.setFirstResult((p-1)*5);
			query.setMaxResults(pb.getPagesize());
			List<ExamQuestion> eqList = query.list();
			pb.setData(eqList);
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
		}
		return pb;
	}

	public int addPaper(Paper paper, int psubid) {
		int i = 1;
		try {
			Subject sub = (Subject) session.get(Subject.class, psubid);
			paper.setSubject(sub);
			Tatus tatus = (Tatus) session.get(Tatus.class, 1);
			paper.setTatus(tatus);
			session.beginTransaction();
			session.save(paper);
			session.beginTransaction().commit();
		} catch (Exception e) {
			i = 0;
			session.beginTransaction().rollback();
		}
		return i;
	}

	public int getPaperDescID() {
		String hql = "from Paper order by pid desc";
		Query query = session.createQuery(hql);
		ArrayList<Paper> paperList = (ArrayList<Paper>) query.list();
	 	Paper p = paperList.get(0);
		return p.getPid();
	}

	public int addPaper_EQ(int pid, int eid) {
		int i = 1;
		try {
			
			Paper paper = (Paper) session.get(Paper.class, pid);
			ExamQuestion examQuestion = (ExamQuestion) session.get(ExamQuestion.class, eid);
			PaperEq pe = new PaperEq();
			pe.setPaper(paper);
			pe.setExamQuestion(examQuestion);
			
			session.beginTransaction();
			session.save(pe);
			session.beginTransaction().commit();
		} catch (Exception e) {
			i = 0;
			session.beginTransaction().rollback();
		}
		return i;
	}

	public ArrayList<ExamQuestion> getExamQuestionByEqPid(int pid) {
		ArrayList<ExamQuestion> list = new ArrayList<ExamQuestion>();
		String hql = "from PaperEq where pid=:pid";
		Query query = session.createQuery(hql);
		query.setInteger("pid", pid);
		ArrayList<PaperEq> PaperEqlist = (ArrayList<PaperEq>) query.list();
		for (PaperEq paperEq : PaperEqlist) {
			  list.add(paperEq.getExamQuestion());
		}
		return list;
	}

	public int updateIStart(ArrayList<Paper> paperLists) {
		int i = 1;
		try {
			for (Paper paper : paperLists) {
				int pid = paper.getPid();
				int cid = paper.getClasss().getCid();
				Classs cla=(Classs) session.get(Classs.class, cid);
				Paper paperInfo = (Paper) session.get(Paper.class, pid);
				if (paperInfo.getPstartTime() == null) {
					paperInfo.setPstartTime(paper.getPstartTime());
				} else {
					if (paperInfo.getPstartTime().equals(paper.getPstartTime())) {
					} else {
						paperInfo.setPstartTime(paper.getPstartTime());
					}
				}
				
				if (paperInfo.getPfinishTime() == null) {
					paperInfo.setPfinishTime(paper.getPstartTime());
				} else {
					if (paperInfo.getPfinishTime().equals(paper.getPfinishTime())) {
					} else {
						paperInfo.setPfinishTime(paper.getPfinishTime());
					}
				}
				
				
				paperInfo.setClasss(cla);
				session.beginTransaction();
				session.update(paperInfo);
				session.beginTransaction().commit();
			}
		} catch (Exception e) {
			i = 0;
			session.beginTransaction().rollback();
		}
		
		return i;
	}

	public ArrayList<Classs> getCalsss() {
		ArrayList<Classs> list = new ArrayList<Classs>();
		String hql = "from Classs";
		Query query = session.createQuery(hql);
		list = (ArrayList<Classs>) query.list();
		return list;
	}

	public int StartExam(int pid) {
		int i = 1;
		try {
			Paper paper = (Paper) session.get(Paper.class, pid);
			Tatus t = (Tatus) session.get(Tatus.class, 2);
			paper.setTatus(t);
			session.beginTransaction();
			session.update(paper);
			session.beginTransaction().commit();
		} catch (Exception e) {
			i = 0;
			session.beginTransaction().rollback();
		}
		
		return i;
	}

	public int FinishExam(int pid) {
		int i = 1;
		try {
			Paper paper = (Paper) session.get(Paper.class, pid);
			Tatus t = (Tatus) session.get(Tatus.class, 3);
			paper.setTatus(t);
			session.beginTransaction();
			session.update(paper);
			session.beginTransaction().commit();
		} catch (Exception e) {
			i = 0;
			session.beginTransaction().rollback();
		}
		return i;
	}

	public int deletePaperAndPaperEQ(int pid) {
		int i = 1;
		try {
			Paper paper = (Paper) session.get(Paper.class, pid);
			String hql = "from PaperEq where pid=:pid";
			Query query = session.createQuery(hql);
			query.setInteger("pid", pid);
			ArrayList<PaperEq> PaperEqList = (ArrayList<PaperEq>) query.list();
			for (PaperEq paperEq : PaperEqList) {
				session.beginTransaction();
				session.delete(paperEq);
				session.beginTransaction().commit();
			}
			session.beginTransaction();
			session.delete(paper);
			session.beginTransaction().commit();
		} catch (Exception e) {
			i = 0;
			session.beginTransaction().rollback();
		}
		return i;
	}

	public int addPaperEq(int pid, Level level) {
		int i = 1;
		
		//��ѡ
		ArrayList<ExamQuestion> addList = new ArrayList<ExamQuestion>(); 
		int easyNum = level.getEasy();
		int ordinary = level.getOrdinary();
		int difficult = level.getDifficult();
		//��ѡ
		int easyNum1 = level.getEasy1();
		int ordinary1 = level.getOrdinary1();
		int difficult1 = level.getDifficult1();
		try {
			Paper paper = (Paper) session.get(Paper.class, pid);
			int subid = paper.getSubject().getSubid();
			
			
			//----��ѡ
			while (easyNum!=0) {
				int m = 0;
				String hql = "from ExamQuestion where esubid=:subid and edifficultLevel='��' and echooseType='��ѡ' ";
				Query query = session.createQuery(hql);
				query.setInteger("subid", subid);
				ArrayList<ExamQuestion> EQList = (ArrayList<ExamQuestion>) query.list();
				for (ExamQuestion EQ : EQList) {
					int num = (int) ((Math.random()*10+1));
					if (num==1) {
						addList.add(EQ);
						easyNum--;
						if (easyNum==0) {
							break;
						}
					} 
				}
				m++;
				if (m==10000) {
					return i=0;
				} 
			}
			
			//--------
			while (ordinary !=0) {
				String hql = "from ExamQuestion where esubid=:subid and edifficultLevel='һ��' and echooseType='��ѡ'";
				Query query = session.createQuery(hql);
				query.setInteger("subid", subid);
				ArrayList<ExamQuestion> EQList1 = (ArrayList<ExamQuestion>) query.list();
				for (ExamQuestion EQ : EQList1) {
					int num = (int) ((Math.random()*10+1));
					if (num==1) {
						addList.add(EQ);
						ordinary--;
						if (ordinary==0) {
							break;
						}
					} 
				}
			}
			
			//--------
			while (difficult != 0) {
				String hql = "from ExamQuestion where esubid=:subid and edifficultLevel='����' and echooseType='��ѡ'";
				Query query = session.createQuery(hql);
				query.setInteger("subid", subid);
				ArrayList<ExamQuestion> EQList2 = (ArrayList<ExamQuestion>) query.list();
				for (ExamQuestion EQ : EQList2) {
					int num = (int) ((Math.random()*10+1));
					if (num==1) {
						addList.add(EQ);
						difficult--;
						if (difficult==0) {
							break;
						}
					} 
				}
			}
			
			//-----��ѡ
			while (easyNum1!=0) {
				String hql = "from ExamQuestion where esubid=:subid and edifficultLevel='��' and echooseType='��ѡ'";
				Query query = session.createQuery(hql);
				query.setInteger("subid", subid);
				ArrayList<ExamQuestion> EQList3 = (ArrayList<ExamQuestion>) query.list();
				for (ExamQuestion EQ : EQList3) {
					int num = (int) ((Math.random()*10+1));
					if (num==1) {
						addList.add(EQ);
						easyNum1--;
						if (easyNum1==0) {
							break;
						}
					} 
				}
			}
			
			//--------
			while (ordinary1 !=0) {
				String hql = "from ExamQuestion where esubid=:subid and edifficultLevel='һ��' and echooseType='��ѡ'";
				Query query = session.createQuery(hql);
				query.setInteger("subid", subid);
				ArrayList<ExamQuestion> EQList4 = (ArrayList<ExamQuestion>) query.list();
				for (ExamQuestion EQ : EQList4) {
					int num = (int) ((Math.random()*10+1));
					if (num==1) {
						addList.add(EQ);
						ordinary1--;
						if (ordinary1==0) {
							break;
						}
					} 
				}
			}
			
			//--------
			while (difficult1 != 0) {
				String hql = "from ExamQuestion where esubid=:subid and edifficultLevel='����' and echooseType='��ѡ'";
				Query query = session.createQuery(hql);
				query.setInteger("subid", subid);
				ArrayList<ExamQuestion> EQList5 = (ArrayList<ExamQuestion>) query.list();
				for (ExamQuestion EQ : EQList5) {
					int num = (int) ((Math.random()*10+1));
					if (num==1) {
						addList.add(EQ);
						difficult1--;
						if (difficult1==0) {
							break;
						}
					} 
				}
			}
			
			/**
			 * ���Ծ���������
			 */
			for (ExamQuestion EQ : addList) {
				int eid = EQ.getEid();
				ExamQuestion eqs = (ExamQuestion) session.get(ExamQuestion.class, eid);
				PaperEq pe = new PaperEq();
				pe.setPaper(paper);
				pe.setExamQuestion(eqs);
				session.beginTransaction();
				session.save(pe);
				session.beginTransaction().commit();
			}
			
			
		} catch (Exception e) {
			i = 0;
			session.beginTransaction().rollback();
		}
		return i;
	}


}
