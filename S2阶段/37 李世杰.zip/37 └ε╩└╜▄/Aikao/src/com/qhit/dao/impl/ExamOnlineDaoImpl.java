package com.qhit.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Transaction;

import com.qhit.bean.ExamQuestion;
import com.qhit.bean.Paper;
import com.qhit.bean.PaperEq;
import com.qhit.bean.Score;
import com.qhit.bean.StuPaperEq;
import com.qhit.bean.Student;
import com.qhit.dao.ExamOnlineDao;
import com.qhit.util.PageBean;

public class ExamOnlineDaoImpl implements ExamOnlineDao {

	public PageBean getPaperByPageBean(int p, int pcid) {
		PageBean pb = new PageBean();
		Transaction transaction = session.beginTransaction();
		try {
			String hql = "from Paper where pcid=:pcid and ptaid=:ptaid";
			Query query = session.createQuery(hql);
			query.setInteger("pcid", pcid);
			query.setInteger("ptaid", 2);
			int count = query.list().size();
			
			pb.setPagesize(5);
			pb.setCount(count);
			pb.setP(p);
			
			query.setFirstResult((p-1)*pb.getPagesize());
			query.setMaxResults(pb.getPagesize());
			List<ExamQuestion> eqList = query.list();
			pb.setData(eqList);
			transaction.commit();
		} catch (Exception e) {
			session.beginTransaction().rollback();
		}
		return pb;
	}

	public ArrayList<Paper> getPaperByPid(int pid) {
		String hql = "from Paper where pid = :pid";
		Query query = session.createQuery(hql);
		query.setInteger("pid", pid);
		return (ArrayList<Paper>) query.list();
	}

	public int getPaperTotalCountByPid(int pid) {
		String hql = "from PaperEq where pid = :pid";
		Query query = session.createQuery(hql);
		query.setInteger("pid", pid);
		return query.list().size();
	}

	public ArrayList<PaperEq> getPaperEqPid(int pid) {
		String hql = "from PaperEq where pid = :pid";
		Query query = session.createQuery(hql);
		query.setInteger("pid", pid);
		return (ArrayList<PaperEq>) query.list();
	}

	public int addStuPaperEq(int sid, int pid, int eid, String stuanswer) {
		int i = 1;
		try {
			Student stu = (Student) session.get(Student.class, sid);
			Paper paper = (Paper) session.get(Paper.class, pid);
			ExamQuestion eq = (ExamQuestion) session.get(ExamQuestion.class, eid);
			
			
			String hql = "from StuPaperEq where sid=:sid and pid=:pid and eid=:eid";
			Query query = session.createQuery(hql);
			query.setInteger("sid", sid);
			query.setInteger("pid", pid);
			query.setInteger("eid", eid);
			int count = query.list().size();//��ѯ��û��������� ����Ϊ1 ����Ϊ0
			if (count == 0) {
				StuPaperEq spe = new StuPaperEq();
				spe.setExamQuestion(eq);
				spe.setStudent(stu);
				spe.setPaper(paper);
				spe.setStuanswer(stuanswer);
				session.beginTransaction();
				session.save(spe);
				session.beginTransaction().commit();
			} else {
				StuPaperEq stup = (StuPaperEq) query.uniqueResult();
				int speid = stup.getSpeid();
				StuPaperEq speU = (StuPaperEq) session.get(StuPaperEq.class, speid);
				speU.setExamQuestion(eq);
				speU.setStudent(stu);
				speU.setPaper(paper);
				speU.setStuanswer(stuanswer);
				
				session.beginTransaction();
				session.update(speU);
				session.beginTransaction().commit();
			}
			
		} catch (Exception e) {
			i = 0;
			session.beginTransaction().rollback();
		}
		return i;
	}

	public StuPaperEq getStuAnswer(int sid, int pid, int eid) {
		String hql = "from StuPaperEq where sid=:sid and pid=:pid and eid=:eid";
		Query query = session.createQuery(hql);
		query.setInteger("sid", sid);
		query.setInteger("pid", pid);
		query.setInteger("eid", eid);
		return (StuPaperEq) query.uniqueResult();
	}

	public ArrayList<StuPaperEq> getStuAnswerAll(int sid, int pid) {
		String hql = "from StuPaperEq where sid=:sid and pid=:pid";
		Query query = session.createQuery(hql);
		query.setInteger("sid", sid);
		query.setInteger("pid", pid);
		return (ArrayList<StuPaperEq>) query.list();
	}

	public int getScore(ArrayList<StuPaperEq> speList, int ptotalScore, int size) {
		int everyScore = ptotalScore/size;
		for (StuPaperEq spe : speList) {
			ExamQuestion eq = spe.getExamQuestion();
			String eanswerReal = eq.getEanswer();
			String stuanswer = spe.getStuanswer();
			if (!eanswerReal.equals(stuanswer)) ptotalScore = ptotalScore-everyScore;
		}
		
		return ptotalScore;
	}

	public int finishExam(String startTime, String finishTime, int socre, int pid, int sid) {
		int i = 1;
		try {
			Paper paper = (Paper) session.get(Paper.class, pid);
			Student stu = (Student) session.get(Student.class, sid);
			Score sco = new Score();
			sco.setScostartTime(startTime);
			sco.setScofinishTime(finishTime);
			sco.setPaper(paper);
			sco.setStudent(stu);
			sco.setScoscore(socre+"");
			session.beginTransaction();
			session.save(sco);
			session.beginTransaction().commit();
		} catch (Exception e) {
			i = 0;
			session.beginTransaction().rollback();
		}
		return i;
	}

	public ArrayList<Score> getStuSocreList(int pid, int sid) {
		String hql = "from Score where scopid=:pid and scosid=:sid";
		Query query = session.createQuery(hql);
		query.setInteger("pid", pid);
		query.setInteger("sid", sid);
		return (ArrayList<Score>) query.list();
	}

	public int judgeExam(int pid, int sid) {
		int j = 0;
		String hql = "from Score where scopid=:pid and scosid=:sid";
		Query query = session.createQuery(hql);
		query.setInteger("pid", pid);
		query.setInteger("sid", sid);
		ArrayList<Score> scList = (ArrayList<Score>) query.list();
		for (Score score : scList) {
			j=1;
		}
		return j;
	}

}
