package com.qhit.biz.impl;

import java.util.ArrayList;

import com.qhit.bean.Direction;
import com.qhit.bean.ExamQuestion;
import com.qhit.bean.Stage;
import com.qhit.bean.Subject;
import com.qhit.biz.ExamBiz;
import com.qhit.dao.ExamDao;
import com.qhit.dao.impl.ExamDaoImpl;
import com.qhit.util.PageBean;


public class ExamBizImpl implements ExamBiz {

	private ExamDao dao=new ExamDaoImpl();

	public ArrayList<Direction> getDirList() {
		
		return dao.getDirList();
	}

	public ArrayList<Stage> getStageList() {
		
		return dao.getStageList();
	}

	public int getCountBySubid(int subid) {
		
		return dao.getCountBySubid(subid);
	}

	public Direction getDirectionById(int did) {
		
		return dao.getDirectionById(did);
	}

	public ArrayList<Stage> getStageById(int staid) {
		
		return dao.getStageById(staid);
	}

	public ArrayList<Subject> getSubjectByDidAndStaid(int did, int staid) {
		
		return dao.getSubjectByDidAndStaid(did, staid);
	}

	public ArrayList<Direction> getDirList(int order) {
		
		return dao.getDirList(order);
	}

	public ArrayList<Stage> getStageList(int order) {
		
		return dao.getStageList(order);
	}

	public ArrayList<ExamQuestion> getExamQuestionByEsubid(int esubid) {
		
		return dao.getExamQuestionByEsubid(esubid);
	}

	public ArrayList<Subject> getSubjectById(int subid) {
		
		return dao.getSubjectById(subid);
	}

	public int addExamQuestion(ExamQuestion e,int esubid) {
		
		return dao.addExamQuestion(e, esubid);
	}

	public int updateExamQuestion(ExamQuestion e, int esubid) {
		
		return dao.updateExamQuestion(e, esubid);
	}

	public ArrayList<ExamQuestion> getExamQuestionByEid(int eid) {
		
		return dao.getExamQuestionByEid(eid);
	}

	public PageBean getExamQuestionPageBean(int p, int esubid) {
		
		return dao.getExamQuestionPageBean(p, esubid);
	}

	
}
