package com.qhit.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Stage entity. @author MyEclipse Persistence Tools
 */

public class Stage implements java.io.Serializable {

	// Fields

	private Integer staid;
	private String staname;
	private Set subjects = new HashSet(0);

	// Constructors

	/** default constructor */
	public Stage() {
	}

	/** minimal constructor */
	public Stage(Integer staid) {
		this.staid = staid;
	}

	/** full constructor */
	public Stage(Integer staid, String staname, Set subjects) {
		this.staid = staid;
		this.staname = staname;
		this.subjects = subjects;
	}

	// Property accessors

	public Integer getStaid() {
		return this.staid;
	}

	public void setStaid(Integer staid) {
		this.staid = staid;
	}

	public String getStaname() {
		return this.staname;
	}

	public void setStaname(String staname) {
		this.staname = staname;
	}

	public Set getSubjects() {
		return this.subjects;
	}

	public void setSubjects(Set subjects) {
		this.subjects = subjects;
	}

}