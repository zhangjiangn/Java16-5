package com.qhit.dao;

import org.hibernate.Session;

import com.qhit.bean.Student;
import com.qhit.bean.Users;

public interface LoginDao {
	
	public Session session=HibernateSessionFactory.getSession();
	public Student loginStudentByStu(String name,String pwd);
	public Users loginUsersByUsers(String name,String pwd);

}
