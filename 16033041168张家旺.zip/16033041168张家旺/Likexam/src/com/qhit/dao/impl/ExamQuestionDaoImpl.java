package com.qhit.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.qhit.bean.Direction;
import com.qhit.bean.ExamQuestion;
import com.qhit.bean.Stage;
import com.qhit.bean.Subject;
import com.qhit.dao.ExamQuestionDao;
import com.qhit.dao.HibernateSessionFactory;
import com.qhit.util.PageBean;

public class ExamQuestionDaoImpl implements ExamQuestionDao {

	public ArrayList<Direction> getDirList() {
		ArrayList<Direction> list = new ArrayList<Direction>();
		String hql = "from Direction";
		Query query = session.createQuery(hql);
		list = (ArrayList<Direction>) query.list();
		return list;
	}

	public ArrayList<Stage> getStageList() {
		ArrayList<Stage> list = new ArrayList<Stage>();
		String hql = "from Stage";
		Query query = session.createQuery(hql);
		list = (ArrayList<Stage>) query.list();
		return list;
	}

	public int getCountBySubid(int subid) {
		int count = 0;
		String sql = "select count(*) from examquestion where esubid=:subid group by esubid";
		SQLQuery sqlquery = session.createSQLQuery(sql);
		sqlquery.setInteger("subid", subid);
		Object o = sqlquery.uniqueResult();
		if (o==null) {
			count = 0;
		}else{
			count = Integer.parseInt(o.toString());
		}
		return count;
	}

	public Direction getDirectionById(int did) {
		// TODO Auto-generated method stub
		return null;
	}

	public ArrayList<Stage> getStageById(int staid) {
		ArrayList<Stage> stage = new ArrayList<Stage>();
		String hql = "from Stage where staid=:staid";
		Query query = session.createQuery(hql);
		query.setInteger("staid", staid);
		stage = (ArrayList<Stage>) query.list();
		return stage;
	}

	public ArrayList<Subject> getSubjectByDidAndStaid(int did, int staid) {
		ArrayList<Subject> subject = new ArrayList<Subject>();
		String hql = "from Subject where subdid=:did and substaid=:staid";
		Query query = session.createQuery(hql);
		query.setInteger("did", did);
		query.setInteger("staid", staid);
		subject =  (ArrayList<Subject>) query.list();
		return subject;
	}

	public ArrayList<Direction> getDirList(int order) {
		ArrayList<Direction> list = new ArrayList<Direction>();
		switch (order) {
		case 1:
			String hql = "from Direction";
			Query query = session.createQuery(hql);
			list = (ArrayList<Direction>) query.list();
			break;
		default:
			String hql2 = "from Direction order by did desc";
			Query query2 = session.createQuery(hql2);
			list = (ArrayList<Direction>) query2.list();
			break;
		}
		return list;
	}

	public ArrayList<Stage> getStageList(int order) {
		ArrayList<Stage> list = new ArrayList<Stage>();
		switch (order) {
		case 1:
			String hql = "from Stage";
			Query query = session.createQuery(hql);
			list = (ArrayList<Stage>) query.list();
			break;

		default:
			String hql2 = "from Stage order by staid desc";
			Query query2 = session.createQuery(hql2);
			list = (ArrayList<Stage>) query2.list();
			break;
		}
		return list;
	}

	public ArrayList<ExamQuestion> getExamQuestionByEsubid(int esubid) {
		// TODO Auto-generated method stub
		ArrayList<ExamQuestion> list = new ArrayList<ExamQuestion>();
		String hql = "from ExamQuestion where esubid=:esubid";
		Query query = session.createQuery(hql);
		query.setInteger("esubid", esubid);
		list = (ArrayList<ExamQuestion>) query.list();
		return list;
	}

	public ArrayList<Subject> getSubjectById(int subid) {
		ArrayList<Subject> list = new ArrayList<Subject>();
		String hql = "from Subject where subid=:subid";
		Query query = session.createQuery(hql);
		query.setInteger("subid", subid);
		list = (ArrayList<Subject>) query.list();
		return list;
	}

	public int addExamQuestion(ExamQuestion e,int esubid) {
		// TODO ����
		int i = 1;
		try {
			
			Subject subO = (Subject) session.get(Subject.class, esubid);
			e.setSubject(subO);
			session.beginTransaction();
			session.save(e);
			session.beginTransaction().commit();
		} catch (Exception e2) {
			i = 0;
			session.beginTransaction().rollback();
		}
		return i;
	}

	public PageBean getExamQuestionPageBean(int p,int esubid) {
		PageBean pb = new PageBean();
		Transaction transaction = session.beginTransaction();
		try {
			String hql = "from ExamQuestion where esubid=:esubid";
			Query query = session.createQuery(hql).setCacheable(true);
			query.setInteger("esubid", esubid);
			int count=query.list().size();
			
			pb.setPagesize(10);
			pb.setCount(count);
			pb.setP(p);
			
			query.setFirstResult((p-1)*10);
			query.setMaxResults(pb.getPagesize());
			List<ExamQuestion> eqList = query.list();
			pb.setData(eqList);
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
		}
		
//		String hql = "from ExamQuestion where esubid=:esubid";
//		Query query = session.createQuery(hql);
//		query.setFirstResult((p-1)*3).setMaxResults(3).setInteger("esubid", esubid);
//		pb.setPagesize(3);
//		pb.setCount(query.list().size());
//		pb.setP(p);
//		List<ExamQuestion> eqList = query.list();
//		pb.setData(eqList);
		
		return pb;
	}

	public ArrayList<ExamQuestion> getExamQuestionByEid(int eid) {
		ArrayList<ExamQuestion> list = new ArrayList<ExamQuestion>();
		String hql = "from ExamQuestion where eid=:eid";
		Query query = session.createQuery(hql);
		query.setInteger("eid", eid);
		list = (ArrayList<ExamQuestion>) query.list();
		return list;
	}

	public int updateExamQuestion(ExamQuestion e, int esubid) {
		int i = 1;
		try {
			ExamQuestion e1 = (ExamQuestion) session.get(ExamQuestion.class, e.getEid());
			Subject subject = (Subject) session.get(Subject.class, esubid);
			e1.setEfirstType(e.getEfirstType());
			e1.setEchooseType(e.getEchooseType());
			e1.setEcontent(e.getEcontent());
			e1.setEoptionA(e.getEoptionA());
			e1.setEoptionB(e.getEoptionB());
			e1.setEoptionC(e.getEoptionC());
			e1.setEoptionD(e.getEoptionD());
			e1.setEanswer(e.getEanswer());
			e1.setEdifficultLevel(e.getEdifficultLevel());
			e1.setEchapter(e.getEchapter());
			e.setSubject(subject);
			session.beginTransaction();
			session.update(e1);
			session.beginTransaction().commit();
		} catch (Exception e2) {
			i =0;
			session.beginTransaction().rollback();
		}
		return i;
	}

}
