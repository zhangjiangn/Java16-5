package com.qhit.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;

import com.qhit.bean.Direction;
import com.qhit.bean.ExamQuestion;
import com.qhit.bean.Stage;
import com.qhit.bean.Subject;
import com.qhit.biz.ExamQuestionBiz;
import com.qhit.biz.impl.ExamQuestionBizImpl;
import com.qhit.util.PageBean;

public class ExamQuestionAction {
	
	private ExamQuestionBiz eqb = new ExamQuestionBizImpl();
	private ArrayList<Direction> dirList = new ArrayList<Direction>();
	private ArrayList<Stage> staList;
	private ArrayList<Subject> subject;
	private ArrayList<Stage> stage;
	private ArrayList<Subject> subList = new ArrayList<Subject>();
	private String dirOpValue;
	private String staOpValue;
	private int esubid;
	private ArrayList<ExamQuestion> EQList;
	private ExamQuestion examQuestions;
	private int p;
	private PageBean pbEQ;
	private int eid;
	private File uploadFile;
	private String uploadFileFileName;
	private String downFileName;
	private InputStream downFile_is;
	
	public String downEQ(){
		if (downFileName!=null) {
		
		
		try {
			String filePath= ServletActionContext.getServletContext().getRealPath("/")+"upload/"+downFileName;
			downFile_is = new FileInputStream(filePath);
			return "down";
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
		return null;
		
		
	}
	
	public String uploadEQ(){
		if(uploadFile!=null){
			String filePath= ServletActionContext.getServletContext().getRealPath("/")+"upload/";
			try {
				FileUtils.copyFile(uploadFile, new File(filePath, uploadFileFileName));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return "info";
		}else{
			ServletActionContext.getRequest().getSession().setAttribute("intext", "��ѡ���ļ�!");
			return "success";
		}
		
		
	}
	
	
	public String EQIndex(){
		dirList = eqb.getDirList();
		staList = eqb.getStageList();
		subject = eqb.getSubjectByDidAndStaid(1, 1);
		stage = eqb.getStageById(1);
		for (Subject sub : subject) {
			int esubid= sub.getSubid();
			int Num = eqb.getCountBySubid(esubid);
			sub.setCount(Num);
			subList.add(sub);
		}
		ServletActionContext.getRequest().getSession().setAttribute("subList", subList);
		return "eq1";
	}
	
	public String EQInfo(){
		System.out.println(esubid);
		int up=1;
		if(p!=0)up=p;
		pbEQ = eqb.getExamQuestionPageBean(up, esubid);
		subject = eqb.getSubjectById(esubid);
		if (pbEQ!=null) {
			return "eqInfo";
		}else{
			return "erro";
		}
	}
	
	public String editEQ(){
		subject = eqb.getSubjectById(esubid);
		EQList = eqb.getExamQuestionByEid(eid);
		return "editExamQuestion";
	}
	
	
	public String dirChange(){
		int did = Integer.parseInt(dirOpValue);
		int staid = Integer.parseInt(staOpValue);
		dirList = eqb.getDirList();
		staList = eqb.getStageList();
		subject = eqb.getSubjectByDidAndStaid(did, staid);
		stage = eqb.getStageById(staid);
		for (Subject sub : subject) {
			int esubid= sub.getSubid();
			int Num = eqb.getCountBySubid(esubid);
			sub.setCount(Num);
			subList.add(sub);
		}
		ServletActionContext.getRequest().getSession().setAttribute("subList", subList);
		return "eq1";
	}
	
	public String staChange(){
		int did = Integer.parseInt(dirOpValue);
		int staid = Integer.parseInt(staOpValue);
		dirList = eqb.getDirList();
		staList = eqb.getStageList();
		subject = eqb.getSubjectByDidAndStaid(did, staid);
		stage = eqb.getStageById(staid);
		for (Subject sub : subject) {
			int esubid= sub.getSubid();
			int Num = eqb.getCountBySubid(esubid);
			sub.setCount(Num);
			subList.add(sub);
		}
		ServletActionContext.getRequest().getSession().setAttribute("subList", subList);
		return "eq1";
	}
	
	//TODO ����
	public String addExamQuestion(){
		subject = eqb.getSubjectById(esubid);
		return "addExamQuestion";
	}
	
	public String addExamQuestionStart(){
		int i= eqb.addExamQuestion(examQuestions,esubid);
		if (i==1) {
			ServletActionContext.getRequest().getSession().setAttribute("intext", "���ӳɹ�!");
			return "success";
		}else{
			ServletActionContext.getRequest().getSession().setAttribute("intext", "����ʧ��!");
			return "success";
		}
		
	}
	
	public String editExamQuestionStart(){
		int i = eqb.updateExamQuestion(examQuestions, esubid);
		if (i==1) {
			ServletActionContext.getRequest().getSession().setAttribute("intext", "�޸ĳɹ�!");
			return "success";
		}else{
			ServletActionContext.getRequest().getSession().setAttribute("intext", "�޸�ʧ��!");
			return "success";
		}
	}
	
	public ExamQuestionBiz getEqb() {
		return eqb;
	}
	public void setEqb(ExamQuestionBiz eqb) {
		this.eqb = eqb;
	}
	public ArrayList<Direction> getDirList() {
		return dirList;
	}
	public void setDirList(ArrayList<Direction> dirList) {
		this.dirList = dirList;
	}
	public ArrayList<Stage> getStaList() {
		return staList;
	}
	public void setStaList(ArrayList<Stage> staList) {
		this.staList = staList;
	}
	
	
	public ArrayList<Stage> getStage() {
		return stage;
	}

	public void setStage(ArrayList<Stage> stage) {
		this.stage = stage;
	}

	public ArrayList<Subject> getSubject() {
		return subject;
	}
	public void setSubject(ArrayList<Subject> subject) {
		this.subject = subject;
	}

	public ArrayList<Subject> getSubList() {
		return subList;
	}

	public void setSubList(ArrayList<Subject> subList) {
		this.subList = subList;
	}

	public String getDirOpValue() {
		return dirOpValue;
	}

	public void setDirOpValue(String dirOpValue) {
		this.dirOpValue = dirOpValue;
	}

	public String getStaOpValue() {
		return staOpValue;
	}

	public void setStaOpValue(String staOpValue) {
		this.staOpValue = staOpValue;
	}

	public int getEsubid() {
		return esubid;
	}

	public void setEsubid(int esubid) {
		this.esubid = esubid;
	}

	public ArrayList<ExamQuestion> getEQList() {
		return EQList;
	}

	public void setEQList(ArrayList<ExamQuestion> eQList) {
		EQList = eQList;
	}

	public ExamQuestion getExamQuestions() {
		return examQuestions;
	}

	public void setExamQuestions(ExamQuestion examQuestions) {
		this.examQuestions = examQuestions;
	}

	public int getP() {
		return p;
	}

	public void setP(int p) {
		this.p = p;
	}

	public PageBean getPbEQ() {
		return pbEQ;
	}

	public void setPbEQ(PageBean pbEQ) {
		this.pbEQ = pbEQ;
	}

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public File getUploadFile() {
		return uploadFile;
	}


	public void setUploadFile(File uploadFile) {
		this.uploadFile = uploadFile;
	}


	public String getUploadFileFileName() {
		return uploadFileFileName;
	}


	public void setUploadFileFileName(String uploadFileFileName) {
		this.uploadFileFileName = uploadFileFileName;
	}

	public String getDownFileName() {
		return downFileName;
	}

	public void setDownFileName(String downFileName) {
		this.downFileName = downFileName;
	}

	public InputStream getDownFile_is() {
		return downFile_is;
	}

	public void setDownFile_is(InputStream downFileIs) {
		downFile_is = downFileIs;
	}

	
	
	
}
